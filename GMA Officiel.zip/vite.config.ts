import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { defineConfig } from 'vite';

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss()],
    define: {
      'process.env.NEXT_PUBLIC_APP_URL': JSON.stringify(
        process.env.NEXT_PUBLIC_APP_URL || 'https://savoirplus-edu.vercel.app'
      ),
      'process.env.NEXT_PUBLIC_SUPABASE_URL': JSON.stringify(
        (() => {
          const raw = process.env.NEXT_PUBLIC_SUPABASE_URL || process.env.VITE_SUPABASE_URL || '';
          if (!raw || raw.includes('[') || raw.includes('VOTRE_') || raw.includes('your_') || raw.includes('votre-projet')) {
            return 'rmumbqtvdmmnngvjivud.supabase.co';
          }
          return raw.replace(/^https?:\/\//, '').replace(/\/+$/, '');
        })()
      ),
      'process.env.VITE_SUPABASE_ANON_KEY': JSON.stringify(
        (() => {
          const raw = process.env.VITE_SUPABASE_ANON_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || '';
          let trimmed = raw.trim().replace(/^["'`]|["'`]$/g, '').trim();
          if (/^sb_publishable_/i.test(trimmed)) {
            return 'sb_publishable_' + trimmed.slice(15);
          }
          if (/^sb_secret_/i.test(trimmed)) {
            return 'sb_secret_' + trimmed.slice(10);
          }
          if (!trimmed || trimmed.includes('[') || trimmed.includes('VOTRE_') || trimmed.length < 10) {
            return 'sb_publishable_1-NSqCHk7YEHgbIxqcgxTw_2bUdO8e0';
          }
          return trimmed;
        })()
      ),
    },
    resolve: {
      dedupe: ['react', 'react-dom', 'react-router-dom', 'react-router'],
      alias: [
        { find: '@', replacement: path.resolve(__dirname, '.') },
      ],
    },
    optimizeDeps: {
      include: [
        'react',
        'react/jsx-runtime',
        'react/jsx-dev-runtime',
        'react-dom',
        'react-dom/client',
        'react-router-dom',
        'lucide-react',
      ],
    },
    server: {
      cors: {
        origin: [
          'https://savoirplus-edu.vercel.app',
          'https://savoirplus.ai.studio',
          'http://localhost:3000',
          'http://localhost:5173',
          /^https:\/\/.*\.vercel\.app$/,
        ],
        methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS', 'PATCH'],
        allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'apikey'],
        credentials: true,
      },
      headers: {
        'Access-Control-Allow-Origin': 'https://savoirplus-edu.vercel.app',
        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS, PATCH',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With, apikey',
        'Access-Control-Allow-Credentials': 'true',
      },
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
    preview: {
      cors: {
        origin: [
          'https://savoirplus-edu.vercel.app',
          'https://savoirplus.ai.studio',
          'http://localhost:3000',
          'http://localhost:5173',
          /^https:\/\/.*\.vercel\.app$/,
        ],
        methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS', 'PATCH'],
        allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'apikey'],
        credentials: true,
      },
      headers: {
        'Access-Control-Allow-Origin': 'https://savoirplus-edu.vercel.app',
        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS, PATCH',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With, apikey',
        'Access-Control-Allow-Credentials': 'true',
      },
    },
  };
});
