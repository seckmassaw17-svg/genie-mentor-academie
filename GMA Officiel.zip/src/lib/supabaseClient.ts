import { createClient, SupabaseClient } from "@supabase/supabase-js";

// Default public Supabase project credentials for Génie Mentor Académie (GMA)
const DEFAULT_SUPABASE_URL = "https://rmumbqtvdmmnngvjivud.supabase.co";
const DEFAULT_SUPABASE_ANON_KEY = "sb_publishable_1-NSqCHk7YEHgbIxqcgxTw_2bUdO8e0";

function cleanUrl(raw?: string | null): string {
  if (!raw || typeof raw !== "string") return DEFAULT_SUPABASE_URL;
  let trimmed = raw.trim().replace(/^["'`]|["'`]$/g, "").trim();

  // If user passed a placeholder, template string or brackets
  if (
    !trimmed ||
    trimmed.includes("[") ||
    trimmed.includes("]") ||
    trimmed.includes("VOTRE_") ||
    trimmed.includes("votre-projet") ||
    trimmed.includes("YOUR_") ||
    trimmed.includes("placeholder") ||
    trimmed.toLowerCase() === "undefined" ||
    trimmed.toLowerCase() === "null"
  ) {
    return DEFAULT_SUPABASE_URL;
  }

  // If user passed a markdown link like [https://...](https://...)
  const matchInParen = trimmed.match(/\((https?:\/\/[^\s)]+)\)/);
  if (matchInParen && matchInParen[1]) {
    trimmed = matchInParen[1];
  } else {
    const matchInBrackets = trimmed.match(/\[(https?:\/\/[^\s\]]+)\]/);
    if (matchInBrackets && matchInBrackets[1]) {
      trimmed = matchInBrackets[1];
    }
  }

  // If user passed just the 20-character project ref (e.g., 'rmumbqtvdmmnngvjivud')
  if (/^[a-z0-9]{20}$/i.test(trimmed)) {
    return `https://${trimmed.toLowerCase()}.supabase.co`;
  }

  // Find valid HTTP/HTTPS URL or hostname
  const urlMatch = trimmed.match(/https?:\/\/[^\s"'`<>\])]+/);
  if (urlMatch) {
    trimmed = urlMatch[0];
  } else if (trimmed.includes(".supabase.co") || trimmed.includes("localhost")) {
    trimmed = "https://" + trimmed.replace(/^https?:\/\//, "");
  }

  try {
    const parsed = new URL(trimmed);
    if (parsed.protocol === "http:" || parsed.protocol === "https:") {
      if (parsed.hostname.includes("votre-projet") || parsed.hostname.includes("[") || parsed.hostname.includes("example")) {
        return DEFAULT_SUPABASE_URL;
      }
      return parsed.origin;
    }
  } catch (err) {
    console.warn("Invalid Supabase URL in env, using default:", err);
  }

  return DEFAULT_SUPABASE_URL;
}

function cleanKey(raw?: string | null): string {
  if (!raw || typeof raw !== "string") return DEFAULT_SUPABASE_ANON_KEY;
  let trimmed = raw.trim().replace(/^["'`]|["'`]$/g, "").trim();

  // If user passed a placeholder or corrupted string
  if (
    trimmed.includes("[") ||
    trimmed.includes("]") ||
    trimmed.includes("VOTRE_") ||
    trimmed.includes("YOUR_") ||
    trimmed.includes("placeholder") ||
    trimmed.toLowerCase() === "undefined" ||
    trimmed.toLowerCase() === "null" ||
    trimmed.length < 10
  ) {
    return DEFAULT_SUPABASE_ANON_KEY;
  }

  // Supabase publishable keys start with 'sb_publishable_' in strict lowercase
  // Normalize if phone/keyboard capitalized the first letter (e.g. Sb_publishable_ or SB_publishable_)
  if (/^sb_publishable_/i.test(trimmed)) {
    trimmed = "sb_publishable_" + trimmed.slice(15);
  } else if (/^sb_secret_/i.test(trimmed)) {
    trimmed = "sb_secret_" + trimmed.slice(10);
  } else if (!trimmed.startsWith("eyJ")) {
    // If not a standard JWT anon key (starts with eyJ) and not an sb_ key, fall back to known default
    return DEFAULT_SUPABASE_ANON_KEY;
  }

  return trimmed;
}

const rawEnvUrl = 
  (typeof process !== "undefined" && process.env?.NEXT_PUBLIC_SUPABASE_URL) ||
  (typeof import.meta !== "undefined" ? (import.meta.env?.NEXT_PUBLIC_SUPABASE_URL || import.meta.env?.VITE_SUPABASE_URL) : undefined);
const rawEnvKey = 
  (typeof process !== "undefined" && process.env?.NEXT_PUBLIC_SUPABASE_ANON_KEY) ||
  (typeof import.meta !== "undefined" ? (import.meta.env?.NEXT_PUBLIC_SUPABASE_ANON_KEY || import.meta.env?.VITE_SUPABASE_ANON_KEY) : undefined);

const supabaseUrl = cleanUrl(rawEnvUrl);
const supabaseAnonKey = cleanKey(rawEnvKey);

export const isSupabaseConfigured = Boolean(
  supabaseUrl &&
  supabaseAnonKey &&
  supabaseUrl.startsWith("https://") &&
  !supabaseUrl.includes("votre-projet")
);

const authOptions = {
  persistSession: true,
  autoRefreshToken: true,
  detectSessionInUrl: true,
  storageKey: "savoirplus_supabase_auth_token",
  storage: typeof window !== "undefined" ? window.localStorage : undefined,
};

function createSafeClient(): SupabaseClient {
  try {
    return createClient(supabaseUrl, supabaseAnonKey, {
      auth: authOptions,
    });
  } catch (err) {
    console.error("Failed to initialize primary Supabase client, falling back to default:", err);
    return createClient(DEFAULT_SUPABASE_URL, DEFAULT_SUPABASE_ANON_KEY, {
      auth: authOptions,
    });
  }
}

// Global singleton client initialized with public anon key, accessible even when no user is logged in
const globalClientInstance: SupabaseClient = createSafeClient();

export function getSupabaseClient(): SupabaseClient {
  return globalClientInstance;
}

// Export direct client references
export const supabase: SupabaseClient = globalClientInstance;
export const supabaseClient: SupabaseClient = globalClientInstance;

export async function testSupabaseConnection(): Promise<boolean> {
  if (!supabase) return false;
  try {
    // 1. Try public system_settings first
    const { data: sysData, error: sysError } = await supabase
      .from("system_settings")
      .select("id")
      .limit(1);
    if (!sysError && sysData) return true;

    // 2. Try app_settings
    const { data: appData, error: appError } = await supabase
      .from("app_settings")
      .select("id")
      .limit(1);
    if (!appError && appData) return true;

    // 3. Try profiles table
    const { error: profileError } = await supabase
      .from("profiles")
      .select("id")
      .limit(1);
    return !profileError;
  } catch {
    return false;
  }
}
