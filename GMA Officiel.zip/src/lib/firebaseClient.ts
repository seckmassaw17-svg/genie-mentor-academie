import { initializeApp, getApps, getApp } from "firebase/app";
import { getFirestore, doc, setDoc, getDoc, updateDoc } from "firebase/firestore";
import { getAuth } from "firebase/auth";
import firebaseConfig from "../../firebase-applet-config.json";
import { UserProfile } from "../types";

export const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId || "(default)");
export const auth = getAuth(app);

/**
 * Synchronise l'utilisateur dans Firestore dans la collection 'users'
 * en utilisant STRICTEMENT son UID d'authentification comme ID unique de document.
 */
export async function syncUserToFirestore(user: Partial<UserProfile> & { uid: string }): Promise<void> {
  if (!user.uid) return;
  try {
    const userRef = doc(db, "users", user.uid);
    const resolvedName = (user.displayName || user.fullName || "").trim() || "Élève";
    const parts = resolvedName.split(/\s+/);
    const prenom = user.prenom || (parts.length > 1 ? parts.slice(0, -1).join(" ") : parts[0]);
    const nom = user.nom || (parts.length > 1 ? parts[parts.length - 1] : "");

    const payload: Record<string, any> = {
      uid: user.uid,
      id: user.uid,
      displayName: resolvedName,
      fullName: resolvedName,
      prenom: prenom || "",
      nom: nom || "",
      email: (user.email || "").trim().toLowerCase(),
      role: user.role || (user.isAdmin ? "admin" : "eleve"),
      level: user.level || user.classe || "3ème",
      classe: user.classe || user.level || "3ème",
      photoUrl: user.photoUrl || user.avatarUrl || "",
      isAdmin: Boolean(user.isAdmin),
      isVIP: Boolean(user.isVIP),
      isProfileComplete: Boolean(user.isProfileComplete),
      createdAt: user.createdAt || Date.now(),
      lastSeen: Date.now(),
    };

    await setDoc(userRef, payload, { merge: true });

    // Synchronise également dans la collection profiles pour compatibilité avec toutes les règles de sécurité
    try {
      const profileRef = doc(db, "profiles", user.uid);
      await setDoc(profileRef, payload, { merge: true });
    } catch {}
  } catch (err) {
    console.warn("[Firebase] Notice synchronisation Firestore user:", err);
  }
}
