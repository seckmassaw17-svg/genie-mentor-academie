export interface SystemSettings {
  id?: string;

  // 1. Identité
  appName: string;
  shortName: string;
  description: string;

  // 2. Charte Graphique (Codes Hexadécimaux)
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;

  // 3. Médias
  faviconUrl: string;
  pwaIconUrl: string;
  pwaIcon192Url?: string;
  pwaIcon512Url?: string;
  logoUrl?: string;
  adminSignatureUrl: string;

  // 4. Opérations & Paiements
  registrationStatus: "open" | "closed";
  waveMerchantNumber: string;
  omMerchantNumber: string;
  paymentGuide: string;

  // 5. Communication
  whatsappSupport: string;
  supportEmail: string;
  communityUrl: string;
  announcementBanner: string;
  announcementBannerActive: boolean;

  // Mises à jour & Fichier APK
  latestVersion?: string;
  apkUrl?: string;
  updateMessage?: string;

  updatedAt?: number;
  updatedBy?: string;
}

export const DEFAULT_SYSTEM_SETTINGS: SystemSettings = {
  id: "main",
  // 1. Identité
  appName: "Génie Mentor Académie (GMA)",
  shortName: "GMA",
  description: "Plateforme éducative d'excellence du Sénégal - Cours, Quiz, Annales et Tuteur IA 100% Hors-Ligne",

  // 2. Charte Graphique
  primaryColor: "#1A237E",
  secondaryColor: "#3949AB",
  accentColor: "#F59E0B",

  // 3. Médias
  faviconUrl: "/logo-192.png",
  pwaIconUrl: "/logo.png",
  adminSignatureUrl: "/app-signature.png",

  // 4. Opérations & Paiements
  registrationStatus: "open",
  waveMerchantNumber: "78 376 95 84",
  omMerchantNumber: "78 376 95 84",
  paymentGuide: "Pour valider votre inscription ou votre Pass VIP, effectuez votre transfert Wave ou Orange Money vers l'un des numéros marchands officiels ci-dessus, puis saisissez la référence de paiement.",

  // 5. Communication
  whatsappSupport: "+221 78 376 95 84",
  supportEmail: "massaw.seck@unchk.edu.sn",
  communityUrl: "https://chat.whatsapp.com/GMA-Excellence-Senegal",
  announcementBanner: "Bienvenue sur Génie Mentor Académie (GMA) ! Les inscriptions et répétitions d'élite sont ouvertes.",
  announcementBannerActive: true,

  // Mises à jour & APK
  latestVersion: "1.0.2",
  apkUrl: "",
  updateMessage: "Une nouvelle version de l'application Génie Mentor Académie est disponible avec des améliorations majeures.",
  updatedAt: Date.now(),
};
