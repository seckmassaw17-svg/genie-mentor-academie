/**
 * Numéro de version globale et dynamique de l'application Génie Mentor Académie (GMA)
 * Centralisé pour toute l'application (UI, Profil, Modales, Mises à jour, SW, Caches).
 */
export const APP_VERSION = "1.0.1";
export const CURRENT_APP_VERSION = APP_VERSION;
