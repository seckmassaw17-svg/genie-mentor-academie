import { supabase, supabaseClient, getSupabaseClient, testSupabaseConnection } from "./lib/supabaseClient";

export { supabase, supabaseClient, getSupabaseClient, testSupabaseConnection };
export default supabase;
