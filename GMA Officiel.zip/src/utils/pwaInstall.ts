// PWA / APK Installation helper for Génie Mentor Académie (GMA)

type BeforeInstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed"; platform: string }>;
};

let deferredPrompt: BeforeInstallPromptEvent | null = null;
const listeners = new Set<(canInstall: boolean) => void>();

export function initPwaInstallListener(): () => void {
  if (typeof window === "undefined") return () => {};

  const handleBeforeInstallPrompt = (e: Event) => {
    e.preventDefault();
    deferredPrompt = e as BeforeInstallPromptEvent;
    notifyListeners();
  };

  const handleAppInstalled = () => {
    deferredPrompt = null;
    notifyListeners();
  };

  window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
  window.addEventListener("appinstalled", handleAppInstalled);

  return () => {
    window.removeEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
    window.removeEventListener("appinstalled", handleAppInstalled);
  };
}

function notifyListeners() {
  const canInstall = !isAppInstalled() && deferredPrompt !== null;
  listeners.forEach((fn) => fn(canInstall));
}

export function subscribeToInstallStatus(callback: (canInstall: boolean) => void): () => void {
  listeners.add(callback);
  // Initial callback
  callback(!isAppInstalled() && deferredPrompt !== null);
  return () => {
    listeners.delete(callback);
  };
}

export function isAppInstalled(): boolean {
  if (typeof window === "undefined") return false;
  return (
    window.matchMedia("(display-mode: standalone)").matches ||
    (window.navigator as any).standalone === true ||
    document.referrer.includes("android-app://")
  );
}

export function canPromptDirectInstall(): boolean {
  return !isAppInstalled() && deferredPrompt !== null;
}

export async function promptPwaInstall(): Promise<"accepted" | "dismissed" | "unavailable"> {
  if (!deferredPrompt) {
    return "unavailable";
  }

  try {
    await deferredPrompt.prompt();
    const choice = await deferredPrompt.userChoice;
    if (choice.outcome === "accepted") {
      deferredPrompt = null;
      notifyListeners();
      return "accepted";
    }
    return "dismissed";
  } catch (err) {
    console.warn("PWA install prompt error:", err);
    return "unavailable";
  }
}
