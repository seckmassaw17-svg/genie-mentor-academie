/**
 * Formate une date ou un timestamp en chaîne de caractères conviviale et humaine en français.
 * Exemples : "À l'instant", "Il y a 10 min", "Aujourd'hui à 14:30", "Hier à 09:15", "25/09/2026".
 */
export function formatFriendlyNotificationDate(
  dateInput: number | string | Date | null | undefined
): string {
  if (!dateInput) {
    return "Récemment";
  }

  // Si c'est déjà un texte formaté en français (ex: "Aujourd'hui à ...", "Il y a ...", "Hier")
  if (
    typeof dateInput === "string" &&
    (dateInput.startsWith("Aujourd'hui") ||
      dateInput.startsWith("Hier") ||
      dateInput.startsWith("Il y a") ||
      dateInput.startsWith("À l'instant"))
  ) {
    return dateInput;
  }

  let date: Date;
  if (typeof dateInput === "number") {
    // Gestion des timestamps en secondes vs millisecondes
    const ms = dateInput < 10000000000 ? dateInput * 1000 : dateInput;
    date = new Date(ms);
  } else if (typeof dateInput === "string") {
    // Vérification si la chaîne est un nombre brut
    const num = Number(dateInput);
    if (!isNaN(num) && num > 0) {
      const ms = num < 10000000000 ? num * 1000 : num;
      date = new Date(ms);
    } else {
      date = new Date(dateInput);
    }
  } else if (dateInput instanceof Date) {
    date = dateInput;
  } else {
    return "Récemment";
  }

  if (isNaN(date.getTime())) {
    return typeof dateInput === "string" ? dateInput : "Récemment";
  }

  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffSec = Math.floor(diffMs / 1000);
  const diffMin = Math.floor(diffSec / 60);
  const diffHours = Math.floor(diffMin / 60);

  // Heure formatée (ex: 14:30)
  const hoursStr = String(date.getHours()).padStart(2, "0");
  const minsStr = String(date.getMinutes()).padStart(2, "0");
  const timeFormatted = `${hoursStr}:${minsStr}`;

  // Date formatée (ex: 25/09/2026)
  const dayStr = String(date.getDate()).padStart(2, "0");
  const monthStr = String(date.getMonth() + 1).padStart(2, "0");
  const yearStr = date.getFullYear();
  const fullDateFormatted = `${dayStr}/${monthStr}/${yearStr}`;

  // Moins d'une minute
  if (diffSec < 60 && diffSec >= -5) {
    return "À l'instant";
  }

  // Moins d'une heure (ex: "Il y a 10 min")
  if (diffMin < 60 && diffMin >= 1) {
    return `Il y a ${diffMin} min`;
  }

  // Vérifier si c'est aujourd'hui (même jour, même mois, même année)
  const isToday =
    date.getDate() === now.getDate() &&
    date.getMonth() === now.getMonth() &&
    date.getFullYear() === now.getFullYear();

  if (isToday) {
    return `Aujourd'hui à ${timeFormatted}`;
  }

  // Vérifier si c'est hier
  const yesterday = new Date(now);
  yesterday.setDate(yesterday.getDate() - 1);
  const isYesterday =
    date.getDate() === yesterday.getDate() &&
    date.getMonth() === yesterday.getMonth() &&
    date.getFullYear() === yesterday.getFullYear();

  if (isYesterday) {
    return `Hier à ${timeFormatted}`;
  }

  // Date complète
  return `${fullDateFormatted} à ${timeFormatted}`;
}
