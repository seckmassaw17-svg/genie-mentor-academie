/**
 * Utilitaires pour le formatage des URLs de documents et supports de cours PDF.
 */
export function getEmbeddableDocumentUrl(rawUrl: string): string {
  if (!rawUrl) return "";
  const trimmed = rawUrl.trim();

  // Support des liens Google Drive /file/d/{id} pour l'iframe de prévisualisation
  const fileIdMatch = trimmed.match(/\/file\/d\/([a-zA-Z0-9_-]+)/);
  if (fileIdMatch && fileIdMatch[1]) {
    return `https://drive.google.com/file/d/${fileIdMatch[1]}/preview`;
  }

  // Support des paramètres id={id}
  const queryIdMatch = trimmed.match(/[?&]id=([a-zA-Z0-9_-]+)/);
  if (queryIdMatch && queryIdMatch[1] && trimmed.includes("drive.google.com")) {
    return `https://drive.google.com/file/d/${queryIdMatch[1]}/preview`;
  }

  // Support Google Docs / Sheets / Slides
  if (trimmed.includes("docs.google.com") && (trimmed.includes("/edit") || trimmed.includes("/view"))) {
    return trimmed.replace(/\/edit.*$/, "/preview").replace(/\/view.*$/, "/preview");
  }

  return trimmed;
}

// Alias de compatibilité
export const getEmbeddableDriveUrl = getEmbeddableDocumentUrl;
