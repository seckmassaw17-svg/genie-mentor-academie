export interface PasswordValidationResult {
  hasMinLength: boolean;
  hasLower: boolean;
  hasUpper: boolean;
  hasDigit: boolean;
  isValid: boolean;
}

export function validatePasswordComplexity(password: string): PasswordValidationResult {
  const pwd = password || "";
  const hasMinLength = pwd.length >= 6;
  const hasLower = /[a-z]/.test(pwd);
  const hasUpper = /[A-Z]/.test(pwd);
  const hasDigit = /\d/.test(pwd);
  return {
    hasMinLength,
    hasLower,
    hasUpper,
    hasDigit,
    isValid: hasMinLength && hasLower && hasUpper && hasDigit,
  };
}
