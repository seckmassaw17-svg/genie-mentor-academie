import { getAppConfigFromSupabase, saveAppConfigToSupabase, AppConfigRecord } from "../data/supabaseStorage";
import { APP_VERSION, CURRENT_APP_VERSION } from "../constants/version";
import { purgeServiceWorkerCaches } from "./swUpdate";

export { APP_VERSION, CURRENT_APP_VERSION };
export type AppConfigData = AppConfigRecord;

const LOCAL_CONFIG_KEY = "savoir_plus_app_config_v1";

export interface UpdateCheckResult {
  hasUpdate: boolean;
  latestVersion: string;
  currentVersion: string;
  apkUrl: string;
  message?: string;
}

/**
 * Compare two semver strings (e.g., "1.0.0" vs "1.0.1").
 * Returns true if latestVersion is strictly greater than currentVersion.
 */
export function isNewerVersion(currentVersion: string, latestVersion: string): boolean {
  if (!latestVersion) return false;

  const clean = (v: string) => v.replace(/^v/i, "").trim();
  const currentParts = clean(currentVersion).split(".").map((p) => parseInt(p, 10) || 0);
  const latestParts = clean(latestVersion).split(".").map((p) => parseInt(p, 10) || 0);

  const maxLength = Math.max(currentParts.length, latestParts.length);

  for (let i = 0; i < maxLength; i++) {
    const c = currentParts[i] || 0;
    const l = latestParts[i] || 0;
    if (l > c) return true;
    if (l < c) return false;
  }

  return false;
}

/**
 * Get current cached config from localStorage.
 */
export function getLocalAppConfig(): AppConfigData {
  try {
    const raw = localStorage.getItem(LOCAL_CONFIG_KEY);
    if (raw) return JSON.parse(raw);
  } catch {
    // ignore
  }
  return {
    latest_version: APP_VERSION,
    apk_url: "",
    message: "Une nouvelle version de l'application Génie Mentor Académie est disponible avec de superbes améliorations.",
  };
}

/**
 * Save config locally.
 */
export function saveLocalAppConfig(config: AppConfigData): void {
  localStorage.setItem(LOCAL_CONFIG_KEY, JSON.stringify(config));
}

/**
 * Fetch latest app config directly from Supabase / system_settings, fallback to local cache.
 * If a newer version exists remotely, immediately purges the Service Worker cache (caches.delete())
 * so the client downloads the newly published assets.
 */
export async function checkForAppUpdates(): Promise<UpdateCheckResult> {
  let config: AppConfigData | null = null;

  try {
    config = await getAppConfigFromSupabase();
  } catch (err) {
    console.warn("[VersionCheck] Could not fetch remote app config from Supabase:", err);
  }

  if (!config) {
    config = getLocalAppConfig();
  } else {
    saveLocalAppConfig(config);
  }

  const latestVer = config.latest_version || config.globalVersion || APP_VERSION;
  const hasUpdate = isNewerVersion(APP_VERSION, latestVer);

  if (hasUpdate) {
    console.log(`[VersionCheck] Nouvelle version distante détectée: v${latestVer} (actuelle: v${APP_VERSION}). Purge du cache Service Worker en cours...`);
    // Automatically purge Service Worker caches (caches.delete()) to force fresh downloads
    purgeServiceWorkerCaches().catch((e) => {
      console.warn("[VersionCheck] Notice purging SW caches:", e);
    });
  }

  return {
    hasUpdate,
    latestVersion: latestVer,
    currentVersion: APP_VERSION,
    apkUrl: config.apk_url || "",
    message: config.message || "Une nouvelle version de l'application Génie Mentor Académie est disponible avec de superbes améliorations.",
  };
}

/**
 * Save new configuration (Admin action) to both Supabase & LocalStorage.
 */
export async function updateAppConfig(config: AppConfigData): Promise<void> {
  saveLocalAppConfig(config);
  await saveAppConfigToSupabase(config);
}

