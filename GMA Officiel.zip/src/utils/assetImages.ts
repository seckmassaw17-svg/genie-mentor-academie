import { useState, useEffect } from "react";
import rawOfficialSignature from "../actifs/images/Signature.png";
import officialLogoPng from "../assets/images/regenerated_image_1789972626630.png";
import { getAppConfigFromSupabase, saveAppConfigToSupabase, isSupabaseActive } from "../data/supabaseStorage";

// ============================================================================
// CONFIGURATION OFFICIELLE SUPABASE STORAGE POUR LE LOGO
// Bucket : "Savoirplus Fichiers"
// Fichier : "logo.png"
// ============================================================================
const rawSupabaseHost = (
  (typeof import.meta !== "undefined" && (import.meta.env?.VITE_SUPABASE_URL || import.meta.env?.NEXT_PUBLIC_SUPABASE_URL)) ||
  (typeof process !== "undefined" && process.env?.NEXT_PUBLIC_SUPABASE_URL) ||
  "rmumbqtvdmmnngvjivud.supabase.co"
);
let candidateHost = String(rawSupabaseHost).replace(/^https?:\/\//, "").replace(/\/+$/, "").trim();
if (
  !candidateHost ||
  candidateHost.includes("[") ||
  candidateHost.includes("VOTRE_") ||
  candidateHost.includes("votre-projet") ||
  candidateHost.includes("your_")
) {
  candidateHost = "rmumbqtvdmmnngvjivud.supabase.co";
}
if (!candidateHost.includes(".")) {
  candidateHost = `${candidateHost}.supabase.co`;
}

/** URL officielle du logo sur Supabase Storage avec anti-cache ?v=1.0.0 */
export const SUPABASE_STORAGE_LOGO_URL = `https://${candidateHost}/storage/v1/object/public/Savoirplus%20Fichiers/logo.png?v=1.0.0`;

export { officialLogoPng };
export const appLogo = officialLogoPng || SUPABASE_STORAGE_LOGO_URL;
export const officialSignature = rawOfficialSignature || "/app-signature.png";

const LOGO_STORAGE_KEY = "savoir_app_logo_data";
const SIGNATURE_STORAGE_KEY = "savoir_official_signature_data";
const FAVICON_STORAGE_KEY = "gma_favicon_data";
const PWA_192_STORAGE_KEY = "gma_pwa_icon_192_data";
const PWA_512_STORAGE_KEY = "gma_pwa_icon_512_data";

let cachedLogoUrl: string | null = null;
let cachedSignatureUrl: string | null = null;
let cachedFaviconUrl: string | null = null;
let cachedPwa192Url: string | null = null;
let cachedPwa512Url: string | null = null;

// Initialisation synchrone depuis le stockage local (Zero-flicker Offline First)
if (typeof window !== "undefined") {
  try {
    const saved = localStorage.getItem(LOGO_STORAGE_KEY);
    if (saved && (saved.startsWith("data:image") || saved.startsWith("http"))) {
      cachedLogoUrl = saved;
    }
  } catch (e) {
    // ignore
  }
  try {
    const savedSig = localStorage.getItem(SIGNATURE_STORAGE_KEY);
    if (savedSig && (savedSig.startsWith("data:image") || savedSig.startsWith("http"))) {
      cachedSignatureUrl = savedSig;
    }
  } catch (e) {
    // ignore
  }
  try {
    const savedFav = localStorage.getItem(FAVICON_STORAGE_KEY);
    if (savedFav && (savedFav.startsWith("data:image") || savedFav.startsWith("http"))) {
      cachedFaviconUrl = savedFav;
    }
  } catch (e) {}
  try {
    const saved192 = localStorage.getItem(PWA_192_STORAGE_KEY);
    if (saved192 && (saved192.startsWith("data:image") || saved192.startsWith("http"))) {
      cachedPwa192Url = saved192;
    }
  } catch (e) {}
  try {
    const saved512 = localStorage.getItem(PWA_512_STORAGE_KEY);
    if (saved512 && (saved512.startsWith("data:image") || saved512.startsWith("http"))) {
      cachedPwa512Url = saved512;
    }
  } catch (e) {}
}

type LogoListener = (url: string) => void;
const logoListeners = new Set<LogoListener>();

export function subscribeToLogoChange(listener: LogoListener): () => void {
  logoListeners.add(listener);
  return () => {
    logoListeners.delete(listener);
  };
}

type SignatureListener = (url: string) => void;
const signatureListeners = new Set<SignatureListener>();

export function subscribeToSignatureChange(listener: SignatureListener): () => void {
  signatureListeners.add(listener);
  return () => {
    signatureListeners.delete(listener);
  };
}

type AssetListener = (url: string) => void;
const faviconListeners = new Set<AssetListener>();
const pwa192Listeners = new Set<AssetListener>();
const pwa512Listeners = new Set<AssetListener>();

export function subscribeToFaviconChange(listener: AssetListener): () => void {
  faviconListeners.add(listener);
  return () => {
    faviconListeners.delete(listener);
  };
}

export function subscribeToPwa192Change(listener: AssetListener): () => void {
  pwa192Listeners.add(listener);
  return () => {
    pwa192Listeners.delete(listener);
  };
}

export function subscribeToPwa512Change(listener: AssetListener): () => void {
  pwa512Listeners.add(listener);
  return () => {
    pwa512Listeners.delete(listener);
  };
}

/** Met à jour la balise favicon dans le document HTML */
export function applyFaviconToDom(url: string): void {
  if (typeof document === "undefined" || !url) return;
  try {
    let link = document.querySelector("link[rel*='icon']") as HTMLLinkElement | null;
    if (!link) {
      link = document.createElement("link");
      link.type = "image/png";
      link.rel = "icon";
      document.head.appendChild(link);
    }
    link.href = url;

    let shortcut = document.querySelector("link[rel='shortcut icon']") as HTMLLinkElement | null;
    if (shortcut) {
      shortcut.href = url;
    }
  } catch (e) {
    // ignore
  }
}

/** Met à jour l'icône PWA 192x192 dans le document HTML */
export function applyPwa192ToDom(url: string): void {
  if (typeof document === "undefined" || !url) return;
  try {
    const icon192 = document.querySelector("link[rel='apple-touch-icon'][sizes='192x192']") as HTMLLinkElement | null;
    if (icon192) {
      icon192.href = url;
    }
  } catch (e) {}
}

/** Met à jour l'icône PWA 512x512 dans le document HTML */
export function applyPwa512ToDom(url: string): void {
  if (typeof document === "undefined" || !url) return;
  try {
    const icon512 = document.querySelector("link[rel='apple-touch-icon'][sizes='512x512']") as HTMLLinkElement | null;
    if (icon512) {
      icon512.href = url;
    }
    const tile = document.querySelector("meta[name='msapplication-TileImage']") as HTMLMetaElement | null;
    if (tile) {
      tile.content = url;
    }
  } catch (e) {}
}

export function setAppLogo(url: string): void {
  if (!url) return;
  cachedLogoUrl = url;
  if (typeof window !== "undefined") {
    try {
      localStorage.setItem(LOGO_STORAGE_KEY, url);
      window.dispatchEvent(new CustomEvent("savoir_logo_updated", { detail: url }));
    } catch (e) {
      // ignore
    }
  }
  logoListeners.forEach((fn) => {
    try {
      fn(url);
    } catch (err) {
      console.warn("Logo listener error:", err);
    }
  });
}

export function setOfficialSignature(url: string): void {
  if (!url) return;
  cachedSignatureUrl = url;
  if (typeof window !== "undefined") {
    try {
      localStorage.setItem(SIGNATURE_STORAGE_KEY, url);
      window.dispatchEvent(new CustomEvent("savoir_signature_updated", { detail: url }));
    } catch (e) {
      // ignore
    }
  }
  signatureListeners.forEach((fn) => {
    try {
      fn(url);
    } catch (err) {
      console.warn("Signature listener error:", err);
    }
  });
}

/**
 * Télécharge le logo depuis Supabase Storage et le met en cache localement
 * en Base64 dans localStorage et dans CacheStorage pour une utilisation Offline-First instantanée.
 */
export async function downloadAndCacheLogo(targetUrl = SUPABASE_STORAGE_LOGO_URL): Promise<string | null> {
  if (typeof window === "undefined") return null;

  // Si l'utilisateur est hors-ligne, on utilise directement le cache existant
  if (typeof navigator !== "undefined" && !navigator.onLine) {
    return cachedLogoUrl || null;
  }

  try {
    const response = await fetch(targetUrl, {
      method: "GET",
      cache: "default",
      headers: {
        Accept: "image/png,image/jpeg,image/webp,image/*",
      },
    });

    if (!response.ok) {
      // Si le logo n'est pas encore téléversé dans Supabase Storage (404/403), on n'écrase pas le cache
      return cachedLogoUrl;
    }

    const blob = await response.blob();
    if (!blob || blob.size === 0) return cachedLogoUrl;

    // Convertit le blob en Base64 Data URL pour persistance synchrone et offline instantané
    const base64 = await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === "string") {
          resolve(reader.result);
        } else {
          reject(new Error("FileReader did not return a string"));
        }
      };
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });

    if (base64 && base64.startsWith("data:image")) {
      setAppLogo(base64);

      // Met également en cache dans l'API CacheStorage du navigateur
      if ("caches" in window) {
        caches.open("gma-logo-cache-v1").then((cache) => {
          cache.put(targetUrl, new Response(blob));
        }).catch(() => {
          // ignore cache storage failure
        });
      }

      return base64;
    }
  } catch (err) {
    console.debug("[Offline-First] Réseau indisponible ou logo Supabase non trouvé, conservation du cache:", err);
  }

  return cachedLogoUrl;
}

// Auto-téléchargement et rafraîchissement du cache en arrière-plan
if (typeof window !== "undefined") {
  // Téléchargement initial avec léger différé pour ne pas bloquer le premier rendu
  setTimeout(() => {
    downloadAndCacheLogo();
  }, 1200);

  // Rafraîchissement automatique dès que la connexion internet est rétablie
  window.addEventListener("online", () => {
    downloadAndCacheLogo();
  });
}

export function useAppLogo(): string {
  const [logo, setLogo] = useState<string>(() => getAppLogo());

  useEffect(() => {
    setLogo(getAppLogo());
    const unsub = subscribeToLogoChange((newLogo) => {
      setLogo(newLogo);
    });

    const handleCustomEvent = (e: Event) => {
      const customEvent = e as CustomEvent<string>;
      if (customEvent.detail) {
        setLogo(customEvent.detail);
      } else {
        setLogo(getAppLogo());
      }
    };

    if (typeof window !== "undefined") {
      window.addEventListener("savoir_logo_updated", handleCustomEvent);
    }

    return () => {
      unsub();
      if (typeof window !== "undefined") {
        window.removeEventListener("savoir_logo_updated", handleCustomEvent);
      }
    };
  }, []);

  return logo;
}

export function useOfficialSignature(): string {
  const [signature, setSignature] = useState<string>(() => getOfficialSignature());

  useEffect(() => {
    setSignature(getOfficialSignature());
    const unsub = subscribeToSignatureChange((newSig) => {
      setSignature(newSig);
    });

    const handleCustomEvent = (e: Event) => {
      const customEvent = e as CustomEvent<string>;
      if (customEvent.detail) {
        setSignature(customEvent.detail);
      } else {
        setSignature(getOfficialSignature());
      }
    };

    if (typeof window !== "undefined") {
      window.addEventListener("savoir_signature_updated", handleCustomEvent);
    }

    return () => {
      unsub();
      if (typeof window !== "undefined") {
        window.removeEventListener("savoir_signature_updated", handleCustomEvent);
      }
    };
  }, []);

  return signature;
}

export function getAppLogo(): string {
  return cachedLogoUrl || appLogo;
}

export function getOfficialSignature(): string {
  return cachedSignatureUrl || officialSignature;
}

export async function syncLogoWithRemote(): Promise<string> {
  if (isSupabaseActive()) {
    try {
      const supaConfig = await getAppConfigFromSupabase();
      if (supaConfig?.logoUrl && (supaConfig.logoUrl.startsWith("data:image") || supaConfig.logoUrl.startsWith("http"))) {
        setAppLogo(supaConfig.logoUrl);
        return supaConfig.logoUrl;
      }
    } catch (err) {
      console.warn("Could not sync custom logo from Supabase app_config:", err);
    }
  }

  // Tente le téléchargement direct depuis le bucket Supabase Storage
  const cachedFromStorage = await downloadAndCacheLogo();
  return cachedFromStorage || getAppLogo();
}

export async function syncSignatureWithRemote(): Promise<string> {
  if (isSupabaseActive()) {
    try {
      const supaConfig = await getAppConfigFromSupabase();
      if (supaConfig?.officialSignature && (supaConfig.officialSignature.startsWith("data:image") || supaConfig.officialSignature.startsWith("http"))) {
        setOfficialSignature(supaConfig.officialSignature);
        return supaConfig.officialSignature;
      }
    } catch (err) {
      console.warn("Could not sync signature from Supabase:", err);
    }
  }
  return getOfficialSignature();
}

export const syncLogoWithFirebase = syncLogoWithRemote;
export const syncSignatureWithFirebase = syncSignatureWithRemote;

export async function saveCustomLogoToRemote(dataUrl: string): Promise<void> {
  setAppLogo(dataUrl);

  if (isSupabaseActive()) {
    await saveAppConfigToSupabase({ logoUrl: dataUrl }).catch((err) =>
      console.warn("[Supabase] Logo save warning:", err)
    );
  }
}

export async function saveCustomSignatureToRemote(dataUrl: string): Promise<void> {
  setOfficialSignature(dataUrl);

  if (isSupabaseActive()) {
    await saveAppConfigToSupabase({ officialSignature: dataUrl }).catch((err) =>
      console.warn("[Supabase] Official signature save warning:", err)
    );
  }
}

export function getFavicon(): string {
  return cachedFaviconUrl || "/favicon.ico";
}

export function setFavicon(url: string): void {
  if (!url) return;
  cachedFaviconUrl = url;
  if (typeof window !== "undefined") {
    try {
      localStorage.setItem(FAVICON_STORAGE_KEY, url);
      window.dispatchEvent(new CustomEvent("gma_favicon_updated", { detail: url }));
    } catch (e) {}
  }
  applyFaviconToDom(url);
  faviconListeners.forEach((fn) => {
    try { fn(url); } catch (err) {}
  });
}

export function useFavicon(): string {
  const [favicon, setFaviconState] = useState<string>(() => getFavicon());
  useEffect(() => {
    setFaviconState(getFavicon());
    const unsub = subscribeToFaviconChange((newFav) => setFaviconState(newFav));
    const handleEvent = (e: Event) => {
      const customEvent = e as CustomEvent<string>;
      setFaviconState(customEvent.detail || getFavicon());
    };
    if (typeof window !== "undefined") {
      window.addEventListener("gma_favicon_updated", handleEvent);
    }
    return () => {
      unsub();
      if (typeof window !== "undefined") {
        window.removeEventListener("gma_favicon_updated", handleEvent);
      }
    };
  }, []);
  return favicon;
}

export function getPwaIcon192(): string {
  return cachedPwa192Url || "/logo-192.png";
}

export function setPwaIcon192(url: string): void {
  if (!url) return;
  cachedPwa192Url = url;
  if (typeof window !== "undefined") {
    try {
      localStorage.setItem(PWA_192_STORAGE_KEY, url);
      window.dispatchEvent(new CustomEvent("gma_pwa_192_updated", { detail: url }));
    } catch (e) {}
  }
  applyPwa192ToDom(url);
  pwa192Listeners.forEach((fn) => {
    try { fn(url); } catch (err) {}
  });
}

export function usePwaIcon192(): string {
  const [icon, setIconState] = useState<string>(() => getPwaIcon192());
  useEffect(() => {
    setIconState(getPwaIcon192());
    const unsub = subscribeToPwa192Change((newIcon) => setIconState(newIcon));
    const handleEvent = (e: Event) => {
      const customEvent = e as CustomEvent<string>;
      setIconState(customEvent.detail || getPwaIcon192());
    };
    if (typeof window !== "undefined") {
      window.addEventListener("gma_pwa_192_updated", handleEvent);
    }
    return () => {
      unsub();
      if (typeof window !== "undefined") {
        window.removeEventListener("gma_pwa_192_updated", handleEvent);
      }
    };
  }, []);
  return icon;
}

export function getPwaIcon512(): string {
  return cachedPwa512Url || "/logo.png";
}

export function setPwaIcon512(url: string): void {
  if (!url) return;
  cachedPwa512Url = url;
  if (typeof window !== "undefined") {
    try {
      localStorage.setItem(PWA_512_STORAGE_KEY, url);
      window.dispatchEvent(new CustomEvent("gma_pwa_512_updated", { detail: url }));
    } catch (e) {}
  }
  applyPwa512ToDom(url);
  pwa512Listeners.forEach((fn) => {
    try { fn(url); } catch (err) {}
  });
}

export function usePwaIcon512(): string {
  const [icon, setIconState] = useState<string>(() => getPwaIcon512());
  useEffect(() => {
    setIconState(getPwaIcon512());
    const unsub = subscribeToPwa512Change((newIcon) => setIconState(newIcon));
    const handleEvent = (e: Event) => {
      const customEvent = e as CustomEvent<string>;
      setIconState(customEvent.detail || getPwaIcon512());
    };
    if (typeof window !== "undefined") {
      window.addEventListener("gma_pwa_512_updated", handleEvent);
    }
    return () => {
      unsub();
      if (typeof window !== "undefined") {
        window.removeEventListener("gma_pwa_512_updated", handleEvent);
      }
    };
  }, []);
  return icon;
}

export async function syncFaviconWithRemote(): Promise<string> {
  if (isSupabaseActive()) {
    try {
      const { supabase } = await import("../lib/supabaseClient");
      if (supabase) {
        // 1. SELECT prioritaire sur la table 'system_settings' (accessible publiquement)
        const { data: rows, error } = await supabase
          .from("system_settings")
          .select("id, favicon_url, updated_at")
          .order("updated_at", { ascending: false })
          .limit(1);

        if (!error && rows && rows.length > 0 && rows[0]?.favicon_url) {
          const remoteFav = rows[0].favicon_url.trim();
          if (remoteFav) {
            setFavicon(remoteFav);
            applyFaviconToDom(remoteFav);
            return remoteFav;
          }
        }

        // Fallback sans tri si la colonne updated_at n'est pas indexée
        const { data: fallbackRows } = await supabase
          .from("system_settings")
          .select("id, favicon_url")
          .limit(1);

        if (fallbackRows && fallbackRows.length > 0 && fallbackRows[0]?.favicon_url) {
          const remoteFav = fallbackRows[0].favicon_url.trim();
          if (remoteFav) {
            setFavicon(remoteFav);
            applyFaviconToDom(remoteFav);
            return remoteFav;
          }
        }
      }
    } catch (err) {
      console.warn("[Favicon] Erreur lors de la lecture de system_settings:", err);
    }

    // 2. Fallback via app_settings ou app_config
    try {
      const supaConfig = await getAppConfigFromSupabase();
      if (supaConfig?.faviconUrl && supaConfig.faviconUrl.trim() !== "") {
        const fav = supaConfig.faviconUrl.trim();
        setFavicon(fav);
        applyFaviconToDom(fav);
        return fav;
      }
    } catch (err) {
      console.warn("Could not sync favicon from app_config:", err);
    }
  }

  // 3. Fallback sur le cache local immédiat
  const current = getFavicon();
  applyFaviconToDom(current);
  return current;
}

export async function syncPwaIconsWithRemote(): Promise<{ icon192: string; icon512: string }> {
  if (isSupabaseActive()) {
    try {
      const { supabase } = await import("../lib/supabaseClient");
      if (supabase) {
        const { data: rows } = await supabase
          .from("system_settings")
          .select("id, pwa_icon_url, pwa_icon_192_url, pwa_icon_512_url, logo_url")
          .order("updated_at", { ascending: false })
          .limit(1);

        if (rows && rows.length > 0) {
          const r = rows[0];
          const i192 = r.pwa_icon_192_url || r.pwa_icon_url;
          const i512 = r.pwa_icon_512_url || r.logo_url || r.pwa_icon_url;
          if (i192) {
            setPwaIcon192(i192);
            applyPwa192ToDom(i192);
          }
          if (i512) {
            setPwaIcon512(i512);
            applyPwa512ToDom(i512);
          }
          // Dynamically refresh Web App Manifest Blob with Supabase icon URLs
          try {
            const { updateDynamicManifest } = await import("./dynamicManifest");
            updateDynamicManifest({ icon192: i192 || undefined, icon512: i512 || undefined });
          } catch {}
        }
      }
    } catch {}
  }
  return { icon192: getPwaIcon192(), icon512: getPwaIcon512() };
}

export async function saveCustomFaviconToRemote(dataUrl: string): Promise<void> {
  if (!dataUrl) return;
  // 1. Sauvegarde locale synchrone immédiate (0ms, survit aux refresh)
  setFavicon(dataUrl);
  applyFaviconToDom(dataUrl);

  if (isSupabaseActive()) {
    try {
      const { supabase } = await import("../lib/supabaseClient");
      if (supabase) {
        const now = Date.now();
        let updated = false;

        // ÉTAPE 1 : Récupération de l'enregistrement actif dans system_settings (ex: id = 1 ou id = 'main')
        const { data: existingRows } = await supabase
          .from("system_settings")
          .select("id")
          .limit(1);

        if (existingRows && existingRows.length > 0) {
          const existingId = existingRows[0].id;
          // UPDATE ciblé sur la ligne existante
          const { error: updErr } = await supabase
            .from("system_settings")
            .update({
              favicon_url: dataUrl,
              updated_at: now,
            })
            .eq("id", existingId);

          if (!updErr) updated = true;
        }

        // ÉTAPE 2 : Si aucun ID spécifique ou si l'update a échoué, mise à jour globale
        if (!updated) {
          const { error: updAllErr } = await supabase
            .from("system_settings")
            .update({
              favicon_url: dataUrl,
              updated_at: now,
            })
            .neq("id", "dummy_unmatched_id_000000");

          if (!updAllErr) updated = true;
        }

        // ÉTAPE 3 : Si la table est complètement vide, insertion par UPSERT (id: 1 puis id: 'main')
        if (!updated) {
          const { error: upsert1Err } = await supabase
            .from("system_settings")
            .upsert({
              id: 1,
              favicon_url: dataUrl,
              updated_at: now,
            });

          if (!upsert1Err) {
            updated = true;
          } else {
            try {
              await supabase
                .from("system_settings")
                .upsert({
                  id: "main",
                  favicon_url: dataUrl,
                  updated_at: now,
                });
            } catch {}
          }
        }
      }
    } catch (err) {
      console.warn("[Supabase] Notice saving favicon directly to system_settings:", err);
    }

    // 2. Synchroniser également la table app_settings et app_config
    await saveAppConfigToSupabase({ faviconUrl: dataUrl }).catch((err) =>
      console.warn("[Supabase] Favicon save warning:", err)
    );
  }
}

export async function saveCustomPwaIcon192ToRemote(dataUrl: string): Promise<void> {
  setPwaIcon192(dataUrl);
  applyPwa192ToDom(dataUrl);

  // Invalidate Service Worker cache and refresh dynamic manifest link immediately
  try {
    const { invalidatePwaIconCache } = await import("./dynamicManifest");
    await invalidatePwaIconCache({ icon192: dataUrl });
  } catch {}

  if (isSupabaseActive()) {
    try {
      const { supabase } = await import("../lib/supabaseClient");
      if (supabase) {
        const now = Date.now();
        const { data: rows } = await supabase.from("system_settings").select("id").limit(1);
        if (rows && rows.length > 0) {
          await supabase
            .from("system_settings")
            .update({ pwa_icon_192_url: dataUrl, pwa_icon_url: dataUrl, updated_at: now })
            .eq("id", rows[0].id);
        } else {
          try {
            await supabase
              .from("system_settings")
              .upsert({ id: 1, pwa_icon_192_url: dataUrl, pwa_icon_url: dataUrl, updated_at: now });
          } catch {}
        }
      }
    } catch {}
    await saveAppConfigToSupabase({ pwaIcon192Url: dataUrl }).catch((err) =>
      console.warn("[Supabase] PWA 192 save warning:", err)
    );
  }
}

export async function saveCustomPwaIcon512ToRemote(dataUrl: string): Promise<void> {
  setPwaIcon512(dataUrl);
  applyPwa512ToDom(dataUrl);

  // Invalidate Service Worker cache and refresh dynamic manifest link immediately
  try {
    const { invalidatePwaIconCache } = await import("./dynamicManifest");
    await invalidatePwaIconCache({ icon512: dataUrl });
  } catch {}

  if (isSupabaseActive()) {
    try {
      const { supabase } = await import("../lib/supabaseClient");
      if (supabase) {
        const now = Date.now();
        const { data: rows } = await supabase.from("system_settings").select("id").limit(1);
        if (rows && rows.length > 0) {
          await supabase
            .from("system_settings")
            .update({ pwa_icon_512_url: dataUrl, updated_at: now })
            .eq("id", rows[0].id);
        } else {
          try {
            await supabase
              .from("system_settings")
              .upsert({ id: 1, pwa_icon_512_url: dataUrl, updated_at: now });
          } catch {}
        }
      }
    } catch {}
    await saveAppConfigToSupabase({ pwaIcon512Url: dataUrl }).catch((err) =>
      console.warn("[Supabase] PWA 512 save warning:", err)
    );
  }
}

export const saveCustomLogoToFirebase = saveCustomLogoToRemote;
export const saveLogoToFirebase = saveCustomLogoToRemote;
export const saveCustomSignatureToFirebase = saveCustomSignatureToRemote;
export const saveSignatureToFirebase = saveCustomSignatureToRemote;

/**
 * Uploads an app asset (logo, favicon, icon192, icon512, signature) to Supabase Storage.
 */
export async function uploadCustomAssetToSupabase(
  file: File | Blob,
  assetType: "logo" | "favicon" | "icon192" | "icon512" | "signature"
): Promise<string | null> {
  const { uploadAppLogoToSupabase } = await import("../data/supabaseStorage");
  const { supabase } = await import("../lib/supabaseClient");
  if (!supabase) return null;

  try {
    const rawName = (file as File).name || `${assetType}.png`;
    const fileExt = (rawName.split(".").pop() || "png").toLowerCase().replace(/[^a-z0-9]/g, "") || "png";
    const fileName = `${assetType}_${Date.now()}.${fileExt}`;

    let publicUrl: string | null = null;

    // 1. Essai sur le bucket 'app_assets'
    const { error: err1 } = await supabase.storage
      .from("app_assets")
      .upload(`icons/${fileName}`, file, {
        cacheControl: "3600",
        upsert: true,
      });

    if (!err1) {
      const { data } = supabase.storage.from("app_assets").getPublicUrl(`icons/${fileName}`);
      publicUrl = data?.publicUrl || null;
    } else {
      // 2. Fallback sur le bucket 'avatars'
      const { error: err2 } = await supabase.storage
        .from("avatars")
        .upload(`app_${fileName}`, file, {
          cacheControl: "3600",
          upsert: true,
        });
      if (!err2) {
        const { data: pData } = supabase.storage.from("avatars").getPublicUrl(`app_${fileName}`);
        publicUrl = pData?.publicUrl || null;
      }
    }

    if (!publicUrl) return null;

    // Persistance immédiate selon le type d'asset
    if (assetType === "logo") {
      await saveCustomLogoToRemote(publicUrl);
    } else if (assetType === "favicon") {
      await saveCustomFaviconToRemote(publicUrl);
    } else if (assetType === "icon192") {
      await saveCustomPwaIcon192ToRemote(publicUrl);
    } else if (assetType === "icon512") {
      await saveCustomPwaIcon512ToRemote(publicUrl);
    } else if (assetType === "signature") {
      await saveCustomSignatureToRemote(publicUrl);
    }

    return publicUrl;
  } catch (err) {
    console.warn(`[Supabase Storage] Erreur upload ${assetType}:`, err);
    return null;
  }
}

