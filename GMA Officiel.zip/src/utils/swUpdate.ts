// Service Worker Auto-Update & Cache Management Utility for Génie Mentor Académie (GMA)

let currentRegistration: ServiceWorkerRegistration | null = null;
let waitingWorkerRegistration: ServiceWorkerRegistration | null = null;
let isUpdateReady = false;
let isReloading = false;

const updateListeners = new Set<(hasUpdate: boolean, registration: ServiceWorkerRegistration | null) => void>();

function notifyUpdateListeners(hasUpdate: boolean, reg: ServiceWorkerRegistration | null) {
  isUpdateReady = hasUpdate;
  if (hasUpdate && reg) {
    waitingWorkerRegistration = reg;
  }
  updateListeners.forEach((listener) => {
    try {
      listener(hasUpdate, reg);
    } catch (err) {
      console.warn("Error in SW update listener:", err);
    }
  });
}

/**
 * Subscribe to update availability events
 */
export function subscribeToUpdateAvailable(
  callback: (hasUpdate: boolean, registration: ServiceWorkerRegistration | null) => void
): () => void {
  updateListeners.add(callback);
  // Immediate callback with current state
  callback(isUpdateReady, waitingWorkerRegistration || currentRegistration);
  return () => {
    updateListeners.delete(callback);
  };
}

/**
 * Check if the URL represents an image asset that must be preserved
 */
function isImageUrl(url: string): boolean {
  const lower = url.toLowerCase();
  return (
    /\.(png|jpg|jpeg|webp|gif|svg|ico)($|\?)/i.test(lower) ||
    lower.includes("/assets/images/") ||
    lower.includes("/storage/v1/object/public/") ||
    lower.includes("logo") ||
    lower.includes("signature")
  );
}

/**
 * Nettoie les caches d'application pour charger les derniers fichiers JS/CSS
 * sans toucher aux données locales de session (localStorage, sessionStorage, IndexedDB)
 * ni altérer les images.
 */
export async function cleanAppCodeCaches(forceAll = false): Promise<void> {
  if (typeof window === "undefined" || !("caches" in window)) {
    return;
  }

  try {
    const cacheNames = await window.caches.keys();
    await Promise.all(
      cacheNames.map(async (name) => {
        try {
          if (forceAll) {
            await window.caches.delete(name);
          } else {
            const cache = await window.caches.open(name);
            const requests = await cache.keys();
            
            await Promise.all(
              requests.map(async (request) => {
                const url = request.url;
                // Only delete HTML, JS, CSS, JSON bundles, but preserve images!
                if (!isImageUrl(url)) {
                  await cache.delete(request);
                }
              })
            );
          }
        } catch (err) {
          console.warn(`Error cleaning cache ${name}:`, err);
        }
      })
    );
    console.log("App code caches successfully cleaned while preserving session data.");
  } catch (error) {
    console.warn("Notice while cleaning app code caches:", error);
  }
}

/**
 * Purge complètement les caches du Service Worker (caches.delete())
 * pour forcer le téléchargement des nouveaux fichiers sans altérer le profil utilisateur / session.
 */
export async function purgeServiceWorkerCaches(): Promise<void> {
  if (typeof window === "undefined") return;

  if ("caches" in window) {
    try {
      const cacheNames = await window.caches.keys();
      await Promise.all(
        cacheNames.map((name) => window.caches.delete(name))
      );
      console.log("[SW] All service worker caches successfully purged via caches.delete()");
    } catch (err) {
      console.warn("[SW] Notice while purging service worker caches:", err);
    }
  }

  if ("serviceWorker" in navigator) {
    try {
      const registrations = await navigator.serviceWorker.getRegistrations();
      for (const reg of registrations) {
        if (reg.waiting) {
          reg.waiting.postMessage({ type: "SKIP_WAITING" });
        }
        await reg.update().catch(() => {});
      }
    } catch (err) {
      console.warn("[SW] Notice updating registrations after cache purge:", err);
    }
  }
}

/**
 * Applique la mise à jour :
 * 1. Envoie le signal SKIP_WAITING au Service Worker en attente
 * 2. Purge les caches JS/CSS/HTML via caches.delete()
 * 3. Écoute 'controllerchange' pour recharger la page
 */
export async function applyServiceWorkerUpdate(customReg?: ServiceWorkerRegistration | null): Promise<void> {
  if (typeof window === "undefined") return;

  const targetReg = customReg || waitingWorkerRegistration || currentRegistration;

  // Step 1: Purge all application code caches
  try {
    await purgeServiceWorkerCaches();
  } catch (err) {
    console.warn("Could not purge caches before update:", err);
  }

  // Set up controllerchange listener to reload immediately when new SW takes control
  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.addEventListener("controllerchange", () => {
      if (!isReloading) {
        isReloading = true;
        window.location.reload();
      }
    });
  }

  // Step 2: Post SKIP_WAITING message to waiting worker
  let messageSent = false;

  if (targetReg && targetReg.waiting) {
    targetReg.waiting.postMessage({ type: "SKIP_WAITING" });
    messageSent = true;
    console.log("Sent SKIP_WAITING to targetReg.waiting");
  }

  // Check all registrations if needed
  if (!messageSent && "serviceWorker" in navigator) {
    try {
      const reg = await navigator.serviceWorker.getRegistration();
      if (reg && reg.waiting) {
        reg.waiting.postMessage({ type: "SKIP_WAITING" });
        messageSent = true;
        console.log("Sent SKIP_WAITING to navigator.serviceWorker.getRegistration().waiting");
      }
    } catch (e) {
      console.warn("Error finding waiting worker:", e);
    }
  }

  // Fallback timeout: if controllerchange doesn't fire within 1500ms, reload anyway
  setTimeout(() => {
    if (!isReloading) {
      isReloading = true;
      window.location.reload();
    }
  }, 1500);
}

/**
 * Manual trigger for checking service worker updates
 */
export async function checkServiceWorkerForUpdate(): Promise<boolean> {
  if (typeof window === "undefined" || !("serviceWorker" in navigator)) {
    return false;
  }

  try {
    const reg = await navigator.serviceWorker.getRegistration();
    if (!reg) return false;

    currentRegistration = reg;

    if (reg.waiting) {
      notifyUpdateListeners(true, reg);
      return true;
    }

    await reg.update();

    if (reg.waiting) {
      notifyUpdateListeners(true, reg);
      return true;
    }

    return false;
  } catch (err) {
    console.warn("ServiceWorker update check error:", err);
    return false;
  }
}

/**
 * Initialise la détection automatique des mises à jour du Service Worker
 * Au chargement, vérifie s'il existe une nouvelle version (registration.update())
 * et alerte l'UI dès qu'un nouveau Service Worker est installé en arrière-plan.
 */
export function initServiceWorkerAutoUpdate(
  onUpdateAvailable?: (reg: ServiceWorkerRegistration) => void
): () => void {
  if (typeof window === "undefined" || !("serviceWorker" in navigator)) {
    return () => {};
  }

  if (onUpdateAvailable) {
    subscribeToUpdateAvailable((hasUpdate, reg) => {
      if (hasUpdate && reg) {
        onUpdateAvailable(reg);
      }
    });
  }

  // Listen to controllerchange globally
  navigator.serviceWorker.addEventListener("controllerchange", () => {
    if (!isReloading) {
      isReloading = true;
      window.location.reload();
    }
  });

  // Écoute les signaux envoyés par le Service Worker lorsqu'une nouvelle version est activée
  navigator.serviceWorker.addEventListener("message", (event) => {
    if (event.data && (event.data.type === "NEW_VERSION_ACTIVATED" || event.data.type === "RELOAD_PAGE")) {
      if (!isReloading) {
        isReloading = true;
        cleanAppCodeCaches(true).finally(() => {
          window.location.reload();
        });
      }
    }
  });

  const setupRegistrationListeners = (registration: ServiceWorkerRegistration) => {
    currentRegistration = registration;

    // 1. If a worker is already waiting, an update is ready! Auto-apply immediately.
    if (registration.waiting) {
      console.log("A service worker is already waiting. Auto-applying update...");
      notifyUpdateListeners(true, registration);
      applyServiceWorkerUpdate(registration).catch(() => {});
    }

    // 2. Listen for newly discovered updates
    registration.addEventListener("updatefound", () => {
      const newWorker = registration.installing;
      if (!newWorker) return;

      console.log("New Service Worker found installing in background...");

      newWorker.addEventListener("statechange", () => {
        if (newWorker.state === "installed") {
          if (navigator.serviceWorker.controller) {
            console.log("New Service Worker successfully installed! Forcing update...");
            notifyUpdateListeners(true, registration);
            // Force immediate reload to deliver new features
            applyServiceWorkerUpdate(registration).catch(() => {});
          } else {
            console.log("Service Worker installed for the first time on this device.");
          }
        }
      });
    });

    // 3. Trigger immediate check on server
    registration.update().catch((err) => {
      console.warn("Initial registration.update() notice:", err);
    });
  };

  const registerSW = () => {
    navigator.serviceWorker
      .register("/sw.js")
      .then((reg) => {
        setupRegistrationListeners(reg);
      })
      .catch((err) => {
        console.warn("SW registration error:", err);
      });
  };

  if (document.readyState === "complete") {
    registerSW();
  } else {
    window.addEventListener("load", registerSW, { once: true });
  }

  // Periodic check when the app returns to foreground (user switches back to tab or app)
  const handleVisibilityChange = () => {
    if (document.visibilityState === "visible" && currentRegistration) {
      currentRegistration.update().catch(() => {});
    }
  };
  document.addEventListener("visibilitychange", handleVisibilityChange);

  // Periodic timer check (every 30 minutes)
  const intervalId = setInterval(() => {
    if (currentRegistration) {
      currentRegistration.update().catch(() => {});
    }
  }, 30 * 60 * 1000);

  return () => {
    document.removeEventListener("visibilitychange", handleVisibilityChange);
    clearInterval(intervalId);
  };
}
