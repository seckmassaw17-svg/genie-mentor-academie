import { UserProfile, StudentRecord } from "../types";

export const ADMIN_EMAILS = [
  "massperpendiculaire@gmail.com",
  "massaw.seck@unchk.edu.sn",
  "massaw.savoirplus@gmail.com",
];

export interface VIPPlanOption {
  id: "1mois" | "3mois" | "6mois" | "1an" | "illimite";
  durationLabel: string;
  priceFCFA: number;
  periodText: string;
  durationMs: number; // -1 for lifetime
  badge?: string;
}

export const VIP_PLANS: VIPPlanOption[] = [
  {
    id: "1mois",
    durationLabel: "1 Mois",
    priceFCFA: 1000,
    periodText: "Valable 30 jours",
    durationMs: 30 * 24 * 60 * 60 * 1000,
  },
  {
    id: "3mois",
    durationLabel: "3 Mois",
    priceFCFA: 2000,
    periodText: "Valable 90 jours (Trimestre)",
    durationMs: 90 * 24 * 60 * 60 * 1000,
    badge: "Populaire 🔥",
  },
  {
    id: "6mois",
    durationLabel: "6 Mois",
    priceFCFA: 4500,
    periodText: "Valable 180 jours (Semestre)",
    durationMs: 180 * 24 * 60 * 60 * 1000,
    badge: "Idéal Semestre 🚀",
  },
  {
    id: "1an",
    durationLabel: "1 An",
    priceFCFA: 8000,
    periodText: "Valable 365 jours (Année Scolaire)",
    durationMs: 365 * 24 * 60 * 60 * 1000,
    badge: "Recommandé 🎓",
  },
  {
    id: "illimite",
    durationLabel: "Illimité",
    priceFCFA: 20000,
    periodText: "Accès à vie sans expiration",
    durationMs: -1,
    badge: "Pack Élite 👑",
  },
];

export function isUserAdmin(user: { email?: string; isAdmin?: boolean; role?: string } | null | undefined): boolean {
  if (!user) return false;
  const cleanEmail = (user.email || "").trim().toLowerCase();
  // Exclusion stricte de massauseck@unchk.edu.sn
  if (cleanEmail === "massauseck@unchk.edu.sn") return false;
  // Les 3 administrateurs autorisés
  if (ADMIN_EMAILS.includes(cleanEmail)) return true;
  if (cleanEmail === "massperpendiculaire@gmail.com" || cleanEmail === "massaw.seck@unchk.edu.sn" || cleanEmail === "massaw.savoirplus@gmail.com") return true;
  if (user.role === "admin" && cleanEmail !== "massauseck@unchk.edu.sn") return true;
  if (user.isAdmin && cleanEmail !== "massauseck@unchk.edu.sn") return true;
  return false;
}

export function isUserVIP(user: { email?: string; isAdmin?: boolean; isVIP?: boolean; vipExpiresAt?: number } | null | undefined): boolean {
  if (!user) return false;
  if (isUserAdmin(user)) return true;
  if (!user.isVIP) return false;
  if (user.vipExpiresAt === undefined || user.vipExpiresAt === -1) return true;
  return user.vipExpiresAt > Date.now();
}

export interface VipStatusInfo {
  isActive: boolean;
  isAdminUser: boolean;
  statusLabel: string;
  planLabel: string;
  expirationFormatted: string;
  daysRemaining?: number;
  isExpired: boolean;
}

export function getVipStatusInfo(user: { email?: string; isAdmin?: boolean; isVIP?: boolean; vipExpiresAt?: number; vipPlan?: string } | null | undefined): VipStatusInfo {
  if (!user) {
    return {
      isActive: false,
      isAdminUser: false,
      statusLabel: "Non Abonné",
      planLabel: "Aucun",
      expirationFormatted: "Pass VIP non activé",
      isExpired: false,
    };
  }

  if (isUserAdmin(user)) {
    return {
      isActive: true,
      isAdminUser: true,
      statusLabel: "Accès Administrateur",
      planLabel: "Super Admin",
      expirationFormatted: "Permanent (Accès total illimité)",
      isExpired: false,
    };
  }

  if (!user.isVIP) {
    return {
      isActive: false,
      isAdminUser: false,
      statusLabel: "Pass VIP Non Activé",
      planLabel: "Aucun",
      expirationFormatted: "Pass VIP non activé",
      isExpired: false,
    };
  }

  if (user.vipExpiresAt === undefined || user.vipExpiresAt === -1) {
    return {
      isActive: true,
      isAdminUser: false,
      statusLabel: "Pass VIP Illimité",
      planLabel: "Illimité",
      expirationFormatted: "Accès permanent (À vie)",
      isExpired: false,
    };
  }

  const now = Date.now();
  if (user.vipExpiresAt > now) {
    const diffMs = user.vipExpiresAt - now;
    const daysRemaining = Math.max(1, Math.ceil(diffMs / (1000 * 60 * 60 * 24)));
    const dateStr = new Date(user.vipExpiresAt).toLocaleDateString("fr-FR", {
      day: "2-digit",
      month: "long",
      year: "numeric",
    });
    return {
      isActive: true,
      isAdminUser: false,
      statusLabel: `Pass VIP Actif (${daysRemaining} j restant${daysRemaining > 1 ? "s" : ""})`,
      planLabel: user.vipPlan || "Pass Actif",
      expirationFormatted: `Valable jusqu'au ${dateStr}`,
      daysRemaining,
      isExpired: false,
    };
  }

  const expiredDateStr = new Date(user.vipExpiresAt).toLocaleDateString("fr-FR", {
    day: "2-digit",
    month: "long",
    year: "numeric",
  });
  return {
    isActive: false,
    isAdminUser: false,
    statusLabel: "Pass VIP Expiré",
    planLabel: user.vipPlan || "Expiré",
    expirationFormatted: `Expiré depuis le ${expiredDateStr}`,
    daysRemaining: 0,
    isExpired: true,
  };
}

export function computeExpirationTimestamp(planId?: string | null, customDays?: number): number {
  if (customDays && customDays > 0) {
    return Date.now() + customDays * 24 * 60 * 60 * 1000;
  }
  if (planId === "illimite") {
    return -1; // Lifetime
  }
  const plan = VIP_PLANS.find((p) => p.id === planId);
  if (!plan) {
    return Date.now() + 30 * 24 * 60 * 60 * 1000; // default 1 month
  }
  if (plan.durationMs === -1) {
    return -1; // Lifetime
  }
  return Date.now() + plan.durationMs;
}

export interface VipCountdownResult {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
  totalSeconds: number;
  formattedText: string;
  shortText: string;
  isExpired: boolean;
  isLifetime: boolean;
}

export function formatVipCountdown(vipExpiresAt?: number | null): VipCountdownResult {
  if (vipExpiresAt === undefined || vipExpiresAt === null || vipExpiresAt === -1) {
    return {
      days: 0,
      hours: 0,
      minutes: 0,
      seconds: 0,
      totalSeconds: -1,
      formattedText: "Accès Illimité (À vie)",
      shortText: "Illimité",
      isExpired: false,
      isLifetime: true,
    };
  }

  const now = Date.now();
  const diffMs = vipExpiresAt - now;

  if (diffMs <= 0) {
    return {
      days: 0,
      hours: 0,
      minutes: 0,
      seconds: 0,
      totalSeconds: 0,
      formattedText: "Abonnement VIP Expiré",
      shortText: "Expiré",
      isExpired: true,
      isLifetime: false,
    };
  }

  const totalSeconds = Math.floor(diffMs / 1000);
  const days = Math.floor(totalSeconds / (24 * 3600));
  const hours = Math.floor((totalSeconds % (24 * 3600)) / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  const formattedText = `${days}j ${hours.toString().padStart(2, "0")}h ${minutes.toString().padStart(2, "0")}m ${seconds.toString().padStart(2, "0")}s restants`;
  const shortText = `${days}j ${hours}h restants`;

  return {
    days,
    hours,
    minutes,
    seconds,
    totalSeconds,
    formattedText,
    shortText,
    isExpired: false,
    isLifetime: false,
  };
}
