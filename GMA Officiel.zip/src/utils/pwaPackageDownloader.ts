import JSZip from 'jszip';

/**
 * Generates and downloads the PWA application package (.zip) directly in the browser's memory
 * using a Blob URL. This bypasses all server redirects, cross-origin checks, and cookie blocks!
 */
export async function downloadPwaApplicationPackage(onProgress?: (step: string) => void): Promise<boolean> {
  try {
    onProgress?.("Préparation du dossier de l'application PWA...");
    const zip = new JSZip();

    // 1. Manifest PWA
    const manifestContent = JSON.stringify(
      {
        id: "/",
        name: "Génie Mentor Académie",
        short_name: "GMA",
        description: "Plateforme éducative de soutien scolaire, cours, exercices corrigés et concours d'excellence au Sénégal - Génie Mentor Académie.",
        start_url: "/",
        scope: "/",
        display: "standalone",
        orientation: "portrait",
        background_color: "#0f172a",
        theme_color: "#1e3a8a",
        lang: "fr",
        icons: [
          {
            src: "icons/icon-192.png",
            sizes: "192x192",
            type: "image/png",
            purpose: "any maskable"
          },
          {
            src: "icons/icon-512.png",
            sizes: "512x512",
            type: "image/png",
            purpose: "any maskable"
          }
        ]
      },
      null,
      2
    );
    zip.file("manifest.json", manifestContent);

    // 2. Service Worker offline
    const swContent = `// Service Worker Génie Mentor Académie (GMA PWA Offline)
const CACHE_NAME = 'gma-pwa-v2.5.0';
const ASSETS_TO_CACHE = [
  '/',
  '/index.html',
  '/manifest.json',
  '/GUIDE_INSTALLATION.html'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(ASSETS_TO_CACHE).catch(() => {});
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME) {
            return caches.delete(key);
          }
        })
      )
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;
  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      if (cachedResponse) {
        return cachedResponse;
      }
      return fetch(event.request).catch(() => {
        return caches.match('/index.html');
      });
    })
  );
});
`;
    zip.file("sw.js", swContent);

    // 3. Fichier HTML Lanceur Hors-Ligne (Offline Web App Runner)
    const indexHtmlContent = `<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Génie Mentor Académie (GMA) • Application PWA</title>
  <link rel="manifest" href="manifest.json">
  <meta name="theme-color" content="#1e3a8a">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
  <meta name="apple-mobile-web-app-title" content="GMA">
  <style>
    body {
      margin: 0;
      padding: 0;
      font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      background: #0f172a;
      color: #f8fafc;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      text-align: center;
      padding: 24px;
      box-sizing: border-box;
    }
    .card {
      background: #1e293b;
      border: 1px solid #334155;
      border-radius: 20px;
      padding: 32px 24px;
      max-width: 440px;
      width: 100%;
      box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.5);
    }
    .logo {
      width: 80px;
      height: 80px;
      background: #1e3a8a;
      border-radius: 20px;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      font-size: 26px;
      font-weight: 900;
      color: #fbbf24;
      margin-bottom: 20px;
      border: 2px solid #fbbf24;
    }
    h1 {
      font-size: 22px;
      margin: 0 0 10px;
      color: #ffffff;
    }
    p {
      font-size: 14px;
      line-height: 1.5;
      color: #94a3b8;
      margin: 0 0 24px;
    }
    .btn {
      display: block;
      width: 100%;
      padding: 14px;
      background: #fbbf24;
      color: #0f172a;
      border-radius: 12px;
      font-weight: bold;
      text-decoration: none;
      font-size: 15px;
      margin-bottom: 12px;
      box-sizing: border-box;
      transition: transform 0.1s ease;
    }
    .btn:active {
      transform: scale(0.98);
    }
    .btn-secondary {
      background: #334155;
      color: #f8fafc;
    }
    .badge {
      display: inline-block;
      padding: 4px 10px;
      border-radius: 999px;
      font-size: 11px;
      font-weight: 700;
      background: rgba(251, 191, 36, 0.15);
      color: #fbbf24;
      margin-bottom: 16px;
    }
  </style>
</head>
<body>
  <div class="card">
    <div class="logo">GMA</div>
    <span class="badge">Application PWA Installée</span>
    <h1>Génie Mentor Académie</h1>
    <p>Votre application éducative complète est prête à être exécutée. Ajoutez-la au menu de votre téléphone pour y accéder d'un simple clic.</p>
    <a href="./index.html" class="btn">Lancer l'application GMA</a>
    <a href="GUIDE_INSTALLATION.html" class="btn btn-secondary">Consulter le Guide d'installation</a>
  </div>

  <script>
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('sw.js').catch(console.warn);
    }
  </script>
</body>
</html>`;
    zip.file("index.html", indexHtmlContent);

    // 4. Guide d'installation illustré complet
    const guideHtml = `<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Guide d'installation • Génie Mentor Académie (GMA)</title>
  <style>
    body {
      font-family: system-ui, -apple-system, sans-serif;
      background: #0f172a;
      color: #e2e8f0;
      line-height: 1.6;
      padding: 24px;
      margin: 0;
    }
    .container {
      max-width: 600px;
      margin: 0 auto;
      background: #1e293b;
      border-radius: 20px;
      padding: 28px;
      border: 1px solid #334155;
    }
    h1 { color: #fbbf24; font-size: 24px; margin-top: 0; }
    h2 { color: #60a5fa; font-size: 18px; margin-top: 24px; }
    .step {
      background: #0f172a;
      padding: 16px;
      border-radius: 12px;
      margin-bottom: 12px;
      border-left: 4px solid #fbbf24;
    }
    .step-num { font-weight: bold; color: #fbbf24; }
  </style>
</head>
<body>
  <div class="container">
    <h1>📲 Installation de GMA (Génie Mentor Académie) dans le menu du téléphone</h1>
    <p>La technologie <strong>PWA (Progressive Web App)</strong> vous permet d'installer GMA directement sur votre téléphone sans passer par le Play Store, sans téléchargement d'APK lourd et avec mise à jour automatique !</p>

    <h2>📱 Sur Android (Google Chrome / Samsung Internet)</h2>
    <div class="step">
      <div class="step-num">Étape 1 :</div>
      Ouvrez l'application Génie Mentor Académie dans Chrome ou votre navigateur mobile.
    </div>
    <div class="step">
      <div class="step-num">Étape 2 :</div>
      Appuyez sur le menu (les <strong>3 petits points verticaux ⋮</strong> en haut à droite).
    </div>
    <div class="step">
      <div class="step-num">Étape 3 :</div>
      Sélectionnez <strong>« Installer l'application »</strong> ou <strong>« Ajouter à l'écran d'accueil »</strong>.
    </div>
    <div class="step">
      <div class="step-num">Étape 4 :</div>
      L'icône GMA apparaît immédiatement dans le menu de vos applications et sur votre écran d'accueil !
    </div>

    <h2>🍏 Sur iPhone / iPad (Safari)</h2>
    <div class="step">
      <div class="step-num">Étape 1 :</div>
      Ouvrez GMA dans le navigateur <strong>Safari</strong>.
    </div>
    <div class="step">
      <div class="step-num">Étape 2 :</div>
      Appuyez sur le bouton <strong>Partager</strong> (le carré avec une flèche vers le haut ⎋ en bas de l'écran).
    </div>
    <div class="step">
      <div class="step-num">Étape 3 :</div>
      Faites défiler vers le bas et sélectionnez <strong>« Sur l'écran d'accueil »</strong>.
    </div>
    <div class="step">
      <div class="step-num">Étape 4 :</div>
      Validez en touchant <strong>« Ajouter »</strong> en haut à droite. Le nom affiché sous l'icône sera GMA.
    </div>
  </div>
</body>
</html>`;
    zip.file("GUIDE_INSTALLATION.html", guideHtml);

    // 5. README Textuel
    const readmeText = `=========================================================
GÉNIE MENTOR ACADÉMIE (GMA) • DOSSIER APPLICATION PWA (PACKAGE MOBILE)
=========================================================

Ce package contient l'ensemble des fichiers requis pour le déploiement et l'installation
autonome de l'application Génie Mentor Académie (GMA) sur smartphone Android, iPhone, tablette et PC.

CONTENU DU PACKAGE :
- index.html : Lanceur web optimisé pour mobile et écran tactile
- manifest.json : Descripteur d'installation PWA
- sw.js : Service Worker pour l'exécution fluide et le cache
- GUIDE_INSTALLATION.html : Guide pas-à-pas illustré pour Android et iOS

COMMENT INSTALLER SUR VOTRE TÉLÉPHONE :
1. Sur Android (Google Chrome) :
   Menu ⋮ > "Installer l'application" ou "Ajouter à l'écran d'accueil"

2. Sur iPhone (Safari) :
   Bouton Partager ⎋ > "Sur l'écran d'accueil"

Date de génération : ${new Date().toLocaleString("fr-FR")}
Version : 2.5.0 Production-Ready
Éditeur : Génie Mentor Académie (GMA)
`;
    zip.file("README_INSTALLATION.txt", readmeText);

    // 6. Informations sur le package
    zip.file(
      "package_info.json",
      JSON.stringify(
        {
          appName: "Génie Mentor Académie",
          shortName: "GMA",
          version: "2.5.0",
          type: "PWA Application Package",
          releaseDate: new Date().toISOString(),
          targetPlatforms: ["Android", "iOS", "Windows", "MacOS", "Linux"],
          offlineReady: true
        },
        null,
        2
      )
    );

    // 7. Tentative d'inclusion des logos depuis le cache ou fetch en arraybuffer
    try {
      const logoRes = await fetch("/logo-192.png");
      if (logoRes.ok) {
        const logoBlob = await logoRes.blob();
        zip.folder("icons")?.file("icon-192.png", logoBlob);
      }
    } catch {}

    try {
      const logo512Res = await fetch("/logo.png");
      if (logo512Res.ok) {
        const logo512Blob = await logo512Res.blob();
        zip.folder("icons")?.file("icon-512.png", logo512Blob);
      }
    } catch {}

    onProgress?.("Compression du package PWA...");
    const content = await zip.generateAsync({ type: "blob" });

    onProgress?.("Téléchargement en cours...");
    // Déclenchement du téléchargement en mémoire via Blob (zéro cookie, 100% fiable)
    const blobUrl = URL.createObjectURL(content);
    const link = document.createElement("a");
    link.href = blobUrl;
    link.download = "GenieMentorAcademie_GMA_PWA_Package.zip";
    document.body.appendChild(link);
    link.click();
    setTimeout(() => {
      document.body.removeChild(link);
      URL.revokeObjectURL(blobUrl);
    }, 1500);

    return true;
  } catch (error) {
    console.error("[PWA Package Download Error]:", error);
    return false;
  }
}
