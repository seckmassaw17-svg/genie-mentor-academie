import { UserProfile, StudentRecord, UserNotification, SecondaryLevel, PaymentFormType } from "../types";
import { saveNotificationToSupabase } from "../data/supabaseStorage";
import { supabase } from "../lib/supabaseClient";
import { isUserAdmin, ADMIN_EMAILS } from "./vipUtils";

export type UserLike = {
  uid: string;
  displayName?: string;
  email?: string;
  level?: SecondaryLevel | string;
  studentId?: string;
  matricule?: string;
  phoneNumber?: string;
  photoUrl?: string;
  isAdmin?: boolean;
  isVIP?: boolean;
};

/**
 * Generates a standardized, unique, deterministic student matricule (e.g. "ELE-6E-0042", "ELE-3E-1042").
 */
export function generateStudentMatricule(
  level?: string,
  uid?: string,
  email?: string
): string {
  if (email && isUserAdmin({ email })) {
    const clean = email.trim().toLowerCase();
    const idx = ADMIN_EMAILS.map((e) => e.toLowerCase()).indexOf(clean);
    return idx !== -1 ? `Admin-${idx + 1}` : "Admin-1";
  }

  const cleanLvl = (level || "6E")
    .toUpperCase()
    .replace(/È/g, "E")
    .replace(/É/g, "E")
    .replace(/[^A-Z0-9]/g, "")
    .substring(0, 4) || "STD";

  const seed = (uid || email || "student_user").trim();
  let hash = 0;
  for (let i = 0; i < seed.length; i++) {
    hash = (hash << 5) - hash + seed.charCodeAt(i);
    hash |= 0;
  }
  const num = String((Math.abs(hash) % 9000) + 1000).padStart(4, "0");
  return `ELE-${cleanLvl}-${num}`;
}

/**
 * Returns a unique student matricule / ID (e.g. "ELE-6E-0042" or "Admin-1").
 */
export function getUserStudentId(
  u: { uid?: string; level?: string; studentId?: string; matricule?: string; email?: string; isAdmin?: boolean } | null | undefined
): string {
  if (!u) return "ELE-6E-0001";
  if (isUserAdmin(u) || u.isAdmin) {
    const cleanEmail = (u.email || "").trim().toLowerCase();
    const idx = ADMIN_EMAILS.map((e) => e.toLowerCase()).indexOf(cleanEmail);
    if (idx !== -1) {
      return `Admin-${idx + 1}`;
    }
    return "Admin-1";
  }
  if (u.matricule && u.matricule.trim().length >= 4) {
    return u.matricule.trim();
  }
  if (u.studentId && u.studentId.trim().length >= 4) {
    return u.studentId.trim();
  }
  return generateStudentMatricule(u.level, u.uid, u.email);
}

/**
 * Dispatches an administrative alert notification to the Admin.
 * (La notification élève 'Demande transmise à la Direction' a été supprimée pour éviter les doublons dans le Centre de Notifications. L'élève recevra uniquement la notification finale de validation.)
 */
export async function notifyClassChangeSubmitted(
  user: UserLike,
  requestedLevel: SecondaryLevel,
  reason: string
): Promise<void> {
  const studentId = getUserStudentId(user);
  const now = Date.now();
  const dateFormatted = `Aujourd'hui à ${new Date().toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}`;

  // Une seule notification d'alerte destinée à l'administration (recipient: 'admin')
  const adminNotif: UserNotification = {
    id: `notif_cc_admin_${user.uid}_${requestedLevel}_${now}`,
    recipient: "admin",
    recipientId: "admin",
    target_uid: "admin",
    targetUid: "admin",
    sender_email: (user.email || "").toLowerCase().trim(),
    userUid: user.uid,
    userId: user.uid,
    userName: user.displayName || "Élève",
    userEmail: user.email || "",
    userPhone: user.phoneNumber || "",
    targetRole: "admin",
    title: "🔔 Nouvelle demande de changement de classe",
    message: `L'élève ${user.displayName || "Élève"} (Email: ${user.email || "Non spécifié"}, ID: #${studentId}, Classe actuelle: ${user.level || "Non spécifiée"}) demande le passage en ${requestedLevel}. Motif: "${reason}".`,
    type: "CLASS_CHANGE",
    status: "UNREAD",
    createdAt: now,
    dateFormatted,
  };

  await saveNotificationToSupabase(adminNotif).catch(console.warn);
}

/**
 * Dispatches notification for VIP Pass subscription.
 */
export async function notifyVIPPaymentSubmitted(
  user: UserLike,
  planDuration: string,
  amount: number,
  transactionRef: string,
  userPhone: string
): Promise<void> {
  const studentId = getUserStudentId(user);
  const now = Date.now();
  const dateFormatted = `Aujourd'hui à ${new Date().toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}`;
  const cleanRef = (transactionRef || "vip").replace(/[^a-zA-Z0-9_-]/g, "");
  const studentEmail = (user.email || "").toLowerCase().trim();

  // Student notification
  const studentNotif: UserNotification = {
    id: `notif_vip_user_${user.uid}_${cleanRef}`,
    recipient: studentEmail || user.uid,
    recipientId: studentEmail || user.uid,
    target_uid: user.uid,
    targetUid: user.uid,
    sender_email: "admin",
    userUid: user.uid,
    userId: user.uid,
    userName: user.displayName || "Élève",
    userEmail: user.email || "",
    userPhone: userPhone,
    targetRole: "student",
    title: "⭐ Demande Pass VIP transmise avec succès",
    message: `Bonjour ${user.displayName || "Élève"} (ID: #${studentId}), votre demande d'activation du Pass VIP (${planDuration}, Réf: ${transactionRef}) d'un montant de ${amount.toLocaleString("fr-FR")} FCFA a été bien transmise à la Direction. Elle sera validée sous peu.`,
    type: "VIP_PASS",
    status: "UNREAD",
    createdAt: now,
    dateFormatted,
  };

  // Admin notification
  const adminNotif: UserNotification = {
    id: `notif_vip_admin_${cleanRef}`,
    recipient: "admin",
    recipientId: "admin",
    target_uid: "admin",
    targetUid: "admin",
    sender_email: studentEmail,
    userUid: user.uid,
    userId: user.uid,
    userName: user.displayName || "Élève",
    userEmail: user.email || "",
    userPhone: userPhone,
    targetRole: "admin",
    title: "🌟 Nouvelle souscription Pass VIP",
    message: `L'élève ${user.displayName || "Élève"} (Email: ${studentEmail}, ID: #${studentId}, Tél: ${userPhone}) a souscrit au Pass VIP (${planDuration}, ${amount.toLocaleString("fr-FR")} FCFA, Réf: ${transactionRef}).`,
    type: "VIP_PASS",
    status: "UNREAD",
    createdAt: now,
    dateFormatted,
  };

  await Promise.all([
    saveNotificationToSupabase(studentNotif).catch(console.warn),
    saveNotificationToSupabase(adminNotif).catch(console.warn),
  ]);
}

/**
 * Dispatches notification for Course (Renforcement / Domicile) payment.
 */
export async function notifyCoursePaymentSubmitted(
  user: UserLike,
  learnerName: string,
  type: PaymentFormType | "renforcement" | "domicile",
  amount: number,
  operator: string,
  phone: string
): Promise<void> {
  const studentId = getUserStudentId(user);
  const now = Date.now();
  const dateFormatted = `Aujourd'hui à ${new Date().toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}`;
  const typeLabel = type === "domicile" ? "Cours à Domicile" : "Cours de Renforcement";
  const refKey = `${user.uid || "guest"}_${type}_${amount}_${now}`;

  const studentEmail = (user.email || "").toLowerCase().trim();

  // Student notification
  const studentNotif: UserNotification = {
    id: `notif_course_user_${refKey}`,
    recipient: studentEmail || user.uid,
    recipientId: studentEmail || user.uid,
    target_uid: user.uid,
    targetUid: user.uid,
    sender_email: "admin",
    userUid: user.uid,
    userId: user.uid,
    userName: user.displayName || "Élève",
    userEmail: user.email || "",
    userPhone: phone,
    targetRole: "student",
    title: `💳 Paiement ${typeLabel} transmis`,
    message: `Bonjour ${user.displayName || "Élève"} (ID: #${studentId}), votre paiement de ${amount.toLocaleString("fr-FR")} FCFA pour l'apprenant "${learnerName}" (${typeLabel}) a bien été transmis. Un reçu provisoire est disponible dans votre profil.`,
    type: "SYSTEM",
    status: "UNREAD",
    createdAt: now,
    dateFormatted,
  };

  // Admin notification
  const adminNotif: UserNotification = {
    id: `notif_course_admin_${refKey}`,
    recipient: "admin",
    recipientId: "admin",
    target_uid: "admin",
    targetUid: "admin",
    sender_email: studentEmail,
    userUid: user.uid,
    userId: user.uid,
    userName: user.displayName || "Élève",
    userEmail: user.email || "",
    userPhone: phone,
    targetRole: "admin",
    title: `💰 Nouveau Paiement ${typeLabel}`,
    message: `Paiement de ${amount.toLocaleString("fr-FR")} FCFA reçu de ${user.displayName || "Élève"} (Email: ${studentEmail}, ID: #${studentId}) pour l'apprenant ${learnerName} (${typeLabel}, Opérateur: ${operator.toUpperCase()}, Tél: ${phone}).`,
    type: "SYSTEM",
    status: "UNREAD",
    createdAt: now,
    dateFormatted,
  };

  await Promise.all([
    saveNotificationToSupabase(studentNotif).catch(console.warn),
    saveNotificationToSupabase(adminNotif).catch(console.warn),
  ]);
}

/**
 * Dispatches notification for Homework / TD submission.
 */
export async function notifyHomeworkSubmitted(
  user: UserLike,
  title: string,
  subject: string,
  level: string
): Promise<void> {
  const studentId = getUserStudentId(user);
  const now = Date.now();
  const dateFormatted = `Aujourd'hui à ${new Date().toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}`;
  const cleanTitle = encodeURIComponent((title || "devoir").trim().toLowerCase().slice(0, 30));

  // Student notification
  const studentNotif: UserNotification = {
    id: `notif_hw_user_${user.uid}_${cleanTitle}`,
    target_uid: user.uid,
    targetUid: user.uid,
    userUid: user.uid,
    userId: user.uid,
    userName: user.displayName || "Élève",
    userEmail: user.email || "",
    recipientId: user.uid,
    targetRole: "student",
    title: "📝 Devoir déposé avec succès",
    message: `Bonjour ${user.displayName || "Élève"} (ID: #${studentId}), votre devoir "${title}" (${subject}) a bien été transmis à la Direction pour correction.`,
    type: "info",
    status: "unread",
    createdAt: now,
    dateFormatted,
  };

  // Admin notification
  const adminNotif: UserNotification = {
    id: `notif_hw_admin_${user.uid}_${cleanTitle}`,
    target_uid: "admin",
    targetUid: "admin",
    userUid: user.uid,
    userId: user.uid,
    userName: user.displayName || "Élève",
    userEmail: user.email || "",
    recipientId: "admin",
    targetRole: "admin",
    title: "📑 Nouveau Devoir déposé",
    message: `L'élève ${user.displayName || "Élève"} (ID: #${studentId}, Classe: ${level}) a déposé son devoir "${title}" en ${subject}.`,
    type: "info",
    status: "unread",
    createdAt: now,
    dateFormatted,
  };

  await Promise.all([
    saveNotificationToSupabase(studentNotif).catch(console.warn),
    saveNotificationToSupabase(adminNotif).catch(console.warn),
  ]);
}

/**
 * Returns whether a student is currently online (active within last 5 minutes)
 * and formatted text for last login.
 */
export function getStudentPresenceStatus(
  lastSeen?: number,
  createdAt?: number
): {
  isOnline: boolean;
  statusLabel: string;
  badgeClass: string;
  lastSeenFormatted: string;
} {
  const effectiveTime = lastSeen || 0;
  const now = Date.now();
  const diffMinutes = effectiveTime > 0 ? Math.floor((now - effectiveTime) / (60 * 1000)) : 9999;

  // Strictly active within the last 5 minutes (300,000 ms)
  const isOnline = Boolean(effectiveTime > 0 && (now - effectiveTime < 5 * 60 * 1000));

  let lastSeenFormatted = "Jamais connecté";
  if (effectiveTime > 0) {
    const d = new Date(effectiveTime);
    if (diffMinutes < 1) {
      lastSeenFormatted = "À l'instant";
    } else if (diffMinutes < 60) {
      lastSeenFormatted = `Il y a ${diffMinutes} min`;
    } else {
      lastSeenFormatted = d.toLocaleDateString("fr-FR", {
        day: "numeric",
        month: "short",
        hour: "2-digit",
        minute: "2-digit",
      });
    }
  } else if (createdAt && createdAt > 0) {
    lastSeenFormatted = `Inscrit le ${new Date(createdAt).toLocaleDateString("fr-FR")}`;
  }

  return {
    isOnline,
    statusLabel: isOnline ? "En ligne" : "Hors-ligne",
    badgeClass: isOnline
      ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
      : "bg-slate-700/40 text-slate-400 border border-slate-600/30",
    lastSeenFormatted,
  };
}

/**
 * Updates user presence timestamp in Supabase.
 */
export async function updateUserPresence(userUid: string): Promise<void> {
  if (!userUid || !supabase) return;
  const now = Date.now();
  try {
    const { error: err1 } = await supabase
      .from("profiles")
      .update({ last_seen: now })
      .eq("id", userUid);
    
    if (err1) {
      console.warn("[Presence Sync] Profiles update notice:", err1.message);
    }

    // Try users_profile table as well to cover all potential schemas
    const { error: err2 } = await supabase
      .from("users_profile")
      .update({ last_seen: now })
      .eq("id", userUid);

    if (err2 && err2.code !== "PGRST116") {
      console.warn("[Presence Sync] Users_profile update notice:", err2.message);
    }
  } catch (err) {
    console.warn("[Presence Sync] Exception during presence update:", err);
  }
}

/**
 * Dispatches an automated class-segmented broadcast notification when a new course is published.
 */
export async function notifyCoursePublished(course: {
  id: string;
  title: string;
  subject: string;
  level: SecondaryLevel | string;
}): Promise<void> {
  const now = Date.now();
  const dateFormatted = `Aujourd'hui à ${new Date().toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}`;
  const notifId = `notif_course_pub_${course.id}`;

  const broadcastNotif: UserNotification = {
    id: notifId,
    target_uid: "all",
    targetUid: "all",
    userUid: "all",
    recipientId: "all",
    targetRole: course.level,
    targetLevel: course.level,
    title: `📚 Nouveau Cours publié (${course.level})`,
    message: `Leçon disponible : « ${course.title} » en ${course.subject} pour la classe de ${course.level}. Cliquez pour consulter le cours.`,
    type: "admin_broadcast",
    status: "unread",
    actionTab: "cours",
    actionItemId: course.id,
    createdAt: now,
    dateFormatted,
  };

  await saveNotificationToSupabase(broadcastNotif).catch(console.warn);
}

/**
 * Dispatches an automated class-segmented broadcast notification when an asset/TD/exam is published.
 */
export async function notifyAssetPublished(asset: {
  assetId: string;
  name?: string;
  title?: string;
  subject?: string;
  level?: SecondaryLevel | string;
  category?: string;
}): Promise<void> {
  const now = Date.now();
  const dateFormatted = `Aujourd'hui à ${new Date().toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}`;
  const notifId = `notif_asset_pub_${asset.assetId}`;
  const level = asset.level || "Toutes classes";
  const isExercise = asset.category === "exercise";
  const assetName = asset.name || asset.title || "Document";

  const broadcastNotif: UserNotification = {
    id: notifId,
    target_uid: "all",
    targetUid: "all",
    userUid: "all",
    recipientId: "all",
    targetRole: level,
    targetLevel: level,
    title: isExercise ? `✏️ Nouvelle Fiche de TD / Exercice (${level})` : `📑 Nouvelle Épreuve / Ressource (${level})`,
    message: `Ressource publiée : « ${assetName} » (${asset.subject || "Général"}) pour la classe de ${level}.`,
    type: "admin_broadcast",
    status: "unread",
    actionTab: "evaluations",
    actionSubTab: isExercise ? "exercices" : "devoirs",
    actionItemId: asset.assetId,
    createdAt: now,
    dateFormatted,
  };

  await saveNotificationToSupabase(broadcastNotif).catch(console.warn);
}

/**
 * Dispatches an automated class-segmented broadcast notification when a Quiz is published.
 */
export async function notifyQuizPublished(quiz: {
  id: string;
  title: string;
  subject: string;
  level: SecondaryLevel | string;
}): Promise<void> {
  const now = Date.now();
  const dateFormatted = `Aujourd'hui à ${new Date().toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}`;
  const notifId = `notif_quiz_pub_${quiz.id}`;

  const broadcastNotif: UserNotification = {
    id: notifId,
    target_uid: "all",
    targetUid: "all",
    userUid: "all",
    recipientId: "all",
    targetRole: quiz.level,
    targetLevel: quiz.level,
    title: `🎯 Nouveau Quiz Évaluatif (${quiz.level})`,
    message: `Quiz QCM interactif : « ${quiz.title} » en ${quiz.subject} (${quiz.level}). Testez vos connaissances !`,
    type: "admin_broadcast",
    status: "unread",
    actionTab: "evaluations",
    actionSubTab: "quiz",
    actionItemId: quiz.id,
    createdAt: now,
    dateFormatted,
  };

  await saveNotificationToSupabase(broadcastNotif).catch(console.warn);
}

/**
 * Logs every administrative action.
 */
export async function logAdminActionToSupabase(
  adminName: string,
  actionType: string,
  details: string,
  targetUserId?: string,
  extraData?: Record<string, any>
): Promise<void> {
  if (!supabase) return;
  try {
    const logId = `admin_log_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    await supabase.from("admin_logs").insert({
      id: logId,
      admin_name: adminName || "Massaw Seck",
      action_type: actionType,
      details,
      target_user_id: targetUserId || null,
      extra_data: extraData || {},
      created_at: Date.now(),
    });
  } catch (err) {
    console.warn("Could not log admin action to Supabase:", err);
  }
}

export const logAdminActionToFirebase = logAdminActionToSupabase;

