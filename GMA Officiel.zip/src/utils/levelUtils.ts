import { normalizeLevel, getLevelLabel } from "../data/mockData";

export function getShortLevelName(level: string | undefined | null): string {
  if (!level) return "";
  return normalizeLevel(level);
}

export function formatLevelDisplay(level: string | undefined | null): string {
  if (!level) return "Classe non spécifiée";
  return getLevelLabel(level);
}

