import { QuizResultRecord } from "../types";

/**
 * Returns distinct quiz results for an individual student (equivalent to COUNT(DISTINCT quiz_id)),
 * prioritizing the highest score or most recent attempt when a student took a quiz more than once.
 */
export function getDistinctQuizResults(results: QuizResultRecord[] = []): QuizResultRecord[] {
  if (!Array.isArray(results) || results.length === 0) return [];

  const map = new Map<string, QuizResultRecord>();

  for (const r of results) {
    const key = (r.quizId || r.quizTitle || r.id || "").trim();
    if (!key) continue;

    const existing = map.get(key);
    if (!existing) {
      map.set(key, r);
    } else {
      const existingScore = existing.score20 ?? (existing.scorePercentage ? existing.scorePercentage / 5 : 0);
      const currentScore = r.score20 ?? (r.scorePercentage ? r.scorePercentage / 5 : 0);
      // Keep highest score or newer attempt if score is equal
      if (currentScore > existingScore || (currentScore === existingScore && (r.timestamp || 0) >= (existing.timestamp || 0))) {
        map.set(key, r);
      }
    }
  }

  return Array.from(map.values()).sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
}

/**
 * Calculates student distinct quiz average (/20).
 */
export function calculateStudentQuizAverage(results: QuizResultRecord[] = []): number | null {
  const distinct = getDistinctQuizResults(results);
  if (distinct.length === 0) return null;
  const sum = distinct.reduce((acc, r) => {
    const score20 = r.score20 ?? (r.scorePercentage ? r.scorePercentage / 5 : 0);
    return acc + score20;
  }, 0);
  return Math.round((sum / distinct.length) * 10) / 10;
}
