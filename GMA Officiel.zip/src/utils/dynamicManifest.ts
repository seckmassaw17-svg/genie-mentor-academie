/**
 * Dynamic PWA Web App Manifest & Service Worker Cache Invalidation Manager
 * Ensures that newly uploaded 192x192 & 512x512 icons in system_settings
 * are immediately reflected in Android Chrome install prompt ("Installer et créer un raccourci")
 * and launcher shortcuts.
 */

import { getPwaIcon192, getPwaIcon512, applyPwa192ToDom, applyPwa512ToDom } from "./assetImages";
import { getLocalSystemSettings } from "../data/systemSettingsStorage";

export interface PwaManifestData {
  id: string;
  name: string;
  short_name: string;
  description: string;
  start_url: string;
  scope: string;
  display: string;
  display_override?: string[];
  background_color: string;
  theme_color: string;
  orientation?: string;
  lang?: string;
  dir?: string;
  categories?: string[];
  prefer_related_applications?: boolean;
  icons: Array<{
    src: string;
    sizes: string;
    type: string;
    purpose?: string;
  }>;
  shortcuts?: Array<{
    name: string;
    short_name: string;
    description: string;
    url: string;
    icons: Array<{
      src: string;
      sizes: string;
      type: string;
    }>;
  }>;
}

let activeBlobUrl: string | null = null;

function inferMimeType(url: string): string {
  const clean = url.split("?")[0].toLowerCase();
  if (clean.endsWith(".svg")) return "image/svg+xml";
  if (clean.endsWith(".jpg") || clean.endsWith(".jpeg")) return "image/jpeg";
  if (clean.endsWith(".webp")) return "image/webp";
  if (clean.endsWith(".ico")) return "image/x-icon";
  return "image/png";
}

/**
 * Builds a compliant Web App Manifest data object with current icons and app settings.
 */
export function buildManifestData(custom?: {
  icon192?: string;
  icon512?: string;
  appName?: string;
  shortName?: string;
}): PwaManifestData {
  const settings = getLocalSystemSettings();
  const icon192 = custom?.icon192 || getPwaIcon192();
  const icon512 = custom?.icon512 || getPwaIcon512();
  const appName = custom?.appName || settings.appName || "Génie Mentor Académie";
  const shortName = custom?.shortName || settings.shortName || "GMA";

  const type192 = inferMimeType(icon192);
  const type512 = inferMimeType(icon512);

  return {
    id: "/",
    name: appName,
    short_name: shortName,
    description:
      settings.description ||
      "Plateforme pédagogique d'excellence Génie Mentor Académie : soutien scolaire, cours de renforcement, répétiteurs à domicile et gestion académique offline-first.",
    start_url: "/",
    scope: "/",
    display: "standalone",
    display_override: ["standalone", "minimal-ui", "window-controls-overlay"],
    background_color: "#ffffff",
    theme_color: settings.primaryColor || "#1e40af",
    orientation: "portrait-primary",
    lang: "fr",
    dir: "ltr",
    categories: ["education", "productivity", "books"],
    prefer_related_applications: false,
    icons: [
      {
        src: icon192,
        sizes: "192x192",
        type: type192,
        purpose: "any",
      },
      {
        src: icon192,
        sizes: "192x192",
        type: type192,
        purpose: "maskable",
      },
      {
        src: icon512,
        sizes: "512x512",
        type: type512,
        purpose: "any",
      },
      {
        src: icon512,
        sizes: "512x512",
        type: type512,
        purpose: "maskable",
      },
    ],
    shortcuts: [
      {
        name: "Mes Cours",
        short_name: "Cours",
        description: "Accéder aux cours et résumés pédagogiques",
        url: "/?tab=courses",
        icons: [{ src: icon192, sizes: "192x192", type: type192 }],
      },
      {
        name: "Exercices & Corrigés",
        short_name: "Exercices",
        description: "S'entraîner avec les exercices corrigés",
        url: "/?tab=exercises",
        icons: [{ src: icon192, sizes: "192x192", type: type192 }],
      },
      {
        name: "Évaluations & Tests",
        short_name: "Tests",
        description: "Tester son niveau avec les QCM et examens blancs",
        url: "/?tab=tests",
        icons: [{ src: icon192, sizes: "192x192", type: type192 }],
      },
      {
        name: "Trouver un Répétiteur",
        short_name: "Répétiteurs",
        description: "Consulter les profils de répétiteurs qualifiés",
        url: "/?tab=repetiteurs",
        icons: [{ src: icon192, sizes: "192x192", type: type192 }],
      },
    ],
  };
}

/**
 * Dynamically updates the <link rel="manifest"> tag in the document head
 * using a dynamic Blob URL representation so Chrome Android instantly picks up
 * the updated icons for the "Installer et créer un raccourci" dialog.
 */
export function updateDynamicManifest(custom?: {
  icon192?: string;
  icon512?: string;
  appName?: string;
  shortName?: string;
}): string {
  if (typeof document === "undefined") return "";

  const manifestData = buildManifestData(custom);
  const jsonString = JSON.stringify(manifestData, null, 2);

  // Revoke previous blob URL to prevent memory leaks
  if (activeBlobUrl) {
    try {
      URL.revokeObjectURL(activeBlobUrl);
    } catch {}
    activeBlobUrl = null;
  }

  const blob = new Blob([jsonString], { type: "application/manifest+json" });
  activeBlobUrl = URL.createObjectURL(blob);

  // Update or insert <link rel="manifest">
  let manifestLink = document.querySelector('link[rel="manifest"]') as HTMLLinkElement | null;
  if (!manifestLink) {
    manifestLink = document.createElement("link");
    manifestLink.rel = "manifest";
    document.head.appendChild(manifestLink);
  }

  manifestLink.href = activeBlobUrl;
  manifestLink.setAttribute("data-dynamic", "true");
  manifestLink.setAttribute("data-updated-at", String(Date.now()));

  // Also apply to DOM apple-touch-icon
  const icon192 = custom?.icon192 || getPwaIcon192();
  const icon512 = custom?.icon512 || getPwaIcon512();
  applyPwa192ToDom(icon192);
  applyPwa512ToDom(icon512);

  // Broadcast custom event
  try {
    window.dispatchEvent(
      new CustomEvent("gma_manifest_updated", {
        detail: {
          manifestUrl: activeBlobUrl,
          icon192,
          icon512,
        },
      })
    );
  } catch {}

  return activeBlobUrl;
}

/**
 * Synchronous initialization on application boot (0ms zero-flicker)
 */
export function applyDynamicManifestFromStorage(): void {
  if (typeof window === "undefined") return;
  updateDynamicManifest();
}

/**
 * Forces invalidation of the Service Worker icon & manifest cache
 * so Chrome and Android immediately load the new icons without stale cache.
 */
export async function invalidatePwaIconCache(customIcons?: {
  icon192?: string;
  icon512?: string;
}): Promise<void> {
  if (typeof window === "undefined") return;

  // 1. Purge matching entries in window.caches (CacheStorage API)
  if ("caches" in window) {
    try {
      const cacheNames = await window.caches.keys();
      await Promise.all(
        cacheNames.map(async (name) => {
          try {
            const cache = await window.caches.open(name);
            const requests = await cache.keys();
            await Promise.all(
              requests.map(async (req) => {
                const url = req.url.toLowerCase();
                if (
                  url.includes("manifest") ||
                  url.includes("logo") ||
                  url.includes("icon") ||
                  url.includes("favicon") ||
                  url.includes("pwa")
                ) {
                  await cache.delete(req);
                }
              })
            );
          } catch (err) {
            console.warn(`[PWA Cache] Warning cleaning ${name}:`, err);
          }
        })
      );
      console.log("[PWA Cache] Icon & manifest entries invalidated in CacheStorage.");
    } catch (e) {
      console.warn("[PWA Cache] Error purging CacheStorage:", e);
    }
  }

  // 2. Send cache invalidation signal to active Service Worker
  if ("serviceWorker" in navigator) {
    try {
      const reg = await navigator.serviceWorker.getRegistration();
      if (reg) {
        if (reg.active) {
          reg.active.postMessage({ type: "INVALIDATE_PWA_CACHE" });
        }
        // Force SW registration update
        await reg.update().catch(() => {});
      }
    } catch (e) {
      console.warn("[PWA Cache] Notice posting message to SW:", e);
    }
  }

  // 3. Update dynamic <link rel="manifest"> in DOM
  updateDynamicManifest(customIcons);

  // 4. Notify backend server endpoint if reachable
  const payload = {
    icon192: customIcons?.icon192 || getPwaIcon192(),
    icon512: customIcons?.icon512 || getPwaIcon512(),
  };

  try {
    await fetch("/api/pwa-manifest", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    }).catch(() => {
      // Benign if offline
    });
  } catch {}
}
