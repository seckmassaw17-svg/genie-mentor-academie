import { Course, Asset, Quiz, UserProfile, SecondaryLevel, StudentRecord, QuizResultRecord, PaymentTransaction, UserNotification, TransactionStatus, ClassChangeRequest, ClassChangeStatus, HomeworkSubmission, HomeworkStatus, VIPPaymentRequest, VIPRequestStatus, TutorialVideo } from "../types";
import { INITIAL_COURSES, INITIAL_ASSETS, INITIAL_QUIZZES, INITIAL_STUDENTS } from "./mockData";
import { isUserAdmin, ADMIN_EMAILS } from "../utils/vipUtils";

const STORAGE_KEYS = {
  COURSES: "savoirplus_room_courses",
  ASSETS: "savoirplus_room_assets",
  QUIZZES: "savoirplus_room_quizzes",
  TUTORIALS: "savoirplus_room_tutorials",
  STUDENTS: "savoirplus_room_students",
  USER: "savoirplus_user_profile",
  TRANSACTIONS: "savoirplus_room_transactions",
  NOTIFICATIONS: "savoirplus_room_notifications",
  OFFLINE_MODE: "savoirplus_offline_mode",
  SYNC_STATUS: "savoirplus_sync_status",
  ADMIN_PASSWORD: "savoirplus_admin_password",
  CLASS_CHANGE_REQUESTS: "savoirplus_class_change_requests",
  VIP_REQUESTS: "savoirplus_vip_requests",
  HOMEWORKS: "savoirplus_room_homeworks",
};

export class RoomDatabaseRepository {
  private static instance: RoomDatabaseRepository;
  private listeners: Array<() => void> = [];

  private constructor() {
    this.initDefaultData();
  }

  public static getInstance(): RoomDatabaseRepository {
    if (!RoomDatabaseRepository.instance) {
      RoomDatabaseRepository.instance = new RoomDatabaseRepository();
    }
    return RoomDatabaseRepository.instance;
  }

  public subscribe(callback: () => void): () => void {
    this.listeners.push(callback);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== callback);
    };
  }

  public notify() {
    setTimeout(() => {
      this.listeners.forEach((cb) => {
        try {
          cb();
        } catch (e) {
          console.warn("[RoomRepo] listener error:", e);
        }
      });
    }, 0);
  }

  private initDefaultData() {
    if (!localStorage.getItem(STORAGE_KEYS.COURSES)) {
      localStorage.setItem(STORAGE_KEYS.COURSES, JSON.stringify([]));
    }
    if (!localStorage.getItem(STORAGE_KEYS.ASSETS)) {
      localStorage.setItem(STORAGE_KEYS.ASSETS, JSON.stringify([]));
    }
    if (!localStorage.getItem(STORAGE_KEYS.QUIZZES)) {
      localStorage.setItem(STORAGE_KEYS.QUIZZES, JSON.stringify([]));
    }
    if (!localStorage.getItem(STORAGE_KEYS.TUTORIALS)) {
      localStorage.setItem(STORAGE_KEYS.TUTORIALS, JSON.stringify([]));
    }
    if (!localStorage.getItem(STORAGE_KEYS.STUDENTS)) {
      localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify([]));
    } else {
      // Purge any demo/mock students (e.g. std_01, std_02, user_massaw_01, or non-admins if flag set)
      try {
        const existingStd: StudentRecord[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.STUDENTS) || "[]");
        const cleanStd = existingStd.filter(
          (s) => !s.uid.startsWith("std_") && s.uid !== "user_massaw_01"
        );
        if (cleanStd.length !== existingStd.length) {
          localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(cleanStd));
        }
      } catch {
        localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify([]));
      }
    }

    // Clean up any stale mock user session that may have been saved previously
    const existingUserRaw = localStorage.getItem(STORAGE_KEYS.USER);
    if (existingUserRaw) {
      try {
        const parsed = JSON.parse(existingUserRaw);
        if (parsed?.uid === "user_massaw_01" || (parsed?.uid && parsed.uid.startsWith("std_"))) {
          localStorage.removeItem(STORAGE_KEYS.USER);
        }
      } catch {
        localStorage.removeItem(STORAGE_KEYS.USER);
      }
    }

    if (!localStorage.getItem(STORAGE_KEYS.TRANSACTIONS)) {
      localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify([]));
    } else {
      // Filter out mock sample transactions
      try {
        const txs: PaymentTransaction[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.TRANSACTIONS) || "[]");
        const cleanTxs = txs.filter((t) => t.id !== "tx_sample_01" && t.id !== "tx_sample_02" && t.userUid !== "user_massaw_01");
        if (cleanTxs.length !== txs.length) {
          localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(cleanTxs));
        }
      } catch {
        localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify([]));
      }
    }

    if (!localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS)) {
      localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify([]));
    } else {
      // Filter out mock sample notifications
      try {
        const notifs: UserNotification[] = JSON.parse(localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS) || "[]");
        const cleanNotifs = notifs.filter((n) => n.id !== "notif_sample_01" && n.id !== "notif_sample_02" && n.userUid !== "user_massaw_01");
        if (cleanNotifs.length !== notifs.length) {
          localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(cleanNotifs));
        }
      } catch {
        localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify([]));
      }
    }
  }

  // --- Admin Password DAO ---
  public getAdminPassword(): string {
    return localStorage.getItem(STORAGE_KEYS.ADMIN_PASSWORD) || "Perpendiculaire @2026";
  }

  public setAdminPassword(newPassword: string): void {
    localStorage.setItem(STORAGE_KEYS.ADMIN_PASSWORD, newPassword);
    
    // Also update student list if admin is present
    const students = this.getAllStudents();
    let updated = false;
    const newStudents = students.map((s) => {
      if (s.email.toLowerCase() === "massaw.seck@unchk.edu.sn" || s.uid === "admin_1") {
        updated = true;
        return { ...s, password: newPassword };
      }
      return s;
    });
    if (updated) {
      localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(newStudents));
    }

    this.notify();
    import("./supabaseStorage").then((m) => {
      m.saveAdminPasswordToSupabase(newPassword).catch((err) => console.warn("[RoomSync]", err?.message || err));
    });
  }

  // --- Room DAO Operations ---

  public getCoursesByLevel(level: SecondaryLevel): Course[] {
    const raw = localStorage.getItem(STORAGE_KEYS.COURSES);
    if (!raw) return [];
    try {
      const courses: Course[] = JSON.parse(raw);
      return courses
        .filter((c) => c.level === level)
        .sort((a, b) => b.createdAt - a.createdAt);
    } catch {
      return [];
    }
  }

  public getAllCourses(): Course[] {
    const raw = localStorage.getItem(STORAGE_KEYS.COURSES);
    if (!raw) return [];
    try {
      return JSON.parse(raw);
    } catch {
      return [];
    }
  }

  public getAssetsForParent(parentId: string): Asset[] {
    const raw = localStorage.getItem(STORAGE_KEYS.ASSETS);
    if (!raw) return [];
    try {
      const assets: Asset[] = JSON.parse(raw);
      return assets.filter((a) => a.parentId === parentId);
    } catch {
      return [];
    }
  }

  public getAllAssets(): Asset[] {
    const raw = localStorage.getItem(STORAGE_KEYS.ASSETS);
    if (!raw) return [];
    try {
      return JSON.parse(raw);
    } catch {
      return [];
    }
  }

  public getQuizzesByLevel(level: SecondaryLevel): Quiz[] {
    const raw = localStorage.getItem(STORAGE_KEYS.QUIZZES);
    if (!raw) return [];
    try {
      const quizzes: Quiz[] = JSON.parse(raw);
      return quizzes.filter((q) => q.level === level);
    } catch {
      return [];
    }
  }

  public getAllQuizzes(): Quiz[] {
    const raw = localStorage.getItem(STORAGE_KEYS.QUIZZES);
    if (!raw) return [];
    try {
      return JSON.parse(raw);
    } catch {
      return [];
    }
  }

  public getAllTutorials(): TutorialVideo[] {
    const raw = localStorage.getItem(STORAGE_KEYS.TUTORIALS);
    if (!raw) return [];
    try {
      return JSON.parse(raw);
    } catch {
      return [];
    }
  }

  public getTutorialsByLevel(level: SecondaryLevel | string): TutorialVideo[] {
    const all = this.getAllTutorials();
    if (!level || level === "Toutes" || level === "ALL") return all;
    return all.filter((t) => t.level === level || level === "Savoir+" || level === "GMA" || level === "Génie Mentor Académie");
  }

  public syncTutorialsFromRemote(remoteTutorials: TutorialVideo[]) {
    if (!remoteTutorials) return;
    localStorage.setItem(STORAGE_KEYS.TUTORIALS, JSON.stringify(remoteTutorials));
    this.notify();
  }

  public insertTutorial(tutorial: TutorialVideo) {
    const current = this.getAllTutorials();
    const updated = [tutorial, ...current.filter((t) => t.id !== tutorial.id)];
    localStorage.setItem(STORAGE_KEYS.TUTORIALS, JSON.stringify(updated));
    this.notify();
    import("./supabaseStorage").then((m) => {
      m.saveTutorialToSupabase?.(tutorial).catch((err) => console.warn("[RoomSync]", err?.message || err));
    });
  }

  public updateTutorial(tutorial: TutorialVideo) {
    const current = this.getAllTutorials();
    const index = current.findIndex((t) => t.id === tutorial.id);
    if (index >= 0) {
      current[index] = tutorial;
    } else {
      current.unshift(tutorial);
    }
    localStorage.setItem(STORAGE_KEYS.TUTORIALS, JSON.stringify(current));
    this.notify();
    import("./supabaseStorage").then((m) => {
      m.saveTutorialToSupabase?.(tutorial).catch((err) => console.warn("[RoomSync]", err?.message || err));
    });
  }

  public deleteTutorial(tutorialId: string) {
    const current = this.getAllTutorials();
    const filtered = current.filter((t) => t.id !== tutorialId);
    localStorage.setItem(STORAGE_KEYS.TUTORIALS, JSON.stringify(filtered));
    this.notify();
    import("./supabaseStorage").then((m) => {
      m.deleteTutorialFromSupabase?.(tutorialId).catch((err) => console.warn("[RoomSync]", err?.message || err));
    });
  }

  public syncCoursesFromFirebase(remoteCourses: Course[]) {
    if (!remoteCourses) return;
    localStorage.setItem(STORAGE_KEYS.COURSES, JSON.stringify(remoteCourses));
    this.notify();
  }

  public syncCoursesFromRemote(remoteCourses: Course[]) {
    this.syncCoursesFromFirebase(remoteCourses);
  }

  public insertCourses(newCourses: Course[]) {
    const current = this.getAllCourses();
    const map = new Map<string, Course>();
    current.forEach((c) => map.set(c.id, c));
    newCourses.forEach((c) => map.set(c.id, c));
    localStorage.setItem(STORAGE_KEYS.COURSES, JSON.stringify(Array.from(map.values())));
    this.notify();
    import("./supabaseStorage").then((m) => {
      newCourses.forEach((course) => {
        m.saveCourseToSupabase(course).catch((err) => console.warn("[RoomSync]", err?.message || err));
      });
    });
  }

  public updateCourse(updatedCourse: Course) {
    const current = this.getAllCourses();
    const index = current.findIndex((c) => c.id === updatedCourse.id);
    if (index >= 0) {
      current[index] = updatedCourse;
    } else {
      current.unshift(updatedCourse);
    }
    localStorage.setItem(STORAGE_KEYS.COURSES, JSON.stringify(current));
    this.notify();
    import("./supabaseStorage").then((m) => {
      m.saveCourseToSupabase(updatedCourse).catch((err) => console.warn("[RoomSync]", err?.message || err));
    });
  }

  public deleteCourse(courseId: string) {
    const current = this.getAllCourses();
    const filtered = current.filter((c) => c.id !== courseId);
    localStorage.setItem(STORAGE_KEYS.COURSES, JSON.stringify(filtered));
    this.notify();
    import("./supabaseStorage").then((m) => {
      m.deleteCourseFromSupabase(courseId).catch((err) => console.warn("[RoomSync]", err?.message || err));
    });
  }

  public syncAssetsFromFirebase(remoteAssets: Asset[]) {
    if (!remoteAssets) return;
    localStorage.setItem(STORAGE_KEYS.ASSETS, JSON.stringify(remoteAssets));
    this.notify();
  }

  public syncAssetsFromRemote(remoteAssets: Asset[]) {
    this.syncAssetsFromFirebase(remoteAssets);
  }

  public insertAssets(newAssets: Asset[]) {
    const current = this.getAllAssets();
    const map = new Map<string, Asset>();
    current.forEach((a) => map.set(a.assetId, a));
    newAssets.forEach((a) => map.set(a.assetId, a));
    localStorage.setItem(STORAGE_KEYS.ASSETS, JSON.stringify(Array.from(map.values())));
    this.notify();
    import("./supabaseStorage").then((m) => {
      newAssets.forEach((asset) => {
        m.saveAssetToSupabase(asset).catch((err) => console.warn("[RoomSync]", err?.message || err));
      });
    });
  }

  public updateAsset(updatedAsset: Asset) {
    const current = this.getAllAssets();
    const index = current.findIndex((a) => a.assetId === updatedAsset.assetId);
    if (index >= 0) {
      current[index] = updatedAsset;
    } else {
      current.unshift(updatedAsset);
    }
    localStorage.setItem(STORAGE_KEYS.ASSETS, JSON.stringify(current));
    this.notify();
    import("./supabaseStorage").then((m) => {
      m.saveAssetToSupabase(updatedAsset).catch((err) => console.warn("[RoomSync]", err?.message || err));
    });
  }

  public deleteAsset(assetId: string) {
    const current = this.getAllAssets();
    const filtered = current.filter((a) => a.assetId !== assetId);
    localStorage.setItem(STORAGE_KEYS.ASSETS, JSON.stringify(filtered));
    this.notify();
    import("./supabaseStorage").then((m) => {
      m.deleteAssetFromSupabase(assetId).catch((err) => console.warn("[RoomSync]", err?.message || err));
    });
  }

  public syncQuizzesFromFirebase(remoteQuizzes: Quiz[]) {
    if (!remoteQuizzes) return;
    localStorage.setItem(STORAGE_KEYS.QUIZZES, JSON.stringify(remoteQuizzes));
    this.notify();
  }

  public syncQuizzesFromRemote(remoteQuizzes: Quiz[]) {
    this.syncQuizzesFromFirebase(remoteQuizzes);
  }

  public insertQuiz(quiz: Quiz) {
    const current = this.getAllQuizzes();
    const map = new Map<string, Quiz>();
    current.forEach((q) => map.set(q.id, q));
    map.set(quiz.id, quiz);
    localStorage.setItem(STORAGE_KEYS.QUIZZES, JSON.stringify(Array.from(map.values())));
    this.notify();
    import("./supabaseStorage").then((m) => {
      m.saveQuizToSupabase(quiz).catch((err) => console.warn("[RoomSync]", err?.message || err));
    });
  }

  public updateQuiz(updatedQuiz: Quiz) {
    const current = this.getAllQuizzes();
    const index = current.findIndex((q) => q.id === updatedQuiz.id);
    if (index >= 0) {
      current[index] = updatedQuiz;
    } else {
      current.unshift(updatedQuiz);
    }
    localStorage.setItem(STORAGE_KEYS.QUIZZES, JSON.stringify(current));
    this.notify();
    import("./supabaseStorage").then((m) => {
      m.saveQuizToSupabase(updatedQuiz).catch((err) => console.warn("[RoomSync]", err?.message || err));
    });
  }

  public deleteQuiz(quizId: string) {
    const current = this.getAllQuizzes();
    const filtered = current.filter((q) => q.id !== quizId);
    localStorage.setItem(STORAGE_KEYS.QUIZZES, JSON.stringify(filtered));
    this.notify();
    import("./supabaseStorage").then((m) => {
      m.deleteQuizFromSupabase(quizId).catch((err) => console.warn("[RoomSync]", err?.message || err));
    });
  }

  public clearCourses() {
    localStorage.setItem(STORAGE_KEYS.COURSES, JSON.stringify([]));
    this.notify();
  }

  public clearAssets() {
    localStorage.setItem(STORAGE_KEYS.ASSETS, JSON.stringify([]));
    this.notify();
  }

  public resetToDefault() {
    localStorage.setItem(STORAGE_KEYS.COURSES, JSON.stringify([]));
    localStorage.setItem(STORAGE_KEYS.ASSETS, JSON.stringify([]));
    localStorage.setItem(STORAGE_KEYS.QUIZZES, JSON.stringify([]));
    localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify([]));
    this.notify();
  }

  // --- Student Management & Quiz Scoring ---

  public getAllStudents(): StudentRecord[] {
    const raw = localStorage.getItem(STORAGE_KEYS.STUDENTS);
    if (!raw) return [];
    try {
      return JSON.parse(raw);
    } catch {
      return [];
    }
  }

  public getStudentByUid(uid: string): StudentRecord | null {
    const students = this.getAllStudents();
    return students.find((s) => s.uid === uid) || null;
  }

  public registerOrUpdateStudent(user: UserProfile | StudentRecord) {
    if ((user as any).isAdmin && user.password) {
      localStorage.setItem(STORAGE_KEYS.ADMIN_PASSWORD, user.password);
    }
    const students = this.getAllStudents();
    const existingIndex = students.findIndex((s) => (user.email && (s.email || "").toLowerCase() === (user.email || "").toLowerCase()) || s.uid === user.uid);
    
    const nowStr = `Aujourd'hui, ${new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}`;
    
    const lastSeenTime = (user as any).lastSeen || user.createdAt || Date.now();
    const isOnlineNow = (user as any).lastSeen ? (Date.now() - Number((user as any).lastSeen) < 5 * 60 * 1000) : false;

    if (existingIndex >= 0) {
      students[existingIndex] = {
        ...students[existingIndex],
        displayName: user.displayName || students[existingIndex].displayName,
        level: user.level || students[existingIndex].level,
        status: isOnlineNow ? "En ligne" : "Hors-ligne",
        lastLogin: nowStr,
        lastSeen: lastSeenTime,
        password: user.password || students[existingIndex].password,
        photoUrl: user.avatarUrl || user.photoUrl || students[existingIndex].photoUrl,
        avatarUrl: user.avatarUrl || user.photoUrl || students[existingIndex].avatarUrl,
        isVIP: user.isVIP !== undefined ? user.isVIP : students[existingIndex].isVIP,
        vipPlan: (user as any).vipPlan || students[existingIndex].vipPlan,
        vipExpiresAt: (user as any).vipExpiresAt !== undefined ? (user as any).vipExpiresAt : students[existingIndex].vipExpiresAt,
        authProvider: (user as any).authProvider || students[existingIndex].authProvider,
      };
    } else {
      const newStudent: StudentRecord = {
        uid: user.uid,
        displayName: user.displayName,
        email: user.email,
        level: user.level,
        status: isOnlineNow ? "En ligne" : "Hors-ligne",
        lastLogin: nowStr,
        lastSeen: lastSeenTime,
        createdAt: Date.now(),
        quizResults: (user as any).quizResults || [],
        password: user.password,
        photoUrl: user.avatarUrl || user.photoUrl,
        avatarUrl: user.avatarUrl || user.photoUrl,
        isVIP: user.isVIP,
        vipPlan: (user as any).vipPlan,
        vipExpiresAt: (user as any).vipExpiresAt,
        authProvider: (user as any).authProvider,
      };
      students.unshift(newStudent);
    }

    localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(students));
    this.notify();
  }

  public setUserVIPStatus(uid: string, isVIP: boolean, vipPlan?: string, vipExpiresAt?: number) {
    const students = this.getAllStudents();
    const student = students.find((s) => s.uid === uid);
    if (student) {
      student.isVIP = isVIP;
      student.vipPlan = isVIP ? vipPlan : undefined;
      student.vipExpiresAt = isVIP ? vipExpiresAt : undefined;
      localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(students));
    }
    const currentProfile = this.getUserProfile();
    if (currentProfile && currentProfile.uid === uid) {
      currentProfile.isVIP = isVIP;
      currentProfile.vipPlan = isVIP ? vipPlan : undefined;
      currentProfile.vipExpiresAt = isVIP ? vipExpiresAt : undefined;
      localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(currentProfile));
    }
    this.notify();
    import("./supabaseStorage").then((m) => {
      m.setUserVIPStatusSupabase(uid, isVIP, vipPlan, vipExpiresAt).catch((err) => console.warn("[RoomSync]", err?.message || err));
    });
  }

  public updateStudentLevel(studentUid: string, newLevel: SecondaryLevel): StudentRecord | null {
    const students = this.getAllStudents();
    const student = students.find((s) => s.uid === studentUid);
    if (student) {
      student.level = newLevel;
      student.classe = newLevel;
      localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(students));
    }
    const currentProfile = this.getUserProfile();
    if (currentProfile && (currentProfile.uid === studentUid || (currentProfile as any).id === studentUid)) {
      currentProfile.level = newLevel;
      currentProfile.classe = newLevel;
      localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(currentProfile));
    }

    // Ajouter notification locale
    const now = Date.now();
    const dateFormatted = new Date(now).toLocaleDateString("fr-FR");
    this.addNotification({
      id: "notif_lvl_direct_" + now,
      target_uid: studentUid,
      targetUid: studentUid,
      userUid: studentUid,
      userId: studentUid,
      recipientId: studentUid,
      title: `🎓 Classe mise à jour : ${newLevel}`,
      message: `L'administration a mis à jour votre classe vers ${newLevel}. Vos cours, exercices et devoirs ont été automatiquement actualisés.`,
      type: "class_change",
      status: "unread",
      createdAt: now,
      dateFormatted,
    });

    this.notify();
    import("./supabaseStorage").then((m) => {
      m.updateStudentLevelSupabase(studentUid, newLevel).catch((err) => console.warn("[RoomSync]", err?.message || err));
    });
    return student || null;
  }

  public addQuizResult(studentId: string, result: QuizResultRecord) {
    const students = this.getAllStudents();
    const student = students.find((s) => s.uid === studentId || (s.email || "").toLowerCase() === (result.studentName || "").toLowerCase());
    
    if (student) {
      if (!student.quizResults) {
        student.quizResults = [];
      }
      // Anti-duplicate & Idempotence check: if this quiz was already submitted, update the existing entry
      const existingIdx = student.quizResults.findIndex(
        (r) => (result.quizId && r.quizId === result.quizId) || r.id === result.id
      );
      if (existingIdx !== -1) {
        student.quizResults[existingIdx] = result;
      } else {
        student.quizResults.unshift(result);
      }
    } else {
      // Create record if student wasn't registered yet
      const safeName = result.studentName || "eleve";
      const newStudent: StudentRecord = {
        uid: studentId,
        displayName: result.studentName,
        email: `${safeName.toLowerCase().replace(/\s+/g, ".")}@senegal.sn`,
        level: result.level,
        status: "Hors-ligne",
        lastSeen: Date.now(),
        lastLogin: "Aujourd'hui",
        createdAt: Date.now(),
        quizResults: [result],
      };
      students.unshift(newStudent);
    }

    localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(students));
    this.notify();

    // Auto sync to Supabase with idempotence
    import("./supabaseStorage").then((m) => {
      m.saveQuizResultToSupabase(result).catch((err) => console.warn("[RoomSync]", err?.message || err));
    });
  }

  /**
   * Real-time persistence of in-progress quiz session and timer
   * Prevents timer reset if user leaves, reloads or switches tabs.
   */
  public saveQuizActiveSession(studentUid: string, quizId: string, session: {
    timeLeft: number;
    endTime: number;
    currentQuestionIndex: number;
    selectedAnswers: Record<number, number | number[]>;
    updatedAt: number;
  }) {
    try {
      localStorage.setItem(`savoirplus_quiz_active_session_${studentUid}_${quizId}`, JSON.stringify(session));
      localStorage.setItem(`savoirplus_quiz_timer_${studentUid}_${quizId}`, JSON.stringify({
        timeLeft: session.timeLeft,
        endTime: session.endTime,
        timestamp: session.updatedAt,
      }));
    } catch {}
  }

  public getQuizActiveSession(studentUid: string, quizId: string): {
    timeLeft: number;
    endTime: number;
    currentQuestionIndex: number;
    selectedAnswers: Record<number, number | number[]>;
    updatedAt: number;
  } | null {
    try {
      const raw = localStorage.getItem(`savoirplus_quiz_active_session_${studentUid}_${quizId}`);
      if (raw) return JSON.parse(raw);
    } catch {}
    return null;
  }

  public clearQuizActiveSession(studentUid: string, quizId: string) {
    try {
      localStorage.removeItem(`savoirplus_quiz_active_session_${studentUid}_${quizId}`);
      localStorage.removeItem(`savoirplus_quiz_timer_${studentUid}_${quizId}`);
      localStorage.removeItem(`savoirplus_quiz_draft_${studentUid}_${quizId}`);
      localStorage.removeItem(`savoirplus_active_quiz_id_${studentUid}`);
    } catch {}
  }

  public resetStudentQuizAttempt(studentId: string, quizId: string) {
    const students = this.getAllStudents();
    const student = students.find((s) => s.uid === studentId || (s.email || "").toLowerCase() === studentId.toLowerCase());
    if (student && student.quizResults) {
      student.quizResults = student.quizResults.filter(
        (r) => r.quizId !== quizId && (r as any).quiz_id !== quizId && r.id !== `res_${studentId}_${quizId}`
      );
      localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(students));
    }

    this.clearQuizActiveSession(studentId, quizId);
    this.notify();

    import("./supabaseStorage").then((m) => {
      if (m.deleteQuizResultFromSupabase) {
        m.deleteQuizResultFromSupabase(studentId, quizId).catch((err) => console.warn("[RoomSync]", err?.message || err));
      }
    });
  }

  public getQuizResultsByStudent(studentId: string): QuizResultRecord[] {
    const students = this.getAllStudents();
    const sId = (studentId || "").toLowerCase();
    const student = students.find((s) => s.uid === studentId || (s.email || "").toLowerCase().includes(sId));
    if (!student || !student.quizResults) return [];
    return student.quizResults.sort((a, b) => b.timestamp - a.timestamp);
  }

  // --- User Profile & Offline Sync ---

  public getUserProfile(): UserProfile | null {
    const raw = localStorage.getItem(STORAGE_KEYS.USER);
    if (!raw) return null;
    try {
      return JSON.parse(raw);
    } catch {
      return null;
    }
  }

  public setUserProfile(user: UserProfile) {
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user));
    this.notify();
  }

  public clearUserProfile() {
    localStorage.removeItem(STORAGE_KEYS.USER);
    this.notify();
  }

  public updateUserProfile(updated: Partial<UserProfile>): UserProfile | null {
    const current = this.getUserProfile();
    if (!current) return null;
    const newUser = { ...current, ...updated };
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(newUser));
    this.notify();
    return newUser;
  }

  public toggleAssetOfflineCache(assetId: string): boolean {
    const assets = this.getAllAssets();
    let isNowCached = false;
    const updated = assets.map((a) => {
      if (a.assetId === assetId) {
        isNowCached = !a.isCachedOffline;
        return { ...a, isCachedOffline: isNowCached };
      }
      return a;
    });
    localStorage.setItem(STORAGE_KEYS.ASSETS, JSON.stringify(updated));
    this.notify();
    return isNowCached;
  }

  // SyncWorker
  public async runSyncWorker(userLevel: SecondaryLevel): Promise<boolean> {
    try {
      const { getCoursesByLevelSupabase, getAssetsSupabase, getQuizzesByLevelSupabase } = await import("./supabaseStorage");
      const [courses, assets, quizzes] = await Promise.all([
        getCoursesByLevelSupabase(userLevel),
        getAssetsSupabase(userLevel),
        getQuizzesByLevelSupabase(userLevel),
      ]);
      if (courses && courses.length > 0) this.syncCoursesFromFirebase(courses);
      if (assets && assets.length > 0) this.syncAssetsFromFirebase(assets);
      if (quizzes && quizzes.length > 0) this.syncQuizzesFromFirebase(quizzes);
    } catch (e) {
      console.warn("[RoomStorage] SyncWorker fetch error:", e);
    }
    return true;
  }

  // --- Payment Transactions & Notifications DAO ---

  public getAllTransactions(): PaymentTransaction[] {
    const raw = localStorage.getItem(STORAGE_KEYS.TRANSACTIONS);
    if (!raw) return [];
    try {
      const txs: PaymentTransaction[] = JSON.parse(raw);
      return txs.sort((a, b) => b.createdAt - a.createdAt);
    } catch {
      return [];
    }
  }

  public getTransactionsByUser(userUid: string): PaymentTransaction[] {
    const uUid = (userUid || "").toLowerCase();
    return this.getAllTransactions().filter(
      (t) => t.userUid === userUid || (t.userName || "").toLowerCase() === uUid
    );
  }

  // Règle d'unicité : Le même nom d'apprenant ne peut pas faire 2 mensualités le même mois
  public checkDuplicateMensualite(learnerName: string, month: string): boolean {
    const nameLower = (learnerName || "").trim().toLowerCase();
    const txs = this.getAllTransactions();
    return txs.some(
      (t) =>
        (t.learnerName || "").trim().toLowerCase() === nameLower &&
        t.paymentType === "mensualite" &&
        t.selectedMonth === month &&
        t.status !== "rejected"
    );
  }

  public insertTransaction(tx: PaymentTransaction) {
    const current = this.getAllTransactions();
    current.unshift(tx);
    localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(current));

    // Créer automatiquement une notification "en cours de vérification" pour l'élève
    const notif: UserNotification = {
      id: "notif_" + Date.now(),
      userUid: tx.userUid,
      title: "Paiement en cours de vérification par l'administration",
      message: `Votre transfert ${tx.operator.toUpperCase()} de ${tx.amount.toLocaleString("fr-FR")} FCFA pour l'apprenant "${tx.learnerName}" est enregistré et en cours de vérification par l'administration (78 376 95 84).`,
      type: "payment_status",
      status: "unread",
      transactionId: tx.id,
      createdAt: Date.now(),
      dateFormatted: `Aujourd'hui, ${new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}`,
    };
    this.addNotification(notif);

    this.notify();
    import("./supabaseStorage").then((m) => {
      m.saveTransactionToSupabase(tx).catch((err) => console.warn("[RoomSync]", err?.message || err));
    });
  }

  public updateTransactionStatus(
    txId: string,
    newStatus: TransactionStatus,
    rejectionReason?: string
  ): PaymentTransaction | null {
    const current = this.getAllTransactions();
    const index = current.findIndex((t) => t.id === txId);
    if (index === -1) return null;

    current[index] = {
      ...current[index],
      status: newStatus,
      rejectionReason: rejectionReason || current[index].rejectionReason,
    };
    localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(current));

    const tx = current[index];
    // Envoi de la notification selon le statut
    const isApproved = newStatus === "approved";
    const title = isApproved
      ? "✅ Paiement Validé par l'Administration !"
      : "❌ Paiement Rejeté par l'Administration";
    const message = isApproved
      ? `Félicitations ! Votre paiement de ${tx.amount.toLocaleString("fr-FR")} FCFA pour l'apprenant "${tx.learnerName}" (${tx.type === 'renforcement' ? 'Renforcement au centre' : 'Cours à domicile'}) a été validé avec succès par l'administration. Votre reçu numérique est prêt.`
      : `Le paiement de ${tx.amount.toLocaleString("fr-FR")} FCFA pour l'apprenant "${tx.learnerName}" a été rejeté${rejectionReason ? ` : ${rejectionReason}` : ''}. Veuillez vérifier votre transfert vers le 78 376 95 84.`;

    const notif: UserNotification = {
      id: "notif_" + Date.now(),
      userUid: tx.userUid,
      title,
      message,
      type: "payment_status",
      status: "unread",
      transactionId: tx.id,
      createdAt: Date.now(),
      dateFormatted: `Aujourd'hui, ${new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}`,
    };
    this.addNotification(notif);

    this.notify();
    import("./supabaseStorage").then((m) => {
      m.updateTransactionStatusSupabase(txId, newStatus, rejectionReason).catch((err) => console.warn("[RoomSync]", err?.message || err));
    });
    return current[index];
  }

  public deleteTransaction(txId: string, _userUid?: string) {
    const current = this.getAllTransactions();
    const filtered = current.filter((t) => t.id !== txId);
    localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(filtered));
    this.notify();
    import("./supabaseStorage").then((m) => {
      m.deleteTransactionFromSupabase(txId).catch((err) => console.warn("[RoomSync]", err?.message || err));
    });
  }

  public resetValidatedRevenue() {
    // Supprime uniquement les transactions validées (approved) ou remet leur montant à 0 / réinitialise
    const current = this.getAllTransactions();
    const remaining = current.filter((t) => t.status !== "approved");
    localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(remaining));
    this.notify();
  }

  public clearAllTransactions() {
    localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify([]));
    this.notify();
  }

  private getReadNotifIds(): Set<string> {
    try {
      const raw = localStorage.getItem("savoirplus_read_notif_ids");
      return raw ? new Set<string>(JSON.parse(raw)) : new Set<string>();
    } catch {
      return new Set<string>();
    }
  }

  private saveReadNotifId(notifId: string): void {
    if (!notifId) return;
    try {
      const set = this.getReadNotifIds();
      set.add(notifId);
      localStorage.setItem("savoirplus_read_notif_ids", JSON.stringify(Array.from(set)));
    } catch {
      // Storage fallback
    }
  }

  public getAllNotifications(): UserNotification[] {
    const raw = localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS);
    if (!raw) return [];
    try {
      const notifs: UserNotification[] = JSON.parse(raw);
      const seen = new Set<string>();
      const readSet = this.getReadNotifIds();
      const uniqueNotifs: UserNotification[] = [];
      for (const n of notifs) {
        if (n && n.id && !seen.has(n.id)) {
          seen.add(n.id);
          const isRead = readSet.has(n.id) || n.status === "read";
          uniqueNotifs.push({
            ...n,
            status: isRead ? "read" : "unread",
          });
        }
      }
      return uniqueNotifs.sort((a, b) => b.createdAt - a.createdAt);
    } catch {
      return [];
    }
  }

  public deleteStudent(studentUid: string) {
    // Remove student record
    const students = this.getAllStudents();
    const filteredStudents = students.filter((s) => s.uid !== studentUid);
    localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(filteredStudents));

    // Remove transactions associated with student
    const txs = this.getAllTransactions();
    const filteredTxs = txs.filter((t) => t.userUid !== studentUid);
    localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(filteredTxs));

    // Remove notifications associated with student
    const notifs = this.getAllNotifications();
    const filteredNotifs = notifs.filter((n) => n.userUid !== studentUid);
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(filteredNotifs));

    this.notify();

    // Trigger Supabase cascade deletion
    import("./supabaseStorage").then((m) => {
      m.deleteStudentFromSupabaseCascade(studentUid).catch((err) => console.warn("[RoomSync]", err?.message || err));
    });
  }

  public deleteStudentQuizResult(studentUid: string, timestamp: number) {
    const students = this.getAllStudents();
    const student = students.find((s) => s.uid === studentUid);
    if (student) {
      student.quizResults = student.quizResults.filter((r) => r.timestamp !== timestamp);
      localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(students));
      this.notify();
    }
  }

  public getNotificationsByUser(userUid: string, isAdmin?: boolean): UserNotification[] {
    return this.getAllNotifications().filter(
      (n) => {
        if (isAdmin) {
          return (
            n.target_uid === "admin" ||
            n.targetUid === "admin" ||
            n.targetRole === "admin" ||
            n.recipientId === "admin" ||
            n.type === "admin_alert" ||
            n.type === "admin_broadcast" ||
            n.target_uid === userUid ||
            n.targetUid === userUid ||
            n.userUid === userUid
          );
        }
        return (
          n.target_uid === userUid ||
          n.targetUid === userUid ||
          n.userUid === userUid ||
          n.userId === userUid ||
          n.target_uid === "all" ||
          n.targetUid === "all" ||
          n.userUid === "all" ||
          n.recipientId === userUid
        );
      }
    );
  }

  public addNotification(notif: UserNotification) {
    if (!notif || !notif.id) return;
    const readSet = this.getReadNotifIds();
    const isAlreadyRead = readSet.has(notif.id) || notif.status === "read";
    const resolvedStatus = isAlreadyRead ? "read" : "unread";
    const targetUid = notif.target_uid || notif.targetUid || (notif.recipientId === "admin" || notif.targetRole === "admin" ? "admin" : notif.userUid);
    const normalizedNotif: UserNotification = { 
      ...notif, 
      target_uid: targetUid,
      targetUid: targetUid,
      status: resolvedStatus 
    };

    const current = this.getAllNotifications();
    const existingIndex = current.findIndex((n) => n.id === notif.id);
    if (existingIndex >= 0) {
      const wasRead = current[existingIndex].status === "read" || isAlreadyRead;
      current[existingIndex] = {
        ...current[existingIndex],
        ...normalizedNotif,
        status: wasRead ? "read" : "unread",
      };
    } else {
      // Deduplicate: check if an identical notification for same request was already created recently
      const isDuplicate = current.some(
        (n) =>
          (n.target_uid === notif.target_uid || n.userUid === notif.userUid) &&
          n.type === notif.type &&
          n.title === notif.title &&
          Math.abs(n.createdAt - notif.createdAt) < 180000 // 3 minutes window
      );
      if (!isDuplicate) {
        current.unshift(normalizedNotif);
      }
    }
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(current));
    this.notify();
    import("./supabaseStorage").then((m) => {
      m.saveNotificationToSupabase(normalizedNotif).catch((err) => console.warn("[RoomSync]", err?.message || err));
    });
  }

  public insertNotification(notif: UserNotification) {
    this.addNotification(notif);
  }

  public deleteNotification(notifId: string, _userUid?: string) {
    const current = this.getAllNotifications();
    const filtered = current.filter((n) => n.id !== notifId);
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(filtered));
    this.notify();

    import("./supabaseStorage").then((m) => {
      m.deleteNotificationFromSupabase(notifId).catch((err) => console.warn("[RoomSync]", err?.message || err));
    });
  }

  public clearAllNotifications() {
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify([]));
    this.notify();
    import("./supabaseStorage").then((m) => {
      m.clearAllNotificationsFromSupabase().catch((err) => console.warn("[RoomSync]", err?.message || err));
    });
  }

  public sendAdminMessage(targetUid: string, title: string, message: string) {
    const notif: UserNotification = {
      id: "notif_admin_" + Date.now(),
      target_uid: targetUid,
      targetUid: targetUid,
      userUid: targetUid,
      userId: targetUid,
      recipientId: targetUid,
      title: title.trim() || "📢 Message de l'Administration Génie Mentor Académie (GMA)",
      message: message.trim(),
      type: "admin_broadcast",
      status: "unread",
      createdAt: Date.now(),
      dateFormatted: `Aujourd'hui, ${new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}`,
    };
    this.addNotification(notif);
    import("./supabaseStorage").then((m) => {
      m.saveNotificationToSupabase(notif).catch((err) => console.warn("[RoomSync]", err?.message || err));
    });
  }

  public markNotificationAsRead(notifId: string, _userUid?: string) {
    this.saveReadNotifId(notifId);
    const current = this.getAllNotifications();
    const index = current.findIndex((n) => n.id === notifId);
    if (index >= 0) {
      current[index].status = "read";
      localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(current));
      this.notify();
      import("./supabaseStorage").then((m) => {
        m.markNotificationAsReadInSupabase(notifId).catch((err) => console.warn("[RoomSync]", err?.message || err));
      });
    }
  }

  public markAllNotificationsAsRead(userUid: string) {
    const current = this.getAllNotifications();
    let changed = false;
    current.forEach((n) => {
      const isTargeted =
        n.target_uid === userUid ||
        n.targetUid === userUid ||
        n.userUid === userUid ||
        n.userId === userUid ||
        n.recipientId === userUid ||
        (userUid === "admin" && (n.target_uid === "admin" || n.targetRole === "admin"));
      if (isTargeted && n.status === "unread") {
        n.status = "read";
        this.saveReadNotifId(n.id);
        changed = true;
        import("./supabaseStorage").then((m) => {
          m.markNotificationAsReadInSupabase(n.id).catch((err) => console.warn("[RoomSync]", err?.message || err));
        });
      }
    });
    if (changed) {
      localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(current));
      this.notify();
    }
  }

  public syncNotificationsFromRemote(remoteNotifs: UserNotification[], userUid: string, isAdmin?: boolean) {
    if (!remoteNotifs) return;
    const current = this.getAllNotifications();
    const others = current.filter((n) => {
      if (isAdmin) {
        return !(
          n.target_uid === "admin" ||
          n.targetUid === "admin" ||
          n.targetRole === "admin" ||
          n.recipientId === "admin" ||
          n.target_uid === userUid
        );
      }
      return !(
        n.target_uid === userUid ||
        n.targetUid === userUid ||
        n.userUid === userUid ||
        n.userId === userUid ||
        n.recipientId === userUid
      );
    });

    const readSet = this.getReadNotifIds();
    const updated = [
      ...remoteNotifs.map((n) => ({
        ...n,
        status: (readSet.has(n.id) || n.status === "read") ? ("read" as const) : ("unread" as const),
      })),
      ...others,
    ];

    updated.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(updated));
    this.notify();
  }

  public purgeAllNonAdminStudents(): number {
    const students = this.getAllStudents();
    const remaining = students.filter((s) => {
      const email = (s.email || "").toLowerCase().trim();
      return s.isAdmin || isUserAdmin({ email, isAdmin: s.isAdmin });
    });
    const purgedCount = students.length - remaining.length;
    localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(remaining));
    this.notify();

    // Trigger Supabase purge
    import("./supabaseStorage").then((m) => {
      m.purgeNonAdminUsersFromSupabase().catch((err) => console.warn("[RoomSync]", err?.message || err));
    });

    return purgedCount;
  }

  // --- Class Change Requests DAO ---

  public getAllClassChangeRequests(): ClassChangeRequest[] {
    const raw = localStorage.getItem(STORAGE_KEYS.CLASS_CHANGE_REQUESTS);
    if (!raw) return [];
    try {
      const reqs: ClassChangeRequest[] = JSON.parse(raw);
      return reqs.sort((a, b) => b.createdAt - a.createdAt);
    } catch {
      return [];
    }
  }

  public getClassChangeRequestsByUser(userUid: string): ClassChangeRequest[] {
    return this.getAllClassChangeRequests().filter((r) => r.userUid === userUid);
  }

  public createClassChangeRequest(
    userUid: string,
    userName: string,
    userEmail: string,
    currentLevel: SecondaryLevel,
    requestedLevel: SecondaryLevel,
    reason: string
  ): ClassChangeRequest {
    const reqs = this.getAllClassChangeRequests();
    const now = Date.now();
    const dateFormatted = `Aujourd'hui, ${new Date().toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}`;

    const newReq: ClassChangeRequest = {
      id: "req_lvl_" + now,
      userUid,
      userName,
      userEmail,
      currentLevel,
      requestedLevel,
      reason: reason.trim(),
      status: "pending",
      createdAt: now,
      dateFormatted,
    };

    reqs.unshift(newReq);
    localStorage.setItem(STORAGE_KEYS.CLASS_CHANGE_REQUESTS, JSON.stringify(reqs));

    // Send an admin-only notification
    this.addNotification({
      id: "notif_lvl_admin_" + now,
      target_uid: "admin",
      targetUid: "admin",
      userUid: "admin",
      userId: "admin",
      recipientId: "admin",
      targetRole: "admin",
      title: "Demande de Changement de Classe",
      message: `${userName} (${currentLevel}) demande à passer en classe de ${requestedLevel}. Motif : "${reason.trim()}"`,
      type: "class_change",
      status: "unread",
      createdAt: now,
      dateFormatted,
    });

    this.notify();

    import("./supabaseStorage").then((m) => {
      m.saveClassChangeRequestToSupabase(newReq).catch((err) => console.warn("[RoomSync]", err?.message || err));
    });

    return newReq;
  }

  public deleteClassChangeRequest(requestId: string): void {
    const reqs = this.getAllClassChangeRequests().filter((r) => r.id !== requestId);
    localStorage.setItem(STORAGE_KEYS.CLASS_CHANGE_REQUESTS, JSON.stringify(reqs));
    this.notify();
    import("./supabaseStorage").then((m) => {
      m.deleteClassChangeRequestSupabase(requestId).catch((err) => console.warn("[RoomSync]", err?.message || err));
    });
  }

  public deletePendingClassChangeRequestsByUser(userUid: string): void {
    const reqs = this.getAllClassChangeRequests().filter(
      (r) => !(r.userUid === userUid && r.status === "pending")
    );
    localStorage.setItem(STORAGE_KEYS.CLASS_CHANGE_REQUESTS, JSON.stringify(reqs));
    this.notify();
  }

  public updateClassChangeRequestStatus(
    requestId: string,
    status: ClassChangeStatus,
    rejectionReason?: string
  ): ClassChangeRequest | null {
    const reqs = this.getAllClassChangeRequests();
    const index = reqs.findIndex((r) => r.id === requestId);
    if (index === -1) return null;

    reqs[index].status = status;
    if (rejectionReason) {
      reqs[index].rejectionReason = rejectionReason;
    }

    const req = reqs[index];
    localStorage.setItem(STORAGE_KEYS.CLASS_CHANGE_REQUESTS, JSON.stringify(reqs));

    const now = Date.now();
    const dateFormatted = `Aujourd'hui, ${new Date().toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}`;

    if (status === "approved") {
      // Update user profile if this is the currently logged in user
      const currentUser = this.getUserProfile();
      const reqEmail = (req.userEmail || "").toLowerCase();
      if (currentUser && (currentUser.uid === req.userUid || (currentUser.email || "").toLowerCase() === reqEmail)) {
        this.setUserProfile({
          ...currentUser,
          level: req.requestedLevel,
          classe: req.requestedLevel,
        });
      }

      // Update student record in students list
      const students = this.getAllStudents();
      const stdIndex = students.findIndex((s) => s.uid === req.userUid || (s.email || "").toLowerCase() === reqEmail);
      if (stdIndex >= 0) {
        students[stdIndex].level = req.requestedLevel;
        localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(students));
      }

      // Notify student
      this.addNotification({
        id: "notif_lvl_appr_" + requestId,
        userUid: req.userUid,
        title: "✅ Demande de changement de classe approuvée !",
        message: `Félicitations ! L'administration a accepté votre passage de la classe de ${req.currentLevel} à la classe de ${req.requestedLevel}. Votre espace d'apprentissage a été mis à jour.`,
        type: "class_change",
        status: "unread",
        createdAt: now,
        dateFormatted,
      });
    } else if (status === "rejected") {
      this.addNotification({
        id: "notif_lvl_rej_" + requestId,
        userUid: req.userUid,
        title: "❌ Demande de changement de classe refusée",
        message: `Votre demande de passage en classe de ${req.requestedLevel} a été refusée par l'administration${rejectionReason ? ` (Motif : ${rejectionReason})` : ""}. Vous restez en classe de ${req.currentLevel}.`,
        type: "class_change",
        status: "unread",
        createdAt: now,
        dateFormatted,
      });
    }

    this.notify();

    import("./supabaseStorage").then((m) => {
      m.updateClassChangeRequestStatusSupabase(requestId, status, req.userUid, req.requestedLevel, rejectionReason, req.userName).catch((err) => console.warn("[RoomSync]", err?.message || err));
    });

    return req;
  }

  public syncClassChangeRequest(req: ClassChangeRequest): void {
    if (!req || !req.id) return;
    const reqs = this.getAllClassChangeRequests();
    const idx = reqs.findIndex((r) => r.id === req.id);
    if (idx >= 0) {
      reqs[idx] = { ...reqs[idx], ...req };
    } else {
      reqs.unshift(req);
    }
    localStorage.setItem(STORAGE_KEYS.CLASS_CHANGE_REQUESTS, JSON.stringify(reqs));
    this.notify();
  }

  // --- VIP Payment Requests DAO ---

  public getAllVIPPaymentRequests(): VIPPaymentRequest[] {
    const raw = localStorage.getItem(STORAGE_KEYS.VIP_REQUESTS);
    if (!raw) return [];
    try {
      const reqs: VIPPaymentRequest[] = JSON.parse(raw);
      return reqs.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    } catch {
      return [];
    }
  }

  public syncVIPPaymentRequest(req: VIPPaymentRequest): void {
    if (!req || !req.id) return;
    const reqs = this.getAllVIPPaymentRequests();
    const idx = reqs.findIndex((r) => r.id === req.id);
    if (idx >= 0) {
      reqs[idx] = { ...reqs[idx], ...req };
    } else {
      reqs.unshift(req);
    }
    localStorage.setItem(STORAGE_KEYS.VIP_REQUESTS, JSON.stringify(reqs));
    this.notify();
  }

  public syncAllVIPPaymentRequests(list: VIPPaymentRequest[]): void {
    if (!Array.isArray(list)) return;
    localStorage.setItem(STORAGE_KEYS.VIP_REQUESTS, JSON.stringify(list));
    this.notify();
  }

  public updateVIPPaymentRequestStatusLocal(
    requestId: string,
    status: VIPRequestStatus,
    rejectionReason?: string
  ): VIPPaymentRequest | null {
    const reqs = this.getAllVIPPaymentRequests();
    const index = reqs.findIndex((r) => r.id === requestId);
    if (index === -1) return null;

    reqs[index].status = status;
    if (rejectionReason) {
      reqs[index].rejectionReason = rejectionReason;
    }
    localStorage.setItem(STORAGE_KEYS.VIP_REQUESTS, JSON.stringify(reqs));
    this.notify();
    import("./supabaseStorage").then((m) => {
      m.updateVIPPaymentRequestStatusSupabase(requestId, status, rejectionReason).catch((err) => console.warn("[RoomSync]", err?.message || err));
    });
    return reqs[index];
  }

  // ==========================================
  // DEVOIRS ET TRAVAUX DIRIGÉS (TD) SECTION
  // ==========================================

  public isVipUser(userUid: string): boolean {
    const student = this.getStudentByUid(userUid);
    if (student && student.isVIP) {
      if (student.vipExpiresAt === undefined || student.vipExpiresAt === -1) return true;
      if (student.vipExpiresAt > Date.now()) return true;
    }
    const userProfile = this.getUserProfile();
    if (userProfile && userProfile.uid === userUid) {
      if (userProfile.isAdmin || userProfile.isVIP) return true;
    }
    const raw = localStorage.getItem("savoirplus_vip_users");
    if (!raw) return false;
    try {
      const vips: string[] = JSON.parse(raw);
      return vips.includes(userUid);
    } catch {
      return false;
    }
  }

  public saveHomework(homework: HomeworkSubmission): void {
    this.insertHomework(homework);
  }

  public saveNotification(notif: UserNotification): void {
    this.addNotification(notif);
  }

  public getAllHomeworks(): HomeworkSubmission[] {
    const raw = localStorage.getItem(STORAGE_KEYS.HOMEWORKS);
    if (!raw) return [];
    try {
      return JSON.parse(raw);
    } catch {
      return [];
    }
  }

  public getAllHomeworkSubmissions(): HomeworkSubmission[] {
    return this.getAllHomeworks();
  }

  public getHomeworksByUser(userUid: string): HomeworkSubmission[] {
    return this.getAllHomeworks().filter((h) => h.userUid === userUid);
  }

  public getHomeworksByLevel(level: SecondaryLevel): HomeworkSubmission[] {
    return this.getAllHomeworks().filter((h) => h.level === level);
  }

  public insertHomework(homework: HomeworkSubmission): void {
    const all = this.getAllHomeworks();
    const existingIndex = all.findIndex((h) => h.id === homework.id);
    if (existingIndex >= 0) {
      all[existingIndex] = homework;
    } else {
      all.unshift(homework);
    }
    localStorage.setItem(STORAGE_KEYS.HOMEWORKS, JSON.stringify(all));
    this.notify();

    // Sync to Supabase
    import("./supabaseStorage").then((m) => {
      m.submitHomeworkToSupabase(homework).catch((err) => console.warn("[RoomSync]", err?.message || err));
    });
  }

  public updateHomeworkGrade(
    id: string,
    grade20: number,
    feedback: string,
    annotatedPdfData?: string
  ): HomeworkSubmission | null {
    const all = this.getAllHomeworks();
    const index = all.findIndex((h) => h.id === id);
    if (index < 0) return null;

    const hw = all[index];
    const now = Date.now();
    const dateFormatted = `Aujourd'hui, ${new Date().toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}`;

    hw.status = "graded";
    hw.grade20 = grade20;
    hw.feedback = feedback;
    if (annotatedPdfData) {
      hw.annotatedPdfData = annotatedPdfData;
    }
    hw.gradedAt = now;
    hw.gradedBy = "Massaw Seck";

    all[index] = hw;
    localStorage.setItem(STORAGE_KEYS.HOMEWORKS, JSON.stringify(all));

    // Send notification to student
    this.addNotification({
      id: "notif_hw_graded_" + now,
      userUid: hw.userUid,
      title: `📝 Devoir Corrigé : ${hw.title} (${hw.subject})`,
      message: `Votre devoir de ${hw.subject} a été corrigé par le professeur Massaw Seck. Note obtenue : ${grade20}/20. Appréciation : "${feedback || "Bon travail !"}"`,
      type: "general",
      status: "unread",
      createdAt: now,
      dateFormatted,
    });

    this.notify();

    // Sync to Supabase
    import("./supabaseStorage").then((m) => {
      m.gradeHomeworkInSupabase(id, grade20, feedback, "Massaw Seck", annotatedPdfData).catch((err) => console.warn("[RoomSync]", err?.message || err));
    });

    return hw;
  }

  public deleteVIPPaymentRequest(requestId: string): void {
    const reqs = this.getAllVIPPaymentRequests().filter((r) => r.id !== requestId);
    localStorage.setItem(STORAGE_KEYS.VIP_REQUESTS, JSON.stringify(reqs));
    this.notify();
    import("./supabaseStorage").then((m) => {
      m.deleteVIPPaymentRequestFromSupabase(requestId).catch((err) => console.warn("[RoomSync]", err?.message || err));
    });
  }

  public deleteCaisseTransaction(id: string): void {
    const raw = localStorage.getItem("savoirplus_caisse_transactions");
    if (raw) {
      try {
        const list = JSON.parse(raw);
        const filtered = list.filter((t: any) => t.id !== id);
        localStorage.setItem("savoirplus_caisse_transactions", JSON.stringify(filtered));
      } catch {}
    }
    this.notify();
    import("./supabaseStorage").then((m) => {
      m.deleteCaisseTransactionFromSupabase(id).catch((err) => console.warn("[RoomSync]", err?.message || err));
    });
  }

  public clearAllCaisseTransactions(): void {
    localStorage.setItem("savoirplus_caisse_transactions", JSON.stringify([]));
    this.notify();
    import("./supabaseStorage").then((m) => {
      m.deleteAllCaisseTransactionsFromSupabase().catch((err) => console.warn("[RoomSync]", err?.message || err));
    });
  }

  public deleteHomework(id: string): void {
    const all = this.getAllHomeworks().filter((h) => h.id !== id);
    localStorage.setItem(STORAGE_KEYS.HOMEWORKS, JSON.stringify(all));
    this.notify();

    // Delete in Supabase
    import("./supabaseStorage").then((m) => {
      m.deleteHomeworkFromSupabase(id).catch((err) => console.warn("[RoomSync]", err?.message || err));
    });
  }
}
