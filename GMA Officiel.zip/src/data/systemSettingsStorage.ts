import { supabase } from "../lib/supabaseClient";
import { SystemSettings, DEFAULT_SYSTEM_SETTINGS } from "../types/systemSettings";
import { useState, useEffect, useCallback } from "react";

const STORAGE_KEY = "gma_system_settings_v1";

/**
 * Calculates a slightly darker shade for hover states.
 */
function adjustHex(hex: string, percent: number): string {
  let clean = hex.replace("#", "");
  if (clean.length === 3) {
    clean = clean.split("").map((c) => c + c).join("");
  }
  const num = parseInt(clean, 16);
  if (isNaN(num)) return hex;
  let r = (num >> 16) + percent;
  let g = ((num >> 8) & 0x00ff) + percent;
  let b = (num & 0x0000ff) + percent;
  r = Math.min(255, Math.max(0, r));
  g = Math.min(255, Math.max(0, g));
  b = Math.min(255, Math.max(0, b));
  return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
}

/**
 * Applies the system theme to standard CSS variables and document metadata.
 * Changes are instantaneous across all components without page reload.
 */
export function applySystemTheme(settings: SystemSettings): void {
  if (typeof document === "undefined") return;

  const root = document.documentElement;
  const primary = settings.primaryColor || DEFAULT_SYSTEM_SETTINGS.primaryColor;
  const secondary = settings.secondaryColor || DEFAULT_SYSTEM_SETTINGS.secondaryColor;
  const accent = settings.accentColor || DEFAULT_SYSTEM_SETTINGS.accentColor;

  root.style.setProperty("--color-primary", primary);
  root.style.setProperty("--color-primary-hover", adjustHex(primary, -20));
  root.style.setProperty("--color-secondary", secondary);
  root.style.setProperty("--color-secondary-hover", adjustHex(secondary, -20));
  root.style.setProperty("--color-accent", accent);
  root.style.setProperty("--color-accent-hover", adjustHex(accent, -20));

  // Update document title if customized
  if (settings.appName && settings.appName.trim() !== "") {
    document.title = `${settings.appName} • Excellence Scolaire Offline-First`;
  }

  // Update favicon if provided
  const activeFavicon = settings.faviconUrl;
  if (activeFavicon && activeFavicon.trim() !== "") {
    try {
      let link = document.querySelector("link[rel*='icon']") as HTMLLinkElement | null;
      if (!link) {
        link = document.createElement("link");
        link.type = "image/png";
        link.rel = "icon";
        document.head.appendChild(link);
      }
      link.href = activeFavicon;

      let shortcut = document.querySelector("link[rel='shortcut icon']") as HTMLLinkElement | null;
      if (shortcut) {
        shortcut.href = activeFavicon;
      }
    } catch {}
  }
}

/**
 * Gets cached system settings from localStorage for instant 0ms startup.
 */
export function getLocalSystemSettings(): SystemSettings {
  if (typeof window === "undefined") return DEFAULT_SYSTEM_SETTINGS;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    const savedFavicon = localStorage.getItem("gma_favicon_data") || localStorage.getItem("savoir_favicon_url");
    if (raw) {
      const parsed = JSON.parse(raw);
      const res = { ...DEFAULT_SYSTEM_SETTINGS, ...parsed };
      if (savedFavicon && savedFavicon.trim() !== "") {
        res.faviconUrl = savedFavicon;
      }
      return res;
    } else if (savedFavicon && savedFavicon.trim() !== "") {
      return { ...DEFAULT_SYSTEM_SETTINGS, faviconUrl: savedFavicon };
    }
  } catch {
    // Ignore JSON parsing errors
  }
  return DEFAULT_SYSTEM_SETTINGS;
}

/**
 * Saves system settings to localStorage and immediately applies CSS variables.
 */
export function saveLocalSystemSettings(settings: SystemSettings): void {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
  } catch {
    // Ignore storage quota
  }
  applySystemTheme(settings);
  window.dispatchEvent(new CustomEvent("gma_system_settings_changed", { detail: settings }));
}

/**
 * Loads system settings from Supabase (table system_settings).
 */
export async function fetchSystemSettingsFromSupabase(): Promise<SystemSettings> {
  const current = getLocalSystemSettings();
  if (!supabase) return current;

  try {
    // 1. SELECT sans filtre restrictif sur l'ID (fonctionne quel que soit l'ID: 1, '1', 'main', etc.)
    let data: any = null;
    const { data: rows, error } = await supabase
      .from("system_settings")
      .select("*")
      .order("updated_at", { ascending: false })
      .limit(1);

    if (!error && rows && rows.length > 0) {
      data = rows[0];
    } else {
      // Fallback sans tri si updated_at n'est pas présent
      const { data: fallbackRows } = await supabase
        .from("system_settings")
        .select("*")
        .limit(1);
      if (fallbackRows && fallbackRows.length > 0) {
        data = fallbackRows[0];
      }
    }

    // 2. Fallback de secours sur app_settings si system_settings n'a pas retourné de ligne
    if (!data) {
      const { data: appData } = await supabase
        .from("app_settings")
        .select("*")
        .maybeSingle();
      if (appData) data = appData;
    }

    if (data) {
      // Parse structured or JSON payload
      const jsonSettings = typeof data.settings_json === "string" 
        ? JSON.parse(data.settings_json) 
        : (data.settings_json || {});

      const resolvedFavicon = data.favicon_url || jsonSettings.faviconUrl || current.faviconUrl;

      const merged: SystemSettings = {
        ...current,
        ...jsonSettings,
        id: data.id ? String(data.id) : "main",
        // 1. Identité
        appName: data.app_name || jsonSettings.appName || current.appName,
        shortName: data.short_name || jsonSettings.shortName || current.shortName,
        description: data.description || jsonSettings.description || current.description,

        // 2. Charte Graphique
        primaryColor: data.primary_color || jsonSettings.primaryColor || current.primaryColor,
        secondaryColor: data.secondary_color || jsonSettings.secondaryColor || current.secondaryColor,
        accentColor: data.accent_color || jsonSettings.accentColor || current.accentColor,

        // 3. Médias
        faviconUrl: resolvedFavicon,
        pwaIconUrl: data.pwa_icon_url || data.pwa_icon_512_url || data.logo_url || jsonSettings.pwaIconUrl || current.pwaIconUrl,
        pwaIcon192Url: data.pwa_icon_192_url || jsonSettings.pwaIcon192Url || current.pwaIcon192Url,
        pwaIcon512Url: data.pwa_icon_512_url || jsonSettings.pwaIcon512Url || current.pwaIcon512Url,
        logoUrl: data.logo_url || jsonSettings.logoUrl || current.logoUrl,
        adminSignatureUrl: data.admin_signature_url || data.official_signature || jsonSettings.adminSignatureUrl || current.adminSignatureUrl,

        // 4. Opérations & Paiements
        registrationStatus: (data.registration_status || jsonSettings.registrationStatus || current.registrationStatus) === "closed" ? "closed" : "open",
        waveMerchantNumber: data.wave_merchant_number || jsonSettings.waveMerchantNumber || current.waveMerchantNumber,
        omMerchantNumber: data.om_merchant_number || jsonSettings.omMerchantNumber || current.omMerchantNumber,
        paymentGuide: data.payment_guide || jsonSettings.paymentGuide || current.paymentGuide,

        // 5. Communication
        whatsappSupport: data.whatsapp_support || data.support_phone || jsonSettings.whatsappSupport || current.whatsappSupport,
        supportEmail: data.support_email || jsonSettings.supportEmail || current.supportEmail,
        communityUrl: data.community_url || jsonSettings.communityUrl || current.communityUrl,
        announcementBanner: data.announcement_banner || data.announcement_text || jsonSettings.announcementBanner || current.announcementBanner,
        announcementBannerActive: data.announcement_banner_active !== undefined 
          ? Boolean(data.announcement_banner_active) 
          : (jsonSettings.announcementBannerActive !== undefined ? Boolean(jsonSettings.announcementBannerActive) : current.announcementBannerActive),

        // Mises à jour & APK
        latestVersion: data.latest_version || data.version || data.app_version || jsonSettings.latestVersion || current.latestVersion,
        apkUrl: data.apk_url || jsonSettings.apkUrl || current.apkUrl,
        updateMessage: data.message || jsonSettings.updateMessage || current.updateMessage,
        updatedAt: Number(data.updated_at || Date.now()),
      };

      if (resolvedFavicon && resolvedFavicon.trim() !== "") {
        try {
          localStorage.setItem("gma_favicon_data", resolvedFavicon);
          localStorage.setItem("savoir_favicon_url", resolvedFavicon);
        } catch {}
      }

      const res192 = merged.pwaIcon192Url || (data.pwa_icon_192_url ? String(data.pwa_icon_192_url) : "");
      const res512 = merged.pwaIcon512Url || (data.pwa_icon_512_url ? String(data.pwa_icon_512_url) : "");

      if (res192 && res192.trim() !== "") {
        try {
          localStorage.setItem("gma_pwa_icon_192_data", res192);
        } catch {}
      }
      if (res512 && res512.trim() !== "") {
        try {
          localStorage.setItem("gma_pwa_icon_512_data", res512);
        } catch {}
      }

      // Synchronize dynamic Web App Manifest
      try {
        import("../utils/dynamicManifest").then(({ updateDynamicManifest }) => {
          updateDynamicManifest({
            icon192: res192 || undefined,
            icon512: res512 || undefined,
            appName: merged.appName,
            shortName: merged.shortName,
          });
        }).catch(() => {});
      } catch {}

      saveLocalSystemSettings(merged);
      return merged;
    }
  } catch (err) {
    console.warn("[Supabase] system_settings load notice:", err);
  }

  return current;
}

/**
 * Persists system settings into Supabase table 'system_settings' with fallback resiliency.
 */
export async function saveSystemSettingsToSupabase(
  newSettings: Partial<SystemSettings>,
  updatedBy = "Admin"
): Promise<SystemSettings> {
  const current = getLocalSystemSettings();
  const now = Date.now();
  const updated: SystemSettings = {
    ...current,
    ...newSettings,
    updatedAt: now,
    updatedBy,
  };

  // 1. Immediately apply and save locally (zero latency)
  saveLocalSystemSettings(updated);

  if (!supabase) return updated;

  // 2. Prepare database payload mapping to all categories
  const dbPayload: Record<string, any> = {
    // 1. Identité
    app_name: updated.appName,
    short_name: updated.shortName,
    description: updated.description,

    // 2. Charte Graphique
    primary_color: updated.primaryColor,
    secondary_color: updated.secondaryColor,
    accent_color: updated.accentColor,

    // 3. Médias
    favicon_url: updated.faviconUrl,
    pwa_icon_url: updated.pwaIcon192Url || updated.pwaIconUrl,
    pwa_icon_192_url: updated.pwaIcon192Url || updated.pwaIconUrl,
    pwa_icon_512_url: updated.pwaIcon512Url || updated.logoUrl || updated.pwaIconUrl,
    logo_url: updated.logoUrl || updated.pwaIcon512Url || updated.pwaIconUrl,
    admin_signature_url: updated.adminSignatureUrl,
    official_signature: updated.adminSignatureUrl,

    // 4. Opérations & Paiements
    registration_status: updated.registrationStatus,
    wave_merchant_number: updated.waveMerchantNumber,
    om_merchant_number: updated.omMerchantNumber,
    payment_guide: updated.paymentGuide,

    // 5. Communication
    whatsapp_support: updated.whatsappSupport,
    support_phone: updated.whatsappSupport,
    support_email: updated.supportEmail,
    community_url: updated.communityUrl,
    announcement_banner: updated.announcementBanner,
    announcement_text: updated.announcementBanner,
    announcement_banner_active: updated.announcementBannerActive,

    // APK & Mises à jour
    latest_version: updated.latestVersion,
    version: updated.latestVersion,
    app_version: updated.latestVersion,
    apk_url: updated.apkUrl,
    message: updated.updateMessage,

    // Complete JSON state for forward compatibility
    settings_json: updated,
    updated_at: now,
    updated_by: updatedBy,
  };

  try {
    // ÉTAPE A : Vérifier s'il existe déjà une ligne dans system_settings (ex: id = 1 ou id = 'main')
    const { data: existingRows } = await supabase.from("system_settings").select("id").limit(1);
    let saved = false;

    if (existingRows && existingRows.length > 0) {
      const existingId = existingRows[0].id;
      dbPayload.id = existingId;
      const { error: updErr } = await supabase
        .from("system_settings")
        .update(dbPayload)
        .eq("id", existingId);

      if (!updErr) saved = true;
    }

    if (!saved) {
      // ÉTAPE B : Tentative d'insertion avec id = 1 puis 'main'
      dbPayload.id = 1;
      const { error: ups1Err } = await supabase.from("system_settings").upsert(dbPayload);
      if (!ups1Err) {
        saved = true;
      } else {
        dbPayload.id = "main";
        const { error: upsMainErr } = await supabase.from("system_settings").upsert(dbPayload);
        if (!upsMainErr) saved = true;
      }
    }
  } catch (err) {
    console.warn("[Supabase] Notice saving to system_settings:", err);
  }

  // 3. Keep backward-compatible 'app_config' table in sync
  try {
    await supabase.from("app_config").upsert({
      id: "main",
      app_name: updated.appName,
      global_version: updated.latestVersion,
      latest_version: updated.latestVersion,
      apk_url: updated.apkUrl,
      message: updated.updateMessage,
      logo_url: updated.pwaIconUrl,
      official_signature: updated.adminSignatureUrl,
      announcement_text: updated.announcementBanner,
      support_phone: updated.whatsappSupport,
      updated_at: now,
    });
  } catch {
    // Non-blocking
  }

  return updated;
}

/**
 * Subscribes in real-time to Supabase changes on 'system_settings'.
 */
export function subscribeToSystemSettings(
  callback: (settings: SystemSettings) => void
): () => void {
  // Always trigger immediately with current local configuration
  callback(getLocalSystemSettings());

  if (!supabase) return () => {};

  const channelName = `sys_settings_realtime_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  const channel = supabase
    .channel(channelName)
    .on(
      "postgres_changes",
      { event: "*", schema: "public", table: "system_settings" },
      async () => {
        const fresh = await fetchSystemSettingsFromSupabase();
        callback(fresh);
      }
    )
    .subscribe();

  // Also listen for local cross-tab or in-app changes
  const handleLocalChange = (e: Event) => {
    const custom = e as CustomEvent<SystemSettings>;
    if (custom.detail) {
      callback(custom.detail);
    }
  };
  if (typeof window !== "undefined") {
    window.addEventListener("gma_system_settings_changed", handleLocalChange);
  }

  return () => {
    supabase.removeChannel(channel);
    if (typeof window !== "undefined") {
      window.removeEventListener("gma_system_settings_changed", handleLocalChange);
    }
  };
}

/**
 * Hook to consume and update system settings with instant reactivity.
 */
export function useSystemSettings() {
  const [settings, setSettings] = useState<SystemSettings>(() => getLocalSystemSettings());
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    // Apply local theme immediately
    applySystemTheme(settings);

    // Fetch latest from Supabase
    fetchSystemSettingsFromSupabase().then((remote) => {
      setSettings(remote);
    });

    // Subscribe to live changes
    const unsub = subscribeToSystemSettings((updated) => {
      setSettings(updated);
    });

    return () => unsub();
  }, []);

  const updateSettings = useCallback(async (partial: Partial<SystemSettings>, updatedBy?: string) => {
    setIsSaving(true);
    try {
      const res = await saveSystemSettingsToSupabase(partial, updatedBy);
      setSettings(res);
      return res;
    } finally {
      setIsSaving(false);
    }
  }, []);

  const refreshSettings = useCallback(async () => {
    const remote = await fetchSystemSettingsFromSupabase();
    setSettings(remote);
    return remote;
  }, []);

  return {
    settings,
    updateSettings,
    refreshSettings,
    isSaving,
  };
}
