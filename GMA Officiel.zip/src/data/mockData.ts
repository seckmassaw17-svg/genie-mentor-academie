import { Course, Asset, Quiz, SecondaryLevel, Subject, StudentRecord } from "../types";

// Standardized levels for Senegal Secondary Education (Collège & Lycée)
// Cycle Moyen : 6ème, 5ème, 4ème, 3ème
// Cycle Secondaire : 2nde S, 2nde L, 1ère S1, 1ère S2, 1ère L1, 1ère L2, 1ère L', Terminale S1, Terminale S2, Terminale L1, Terminale L2, Terminale L'
export const STUDENT_LEVELS: SecondaryLevel[] = [
  "6ème",
  "5ème",
  "4ème",
  "3ème",
  "2nde S",
  "2nde L",
  "1ère S1",
  "1ère S2",
  "1ère L1",
  "1ère L2",
  "1ère L'",
  "Terminale S1",
  "Terminale S2",
  "Terminale L1",
  "Terminale L2",
  "Terminale L'",
];

export const COLLEGE_LEVELS: SecondaryLevel[] = ["6ème", "5ème", "4ème", "3ème"];

export const LYCEE_LEVELS: SecondaryLevel[] = [
  "2nde S",
  "2nde L",
  "1ère S1",
  "1ère S2",
  "1ère L1",
  "1ère L2",
  "1ère L'",
  "Terminale S1",
  "Terminale S2",
  "Terminale L1",
  "Terminale L2",
  "Terminale L'",
];

export const ALL_LEVELS: SecondaryLevel[] = [
  "6ème",
  "5ème",
  "4ème",
  "3ème",
  "2nde S",
  "2nde L",
  "1ère S1",
  "1ère S2",
  "1ère L1",
  "1ère L2",
  "1ère L'",
  "Terminale S1",
  "Terminale S2",
  "Terminale L1",
  "Terminale L2",
  "Terminale L'",
  "GMA",
  "Génie Mentor Académie",
  "Savoir+",
  "Concours",
  "Examens",
  "Exercices Avancés"
];

export const ALL_SUBJECTS: Subject[] = [
  "Maths", "Physique-Chimie", "SVT", "Français", "Histoire-Géo", "Anglais", "Philo", "Informatique"
];

/**
 * Returns formatted and standardized label for a level
 */
export function getLevelLabel(level: SecondaryLevel | string | undefined | null): string {
  if (!level) return "Non défini";
  const norm = normalizeLevel(level);
  switch (norm) {
    case "6ème":
      return "6ème";
    case "5ème":
      return "5ème";
    case "4ème":
      return "4ème";
    case "3ème":
      return "3ème";
    case "2nde S":
      return "2nde S";
    case "2nde L":
      return "2nde L";
    case "1ère S1":
      return "1ère S1";
    case "1ère S2":
      return "1ère S2";
    case "1ère L1":
      return "1ère L1";
    case "1ère L2":
      return "1ère L2";
    case "1ère L'":
      return "1ère L'";
    case "Terminale S1":
      return "Terminale S1";
    case "Terminale S2":
      return "Terminale S2";
    case "Terminale L1":
      return "Terminale L1";
    case "Terminale L2":
      return "Terminale L2";
    case "Terminale L'":
      return "Terminale L'";
    default:
      return String(norm || level);
  }
}

/**
 * Normalizes user input level to standard SecondaryLevel format
 */
export function normalizeLevel(level: string | undefined | null): SecondaryLevel {
  if (!level) return "3ème";
  const trimmed = level.trim();
  
  // Cycle Moyen
  if (/^(classe de )?6(e|ème|eme|ième|ieme)?$/i.test(trimmed) || trimmed === "Sixième" || trimmed === "Sixieme") return "6ème";
  if (/^(classe de )?5(e|ème|eme|ième|ieme)?$/i.test(trimmed) || trimmed === "Cinquième" || trimmed === "Cinquieme") return "5ème";
  if (/^(classe de )?4(e|ème|eme|ième|ieme)?$/i.test(trimmed) || trimmed === "Quatrième" || trimmed === "Quatrieme") return "4ème";
  if (/^(classe de )?3(e|ème|eme|ième|ieme)?(\s*\(?bfem\)?)?$/i.test(trimmed) || trimmed === "3ème prépa" || trimmed === "Troisième" || trimmed === "Troisieme") return "3ème";
  
  // Secondes
  if (/^(classe de )?(2nde?|seconde)\s*s$/i.test(trimmed) || trimmed === "2S") return "2nde S";
  if (/^(classe de )?(2nde?|seconde)\s*l$/i.test(trimmed) || trimmed === "2L") return "2nde L";
  if (/^(classe de )?(2nde?|seconde)$/i.test(trimmed)) return "2nde S";
  
  // Premières
  if (/^(classe de )?(1re|1ère|1ere|première)\s*s1$/i.test(trimmed) || trimmed === "1S1") return "1ère S1";
  if (/^(classe de )?(1re|1ère|1ere|première)\s*s2$/i.test(trimmed) || trimmed === "1S2") return "1ère S2";
  if (/^(classe de )?(1re|1ère|1ere|première)\s*l1$/i.test(trimmed) || trimmed === "1L1") return "1ère L1";
  if (/^(classe de )?(1re|1ère|1ere|première)\s*l2$/i.test(trimmed) || trimmed === "1L2") return "1ère L2";
  if (/^(classe de )?(1re|1ère|1ere|première)\s*l'?$/i.test(trimmed) || trimmed === "1L'") return "1ère L'";
  if (/^(classe de )?(1re|1ère|1ere|première)$/i.test(trimmed)) return "1ère S2";

  // Terminales
  if (/^(classe de )?(tle|terminale?)\s*s1$/i.test(trimmed) || trimmed === "TS1") return "Terminale S1";
  if (/^(classe de )?(tle|terminale?)\s*s2$/i.test(trimmed) || trimmed === "TS2" || /^(classe de )?(tle|terminale?)$/i.test(trimmed) || trimmed === "Terminale prépa" || trimmed === "Terminale BAC") return "Terminale S2";
  if (/^(classe de )?(tle|terminale?)\s*l1$/i.test(trimmed) || trimmed === "TL1") return "Terminale L1";
  if (/^(classe de )?(tle|terminale?)\s*l2$/i.test(trimmed) || trimmed === "TL2") return "Terminale L2";
  if (/^(classe de )?(tle|terminale?)\s*l'?$/i.test(trimmed) || trimmed === "TL'") return "Terminale L'";

  // GMA / Savoir+
  if (/^(savoir\+?|savoirplus|savoir-plus|gma|génie mentor académie)$/i.test(trimmed)) return "GMA";

  return trimmed as SecondaryLevel;
}

export function isLevelMatching(lvlA: string | undefined | null, lvlB: string | undefined | null): boolean {
  if (!lvlA || !lvlB) return false;
  if (lvlA === "ALL" || lvlB === "ALL" || lvlA === "Tous" || lvlB === "Tous") return true;
  return normalizeLevel(lvlA) === normalizeLevel(lvlB);
}

export function getSubjectsForLevel(level: SecondaryLevel | string): Subject[] {
  const norm = normalizeLevel(level);
  if (norm === "6ème" || norm === "5ème") {
    return ["Maths", "SVT", "Français", "Anglais", "Histoire-Géo"];
  }
  if (norm === "4ème" || norm === "3ème") {
    return ["Maths", "Physique-Chimie", "SVT", "Français", "Anglais", "Histoire-Géo"];
  }
  if (norm === "2nde S") {
    return ["Maths", "Physique-Chimie", "SVT", "Français", "Anglais", "Histoire-Géo"];
  }
  if (norm === "2nde L") {
    return ["Français", "Histoire-Géo", "Anglais", "Maths", "SVT"];
  }
  if (norm === "1ère S1" || norm === "1ère S2") {
    return ["Maths", "Physique-Chimie", "SVT", "Français", "Anglais", "Histoire-Géo"];
  }
  if (norm === "1ère L1" || norm === "1ère L2" || norm === "1ère L'") {
    return ["Français", "Histoire-Géo", "Anglais", "Philo", "Maths", "SVT"];
  }
  if (norm === "Terminale S1" || norm === "Terminale S2") {
    return ["Maths", "Physique-Chimie", "SVT", "Français", "Philo", "Histoire-Géo", "Anglais"];
  }
  if (norm === "Terminale L1" || norm === "Terminale L2" || norm === "Terminale L'") {
    return ["Philo", "Français", "Histoire-Géo", "Anglais", "Maths"];
  }
  return ALL_SUBJECTS;
}

// NO MOCK DATA: Clean initial arrays - data must strictly come from Supabase SELECT
export const INITIAL_COURSES: Course[] = [];
export const INITIAL_ASSETS: Asset[] = [];
export const INITIAL_QUIZZES: Quiz[] = [];
export const INITIAL_STUDENTS: StudentRecord[] = [];

export const CONSEIL_DU_JOUR = [
  "« N'apprends pas seulement pour réussir tes examens, apprends pour maîtriser ton avenir ! » - Massaw Seck",
  "Organisation BFEM / BAC : Fais des fiches de révision courtes après chaque cours et refais 2 exercices types sans regarder le corrigé.",
  "La régularité bat le talent : 30 minutes de révision quotidienne valent mieux que 5 heures la veille d'un contrôle !",
  "En mathématiques, refaire les figures géométriques à main levée aide à mieux visualiser les théorèmes de Thalès et Pythagore."
];
