import { supabase, isSupabaseConfigured } from "../lib/supabaseClient";
import { syncUserToFirestore } from "../lib/firebaseClient";
import { APP_VERSION } from "../constants/version";
import { ADMIN_EMAILS } from "../utils/vipUtils";
import {
  Course,
  Asset,
  Quiz,
  Subject,
  UserProfile,
  SecondaryLevel,
  ClassChangeRequest,
  ClassChangeStatus,
  VIPPaymentRequest,
  VIPRequestStatus,
  HomeworkSubmission,
  QuizResultRecord,
  StudentRecord,
  UserNotification,
  CaisseTransaction,
  PaymentTransaction,
  TransactionStatus,
  TutorialVideo,
  AdminAuditLog,
} from "../types";

/**
 * Returns true if Supabase URL and Anon Key are configured and available.
 */
export function isSupabaseActive(): boolean {
  return isSupabaseConfigured && supabase !== null;
}

/**
 * Safely parses any date representation (numeric milliseconds, numeric string, or ISO TIMESTAMPTZ string)
 * into a valid numeric timestamp.
 */
export function safeParseTime(val: any): number {
  if (!val) return Date.now();
  if (typeof val === "number") return val;
  const num = Number(val);
  if (!isNaN(num)) return num;
  const parsed = Date.parse(val);
  return isNaN(parsed) ? Date.now() : parsed;
}

/**
 * Safely logs Supabase errors. If the table is not found (PGRST205 / schema cache),
 * invalid API key, network error, or unauthorized, it logs a gentle warning rather than
 * an unhandled error so offline-first Room local storage operates cleanly.
 */
export function logSupabaseError(context: string, error: any) {
  const msg = (typeof error === "string" ? error : error?.message || error?.hint || JSON.stringify(error) || "").toLowerCase();
  const isOfflineOrKeyOrCache =
    error?.code === "PGRST205" ||
    error?.code === "401" ||
    error?.code === "403" ||
    error?.status === 401 ||
    error?.status === 403 ||
    msg.includes("could not find the table") ||
    msg.includes("schema cache") ||
    msg.includes("invalid api key") ||
    msg.includes("invalid-api-key") ||
    msg.includes("double check your supabase") ||
    msg.includes("apikey") ||
    msg.includes("jwt") ||
    msg.includes("unauthorized") ||
    msg.includes("forbidden") ||
    msg.includes("hors-ligne") ||
    msg.includes("offline") ||
    msg.includes("failed to fetch") ||
    msg.includes("networkerror") ||
    msg.includes("load failed") ||
    msg.includes("aborted");

  if (isOfflineOrKeyOrCache) {
    console.warn(
      `[Supabase] Accès distant indisponible pour ${context} (${error?.code || error?.message || "Hors-ligne/Clé en attente"}). Bascule transparente sur la base locale Room.`
    );
    return;
  }
  console.warn(`[Supabase] ${context}:`, error);
}

// ============================================================================
// 1. AUTHENTICATION (Session recovery, local persistence, clean error handling)
// ============================================================================

export async function signInWithEmailSupabase(
  email: string,
  password: string
): Promise<UserProfile> {
  if (!supabase) {
    throw new Error("Connexion Supabase non initialisée. Veuillez vérifier la configuration.");
  }
  const cleanEmail = (email || "").trim().toLowerCase();

  const { data, error } = await supabase.auth.signInWithPassword({
    email: cleanEmail,
    password,
  });

  if (error) {
    console.warn("[Supabase Auth] signInWithPassword notice:", error.message || error);
    const msg = error.message || "";
    if (
      msg.includes("Invalid login credentials") ||
      msg.includes("invalid_grant") ||
      msg.includes("invalid_credentials")
    ) {
      throw new Error("Identifiants invalides : email ou mot de passe incorrect.");
    }
    if (msg.includes("Email not confirmed")) {
      throw new Error("Veuillez confirmer votre adresse email avant de vous connecter.");
    }
    if (msg.includes("network") || msg.includes("Failed to fetch")) {
      throw new Error("Problème de connexion réseau. Veuillez réessayer.");
    }
    throw new Error(msg || "Erreur de connexion.");
  }

  if (!data.user) {
    throw new Error("Utilisateur introuvable.");
  }

  const isSuperAdmin =
    cleanEmail === "massperpendiculaire@gmail.com" ||
    cleanEmail === "massaw.seck@unchk.edu.sn" ||
    cleanEmail === "massaw.savoirplus@gmail.com";

  // Fetch or bootstrap profile
  let profile = await getUserProfileFromSupabase(data.user.id);

  if (!profile) {
    profile = {
      uid: data.user.id,
      email: cleanEmail,
      displayName: data.user.user_metadata?.display_name || cleanEmail.split("@")[0],
      role: isSuperAdmin ? "admin" : (data.user.user_metadata?.role || "eleve"),
      level: undefined,
      classe: undefined,
      phoneNumber: data.user.user_metadata?.phone || "",
      phone: data.user.user_metadata?.phone || "",
      isAdmin: isSuperAdmin,
      isVIP: isSuperAdmin,
      isProfileComplete: isSuperAdmin,
      createdAt: Date.now(),
    };
    try {
      await saveUserProfileToSupabase(profile);
    } catch (saveErr) {
      console.warn("[Supabase] Profile bootstrap notice:", saveErr);
    }
  } else if (isSuperAdmin && (!profile.isAdmin || !profile.isVIP)) {
    profile.isAdmin = true;
    profile.isVIP = true;
    profile.role = "admin";
    profile.level = undefined;
    profile.classe = undefined;
    try {
      await saveUserProfileToSupabase(profile);
    } catch (saveErr) {
      console.warn("[Supabase] Admin profile update notice:", saveErr);
    }
  }

  return profile;
}

export async function signUpWithEmailSupabase(
  email: string,
  password: string,
  displayName: string,
  level?: SecondaryLevel,
  phone = ""
): Promise<UserProfile> {
  if (!supabase) {
    throw new Error("Supabase non initialisé.");
  }
  const cleanEmail = (email || "").trim().toLowerCase();

  const isSuperAdmin =
    cleanEmail === "massperpendiculaire@gmail.com" ||
    cleanEmail === "massaw.seck@unchk.edu.sn" ||
    cleanEmail === "massaw.savoirplus@gmail.com";

  const userRole = isSuperAdmin ? "admin" : "eleve";

  const { data, error } = await supabase.auth.signUp({
    email: cleanEmail,
    password,
    options: {
      emailRedirectTo: typeof window !== "undefined" ? window.location.origin : undefined,
      data: {
        display_name: displayName.trim(),
        role: userRole,
        level: isSuperAdmin ? null : null,
        classe: isSuperAdmin ? null : null,
        phone: phone.trim(),
      },
    },
  });

  if (error) {
    console.warn("[Supabase Auth] signUp notice:", error.message || error);
    const msg = error.message || "";
    if (msg.includes("already registered") || msg.includes("already exists")) {
      throw new Error("Un compte existe déjà avec cette adresse email.");
    }
    if (msg.includes("Password should be")) {
      throw new Error("Le mot de passe doit comporter au moins 6 caractères.");
    }
    throw new Error(msg || "Erreur lors de la création du compte.");
  }

  if (!data.user) {
    throw new Error("Impossible de créer le compte utilisateur.");
  }

  const authUid = data.user.id;
  // Initialisation du profil avec rôle eleve par défaut pour les apprenants
  const profile: UserProfile = {
    id: authUid,
    uid: authUid,
    email: cleanEmail,
    displayName: displayName.trim() || cleanEmail.split("@")[0],
    role: userRole,
    level: isSuperAdmin ? undefined : undefined,
    classe: isSuperAdmin ? undefined : (null as any),
    phoneNumber: phone.trim(),
    phone: phone.trim(),
    isAdmin: isSuperAdmin,
    isVIP: isSuperAdmin,
    isProfileComplete: isSuperAdmin,
    createdAt: Date.now(),
  };

  // Enregistrement direct et immédiat dans la table profiles avec la clé primaire auth.users.id
  try {
    const { error: insertErr } = await supabase.from("profiles").upsert({
      id: authUid,
      email: cleanEmail,
      display_name: profile.displayName,
      role: userRole,
      level: profile.level || null,
      classe: profile.classe || null,
      phone_number: phone.trim() || null,
      is_admin: isSuperAdmin,
      is_vip: isSuperAdmin,
      is_profile_complete: isSuperAdmin,
      created_at: Date.now(),
      updated_at: Date.now(),
    });
    if (insertErr) {
      console.warn("[Supabase Auth] Direct profile insert notice:", insertErr);
    }
  } catch (insertEx) {
    console.warn("[Supabase Auth] Direct profile insert exception:", insertEx);
  }

  try {
    await saveUserProfileToSupabase(profile);
  } catch (saveErr) {
    console.warn("[Supabase] Initial profile creation notice (non-blocking):", saveErr);
  }

  return profile;
}

export async function signInWithGoogleSupabase(): Promise<{ url?: string; redirected?: boolean }> {
  if (!supabase) throw new Error("Supabase non initialisé.");
  
  // URL officielle de production pour la redirection OAuth (Google Auth)
  const redirectTo = process.env.NEXT_PUBLIC_APP_URL || 'https://savoirplus-edu.vercel.app';
  const isInIframe = typeof window !== "undefined" && window.self !== window.top;

  const { data, error } = await supabase.auth.signInWithOAuth({
    provider: "google",
    options: {
      redirectTo,
      skipBrowserRedirect: isInIframe,
    },
  });

  if (error) {
    const msg = (error.message || "").toLowerCase();
    if (
      msg.includes("provider is not enabled") ||
      msg.includes("unsupported provider") ||
      msg.includes("fournisseur") ||
      msg.includes("not enabled") ||
      msg.includes("disabled")
    ) {
      const customErr = new Error(
        "Le fournisseur de connexion Google n'est pas activé dans votre console Supabase."
      );
      (customErr as any).code = "PROVIDER_NOT_ENABLED";
      (customErr as any).originalMessage = error.message;
      throw customErr;
    }
    throw error;
  }

  if (isInIframe && data?.url) {
    const width = 550;
    const height = 650;
    const left = typeof window !== "undefined" ? window.screenX + (window.outerWidth - width) / 2 : 100;
    const top = typeof window !== "undefined" ? window.screenY + (window.outerHeight - height) / 2 : 100;
    const popup = window.open(
      data.url,
      "google_oauth_popup",
      `width=${width},height=${height},left=${left},top=${top},toolbar=no,menubar=no,scrollbars=yes,status=no`
    );
    if (!popup || popup.closed || typeof popup.closed === "undefined") {
      window.open(data.url, "_blank");
    }
    return { url: data.url, redirected: false };
  }

  return { redirected: true };
}

export async function signOutSupabase(): Promise<void> {
  if (!supabase) return;
  try {
    await supabase.auth.signOut();
  } catch (err) {
    console.warn("[Supabase Auth] Sign out error:", err);
  }
}

export const handleResetPassword = async (email: string) => {
  if (!supabase) {
    alert("Erreur : Supabase non initialisé.");
    return;
  }
  const cleanEmail = (email || "").trim().toLowerCase();
  if (!cleanEmail || !cleanEmail.includes("@")) {
    alert("Veuillez saisir une adresse e-mail valide.");
    return;
  }

  const redirectUrl = typeof window !== "undefined" && window.location?.origin
    ? `${window.location.origin}/reset-password`
    : "https://votre-app.com/reset-password";

  const { error } = await supabase.auth.resetPasswordForEmail(cleanEmail, {
    redirectTo: redirectUrl,
  });

  if (error) {
    alert("Erreur : " + error.message);
  } else {
    alert("Un lien de réinitialisation a été envoyé à votre adresse e-mail.");
  }
};

export async function sendPasswordResetEmailSupabase(email: string): Promise<void> {
  if (!supabase) throw new Error("Supabase non initialisé.");
  const redirectUrl = typeof window !== "undefined" && window.location?.origin
    ? `${window.location.origin}/reset-password`
    : "https://votre-app.com/reset-password";

  const { error } = await supabase.auth.resetPasswordForEmail(email.trim().toLowerCase(), {
    redirectTo: redirectUrl,
  });
  if (error) throw error;
}

export async function updateUserPasswordSupabase(newPassword: string): Promise<void> {
  if (!supabase) throw new Error("Supabase non initialisé.");
  const { error } = await supabase.auth.updateUser({
    password: newPassword,
  });
  if (error) throw error;
}

export function subscribeToAuthChangesSupabase(
  callback: (user: { uid: string; email?: string } | null, event?: string) => void
): () => void {
  if (!supabase) return () => {};

  supabase.auth.getSession().then(({ data: { session } }) => {
    if (session?.user) {
      callback({ uid: session.user.id, email: session.user.email }, "INITIAL_SESSION");
    } else {
      callback(null, "INITIAL_SESSION_NULL");
    }
  }).catch(() => callback(null, "INITIAL_SESSION_ERROR"));

  const { data } = supabase.auth.onAuthStateChange((event, session) => {
    if (session?.user) {
      callback({ uid: session.user.id, email: session.user.email }, event);
    } else {
      callback(null, event);
    }
  });

  return () => {
    data.subscription.unsubscribe();
  };
}

// ============================================================================
// 2. PROFILES & STUDENTS MANAGEMENT (CRUD + Realtime)
// ============================================================================

export async function getUserProfileFromSupabase(uid?: string): Promise<UserProfile | null> {
  if (!supabase) return null;
  try {
    let targetUid = uid;
    let authUser: any = null;
    // Source d'autorité unique : Récupération prioritaire depuis la session authentifiée active
    try {
      const { data: authData } = await supabase.auth.getUser();
      if (authData?.user?.id) {
        authUser = authData.user;
        if (!targetUid || targetUid === "me" || (targetUid.startsWith("auth_") || targetUid.startsWith("user_") && targetUid !== authData.user.id)) {
          targetUid = authData.user.id;
        }
      }
    } catch {}

    if (!targetUid) return null;

    let data: any = null;
    const { data: profileData } = await supabase
      .from("profiles")
      .select("*")
      .eq("id", targetUid)
      .maybeSingle();

    if (profileData) {
      data = profileData;
    } else {
      const { data: userData } = await supabase
        .from("users")
        .select("*")
        .eq("id", targetUid)
        .maybeSingle();
      data = userData;
    }

    if (!data) return null;

    const rawField = data.classe || data.level || data.class_name || data.new_class_name || data.niveau;
    const hasValidClasseField = Boolean(
      rawField &&
      String(rawField).trim() !== "" &&
      rawField !== "null" &&
      rawField !== "undefined"
    );
    const rawClasse = hasValidClasseField ? String(rawField).trim() : null;
    const rawLevel = rawClasse ? (rawClasse as SecondaryLevel) : undefined;
    const isExplicitAdmin = Boolean(data.is_admin || data.role === "admin");
    const role = data.role || (isExplicitAdmin ? "admin" : "eleve");

    // Résolution robuste et hiérarchique du Nom et Prénom complet
    const resolvedDisplayName =
      (data.display_name && data.display_name.trim()) ||
      (data.full_name && data.full_name.trim()) ||
      (authUser?.user_metadata?.display_name && authUser.user_metadata.display_name.trim()) ||
      (authUser?.user_metadata?.full_name && authUser.user_metadata.full_name.trim()) ||
      (authUser?.user_metadata?.name && authUser.user_metadata.name.trim()) ||
      (data.email ? data.email.split("@")[0] : "") ||
      (isExplicitAdmin ? "Administrateur" : "Élève");

    const nameParts = resolvedDisplayName.trim().split(/\s+/);
    const prenom = (data.prenom && String(data.prenom).trim() && data.prenom !== "Élève" ? String(data.prenom).trim() : null) ||
      (nameParts.length > 1 ? nameParts.slice(0, -1).join(" ") : nameParts[0]);
    const nom = (data.nom && String(data.nom).trim() && data.nom !== "Élève" ? String(data.nom).trim() : null) ||
      (nameParts.length > 1 ? nameParts.slice(1).join(" ") : "");

    // Si display_name ou full_name était absent dans la base, on le sauvegarde automatiquement
    if ((!data.display_name || !data.full_name) && resolvedDisplayName) {
      supabase
        .from("profiles")
        .update({
          display_name: resolvedDisplayName,
          full_name: resolvedDisplayName,
          updated_at: Date.now(),
        })
        .eq("id", targetUid)
        .then(() => {}, () => {});
    }

    return {
      id: data.id,
      uid: data.id,
      email: data.email,
      displayName: resolvedDisplayName,
      fullName: resolvedDisplayName,
      prenom,
      nom,
      role,
      studentId: data.student_id,
      matricule: data.matricule || data.student_id,
      level: isExplicitAdmin ? undefined : rawLevel,
      classe: isExplicitAdmin ? undefined : (rawClasse || (null as any)),
      phoneNumber: data.phone_number || "",
      phone: data.phone_number || "",
      photoUrl: data.photo_url || data.avatar_url || "",
      photoURL: data.photo_url || data.avatar_url || "",
      avatarUrl: data.avatar_url || data.photo_url || "",
      avatar_url: data.avatar_url || data.photo_url || "",
      isAdmin: isExplicitAdmin,
      isVIP: Boolean(data.is_vip || isExplicitAdmin),
      vipPlan: isExplicitAdmin ? "admin" : data.vip_plan,
      vipExpiresAt: isExplicitAdmin ? -1 : (data.vip_expires_at ? safeParseTime(data.vip_expires_at) : undefined),
      isProfileComplete: Boolean(isExplicitAdmin || (data.is_profile_complete && rawClasse)),
      lastSeen: safeParseTime(data.last_seen),
      createdAt: safeParseTime(data.created_at),
    };
  } catch (err) {
    console.warn("[Supabase] Error fetching user profile:", err);
    return null;
  }
}

export async function saveUserProfileToSupabase(profile: UserProfile): Promise<void> {
  if (!supabase) return;
  try {
    // 2. IDENTIFIANT UNIQUE STRICT (UUID) ISSU DE L'AUTHENTIFICATION :
    let userUuid = profile.id || profile.uid;
    try {
      const { data: authData } = await supabase.auth.getUser();
      if (authData?.user?.id) {
        // L'UID authentifié est la source d'autorité absolue
        userUuid = authData.user.id;
      }
    } catch {}

    if (!userUuid) return;

    profile.id = userUuid;
    profile.uid = userUuid;

    const avatar = profile.avatarUrl || profile.avatar_url || profile.photoUrl || profile.photoURL || null;
    const hasValidClasse = Boolean(
      profile.classe &&
      String(profile.classe).trim() !== "" &&
      profile.classe !== "null" &&
      profile.classe !== "undefined"
    );
    const resolvedClasse = (!profile.isAdmin && hasValidClasse) ? String(profile.classe).trim() : null;
    const resolvedLevel = profile.isAdmin ? null : (resolvedClasse || null);
    const role = profile.role || (profile.isAdmin ? "admin" : "eleve");

    // 1. Upsert complet avec le rôle 'eleve' ou 'admin' et auth.uid() comme clé primaire 'id'
    const resolvedDisplayName = profile.displayName || profile.fullName || (role === "admin" ? "Administrateur" : "Élève");
    const payload: any = {
      id: userUuid,
      uid: userUuid,
      email: (profile.email || "").toLowerCase().trim(),
      display_name: resolvedDisplayName,
      full_name: resolvedDisplayName,
      prenom: profile.prenom || (resolvedDisplayName !== "Élève" ? resolvedDisplayName.split(" ")[0] : null),
      nom: profile.nom || (resolvedDisplayName !== "Élève" ? resolvedDisplayName.split(" ").slice(1).join(" ") : null),
      role,
      student_id: profile.studentId || profile.matricule || null,
      matricule: profile.matricule || profile.studentId || null,
      level: resolvedLevel,
      classe: resolvedClasse, // STRICTEMENT NULL en base tant qu'aucune classe n'est validée
      phone_number: profile.phoneNumber || profile.phone || null,
      photo_url: avatar,
      avatar_url: avatar,
      is_admin: Boolean(profile.isAdmin),
      is_vip: Boolean(profile.isVIP),
      vip_plan: profile.vipPlan || null,
      vip_expires_at: profile.vipExpiresAt || null,
      is_profile_complete: Boolean((profile.isAdmin || profile.isProfileComplete) && resolvedClasse),
      status: profile.lastSeen && (Date.now() - profile.lastSeen < 5 * 60 * 1000) ? "En ligne" : "Hors-ligne",
      last_seen: Date.now(),
      created_at: profile.createdAt || Date.now(),
      updated_at: Date.now(),
    };

    const { error } = await supabase.from("profiles").upsert(payload);

    // Étape 7 : Synchronisation stricte de l'UID d'authentification comme clé primaire dans la table users
    try {
      await supabase.from("users").upsert({
        id: userUuid,
        uid: userUuid,
        email: (profile.email || "").toLowerCase().trim(),
        display_name: resolvedDisplayName,
        full_name: resolvedDisplayName,
        prenom: profile.prenom || resolvedDisplayName.split(" ")[0],
        nom: profile.nom || resolvedDisplayName.split(" ").slice(1).join(" "),
        role,
        level: resolvedLevel,
        classe: resolvedClasse,
        created_at: profile.createdAt || Date.now(),
        updated_at: Date.now(),
      });
    } catch {}

    // Synchronisation Firestore automatique avec UID comme ID de document
    syncUserToFirestore({
      ...profile,
      uid: userUuid,
      id: userUuid,
      displayName: resolvedDisplayName,
      fullName: resolvedDisplayName,
      role,
      level: resolvedLevel as SecondaryLevel,
      classe: resolvedClasse || undefined,
    }).catch(() => {});

    // Stockage local immédiat garanti
    try {
      localStorage.setItem("savoirplus_user_profile", JSON.stringify({ ...profile, uid: userUuid, id: userUuid, displayName: resolvedDisplayName }));
      localStorage.setItem("savoir_user", JSON.stringify({ ...profile, uid: userUuid, id: userUuid, displayName: resolvedDisplayName }));
      sessionStorage.setItem("savoirplus_user_profile", JSON.stringify({ ...profile, uid: userUuid, id: userUuid, displayName: resolvedDisplayName }));
    } catch {}

    if (error) {
      console.warn("[Supabase] Notice on profile upsert:", error.message);
      // Tentative de secours simplifiée si une colonne n'est pas encore migrée
      try {
        const fallbackPayload: any = {
          id: userUuid,
          email: (profile.email || "").toLowerCase().trim(),
          display_name: profile.displayName || "Élève",
          classe: resolvedClasse,
          level: resolvedLevel,
          is_admin: Boolean(profile.isAdmin),
          is_vip: Boolean(profile.isVIP),
          is_profile_complete: Boolean((profile.isAdmin || profile.isProfileComplete) && resolvedClasse),
          last_seen: Date.now(),
        };
        await supabase.from("profiles").upsert(fallbackPayload);
      } catch (fbErr) {
        // Safe silent fallback
      }
    }
  } catch (err) {
    console.warn("[Supabase] Non-blocking exception during profile save:", err);
  }
}

/**
 * Safe helper to update the profiles table in Supabase.
 * Strips missing columns (like updated_at or class_id) if the database schema cache throws PGRST204.
 */
export async function safeUpdateProfile(userUid: string, updates: Record<string, any>): Promise<void> {
  if (!supabase || !userUid) return;
  const payload = { ...updates };

  let { error } = await supabase.from("profiles").update(payload).eq("id", userUid);

  let attempts = 0;
  while (error && error.code === "PGRST204" && attempts < 6) {
    attempts++;
    const match = error.message?.match(/Could not find the '([^']+)' column/);
    if (match && match[1] && match[1] in payload) {
      delete payload[match[1]];
      const retryResult = await supabase.from("profiles").update(payload).eq("id", userUid);
      error = retryResult.error;
    } else {
      break;
    }
  }

  if (error) {
    console.warn("[Supabase] Profile update notice:", error.message || error);
  }
}

/**
 * Safe helper to update any table in Supabase.
 * Strips missing columns (like rejection_reason, updated_at) if the database schema cache throws PGRST204.
 */
export async function safeUpdateSupabaseTable(
  table: string,
  id: string,
  updates: Record<string, any>,
  idColumn: string = "id"
): Promise<void> {
  if (!supabase || !id) return;
  const payload = { ...updates };

  let { error } = await supabase.from(table).update(payload).eq(idColumn, id);

  let attempts = 0;
  while (error && error.code === "PGRST204" && attempts < 6) {
    attempts++;
    const match = error.message?.match(/Could not find the '([^']+)' column/);
    if (match && match[1] && match[1] in payload) {
      delete payload[match[1]];
      const retryResult = await supabase.from(table).update(payload).eq(idColumn, id);
      error = retryResult.error;
    } else {
      break;
    }
  }

  if (error) {
    console.warn(`[Supabase] Table '${table}' update notice:`, error.message || error);
  }
}

/**
 * Uploads a profile avatar directly to Supabase Storage bucket 'avatars' (public bucket),
 * retrieves the permanent public URL with .getPublicUrl(), and immediately saves it in
 * the 'avatar_url' column of the 'profiles' table for the user.
 */
export async function uploadAvatarToSupabase(file: File, userUid: string): Promise<string | null> {
  if (!supabase || !userUid) return null;

  try {
    const fileExt = file.name.split(".").pop() || "jpg";
    const cleanExt = fileExt.toLowerCase().replace(/[^a-z0-9]/g, "") || "jpg";
    const fileName = `${userUid}_${Date.now()}.${cleanExt}`;
    const filePath = `avatars/${fileName}`;

    // Upload to 'avatars' bucket
    const { error: uploadError } = await supabase.storage
      .from("avatars")
      .upload(filePath, file, {
        cacheControl: "3600",
        upsert: true,
      });

    if (uploadError) {
      console.warn("[Supabase Storage] Upload error to bucket 'avatars':", uploadError);
      return null;
    }

    // Retrieve public URL
    const { data: publicUrlData } = supabase.storage
      .from("avatars")
      .getPublicUrl(filePath);

    const publicUrl = publicUrlData?.publicUrl;
    if (!publicUrl) return null;

    // Immediately persist in 'profiles' table for auth.uid()
    await safeUpdateProfile(userUid, {
      avatar_url: publicUrl,
      photo_url: publicUrl,
    });

    return publicUrl;
  } catch (err) {
    console.warn("[Supabase Storage] Exception during avatar upload:", err);
    return null;
  }
}

/**
 * Upload an official application logo to Supabase Storage (app_assets or avatars)
 * and update the app_config table with real-time broadcasting.
 */
export async function uploadAppLogoToSupabase(file: File | Blob): Promise<string | null> {
  if (!supabase) return null;

  try {
    const rawName = (file as File).name || "logo.png";
    const fileExt = rawName.split(".").pop() || "png";
    const cleanExt = fileExt.toLowerCase().replace(/[^a-z0-9]/g, "") || "png";
    const fileName = `logo_${Date.now()}.${cleanExt}`;

    let publicUrl: string | null = null;

    // 1. Try 'app_assets' bucket first
    const { error: uploadErr1 } = await supabase.storage
      .from("app_assets")
      .upload(`logos/${fileName}`, file, {
        cacheControl: "3600",
        upsert: true,
      });

    if (!uploadErr1) {
      const { data: pData } = supabase.storage.from("app_assets").getPublicUrl(`logos/${fileName}`);
      publicUrl = pData?.publicUrl || null;
    } else {
      // 2. Fallback to 'avatars' bucket
      const { error: uploadErr2 } = await supabase.storage
        .from("avatars")
        .upload(`app_logo_${fileName}`, file, {
          cacheControl: "3600",
          upsert: true,
        });

      if (!uploadErr2) {
        const { data: pData2 } = supabase.storage.from("avatars").getPublicUrl(`app_logo_${fileName}`);
        publicUrl = pData2?.publicUrl || null;
      } else {
        console.warn("[Supabase Storage] Logo upload fallback warning:", uploadErr2);
      }
    }

    if (!publicUrl) return null;

    // 3. Immediately persist in 'app_config'
    await saveAppConfigToSupabase({ logoUrl: publicUrl });

    // 4. Dispatch instant local event for real-time reactivity
    if (typeof window !== "undefined") {
      try {
        localStorage.setItem("savoir_app_logo_data", publicUrl);
        window.dispatchEvent(new CustomEvent("savoir_logo_updated", { detail: publicUrl }));
      } catch (e) {
        // ignore
      }
    }

    return publicUrl;
  } catch (err) {
    console.error("[Supabase Storage] Error uploading app logo:", err);
    return null;
  }
}

/**
 * Direct client-to-storage upload for quiz question figures / illustrations (PNG, JPG, WebP)
 * Uploads raw binary File/Blob to 'app_assets' bucket, avoiding memory crashes.
 */
export async function uploadQuizImageToSupabase(file: File | Blob): Promise<string | null> {
  if (!supabase) return null;
  try {
    const rawName = (file as File).name || "figure.png";
    const fileExt = rawName.split(".").pop() || "png";
    const cleanExt = fileExt.toLowerCase().replace(/[^a-z0-9]/g, "") || "png";
    const cleanBaseName = rawName.replace(/\.[^/.]+$/, "").replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 30);
    const fileName = `quiz_fig_${Date.now()}_${cleanBaseName}.${cleanExt}`;

    // 1. Upload to 'app_assets' under quiz_figures/
    const { error: err1 } = await supabase.storage
      .from("app_assets")
      .upload(`quiz_figures/${fileName}`, file, {
        cacheControl: "3600",
        upsert: true,
      });

    if (!err1) {
      const { data } = supabase.storage.from("app_assets").getPublicUrl(`quiz_figures/${fileName}`);
      return data?.publicUrl || null;
    }

    // Fallback directly to root of 'app_assets'
    const { error: err2 } = await supabase.storage
      .from("app_assets")
      .upload(fileName, file, { cacheControl: "3600", upsert: true });

    if (!err2) {
      const { data } = supabase.storage.from("app_assets").getPublicUrl(fileName);
      return data?.publicUrl || null;
    }

    console.warn("[Supabase Storage] Quiz image upload warning:", err1, err2);
    return null;
  } catch (err) {
    console.error("[Supabase Storage] Error uploading quiz image:", err);
    return null;
  }
}

/**
 * Direct client-to-storage upload for heavy PDF course documents (up to 25-50 MB)
 * Avoids browser memory exhaustion and payload limits associated with FileReader base64.
 */
export async function uploadCoursePdfToSupabase(
  file: File | Blob,
  onProgress?: (percent: number) => void
): Promise<string | null> {
  if (!supabase) return null;
  try {
    const rawName = (file as File).name || "document.pdf";
    const fileExt = rawName.split(".").pop() || "pdf";
    const cleanExt = fileExt.toLowerCase().replace(/[^a-z0-9]/g, "") || "pdf";
    const cleanBaseName = rawName.replace(/\.[^/.]+$/, "").replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 35);
    const fileName = `cours_${Date.now()}_${cleanBaseName}.${cleanExt}`;

    if (onProgress) onProgress(25);

    // 1. Try 'course_documents' bucket
    const { error: err1 } = await supabase.storage
      .from("course_documents")
      .upload(`documents/${fileName}`, file, {
        cacheControl: "3600",
        upsert: true,
      });

    if (!err1) {
      if (onProgress) onProgress(100);
      const { data } = supabase.storage.from("course_documents").getPublicUrl(`documents/${fileName}`);
      return data?.publicUrl || null;
    }

    // 2. Fallback to 'app_assets' bucket (which is configured up to 50MB)
    if (onProgress) onProgress(60);
    const { error: err2 } = await supabase.storage
      .from("app_assets")
      .upload(`course_pdfs/${fileName}`, file, {
        cacheControl: "3600",
        upsert: true,
      });

    if (!err2) {
      if (onProgress) onProgress(100);
      const { data } = supabase.storage.from("app_assets").getPublicUrl(`course_pdfs/${fileName}`);
      return data?.publicUrl || null;
    }

    console.warn("[Supabase Storage] PDF upload fallback error:", err1, err2);
    return null;
  } catch (err) {
    console.error("[Supabase Storage] Error uploading course PDF:", err);
    return null;
  }
}

/**
 * Direct client-to-storage upload for video files (up to 2 GB)
 * Uses the 'videos' bucket with cacheControl: '3600' and upsert: true
 */
export async function uploadCourseVideoToSupabase(
  file: File | Blob,
  onProgress?: (percent: number) => void
): Promise<string | null> {
  if (!supabase) return null;
  try {
    const rawName = (file as File).name || "video.mp4";
    const fileExt = rawName.split(".").pop() || "mp4";
    const cleanExt = fileExt.toLowerCase().replace(/[^a-z0-9]/g, "") || "mp4";
    const cleanBaseName = rawName.replace(/\.[^/.]+$/, "").replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 35);
    const fileName = `video_${Date.now()}_${cleanBaseName}.${cleanExt}`;
    const filePath = `videos/${fileName}`;

    if (onProgress) onProgress(20);

    // 1. Direct upload to primary 'videos' bucket
    const { error: errVideos } = await supabase.storage
      .from("videos")
      .upload(filePath, file, {
        cacheControl: "3600",
        upsert: true,
      });

    if (!errVideos) {
      if (onProgress) onProgress(100);
      const { data } = supabase.storage.from("videos").getPublicUrl(filePath);
      return data?.publicUrl || null;
    }

    console.warn("[Supabase Storage] Notice on 'videos' bucket:", errVideos.message);

    // 2. Fallback to 'course_videos' bucket
    if (onProgress) onProgress(45);
    const { error: err1 } = await supabase.storage
      .from("course_videos")
      .upload(filePath, file, {
        cacheControl: "3600",
        upsert: true,
      });

    if (!err1) {
      if (onProgress) onProgress(100);
      const { data } = supabase.storage.from("course_videos").getPublicUrl(filePath);
      return data?.publicUrl || null;
    }

    // 3. Fallback to 'app_assets' bucket
    if (onProgress) onProgress(65);
    const { error: err2 } = await supabase.storage
      .from("app_assets")
      .upload(filePath, file, {
        cacheControl: "3600",
        upsert: true,
      });

    if (!err2) {
      if (onProgress) onProgress(100);
      const { data } = supabase.storage.from("app_assets").getPublicUrl(filePath);
      return data?.publicUrl || null;
    }

    // 4. Fallback to 'course_documents'
    if (onProgress) onProgress(80);
    const { error: err3 } = await supabase.storage
      .from("course_documents")
      .upload(filePath, file, {
        cacheControl: "3600",
        upsert: true,
      });

    if (!err3) {
      if (onProgress) onProgress(100);
      const { data } = supabase.storage.from("course_documents").getPublicUrl(filePath);
      return data?.publicUrl || null;
    }

    console.warn("[Supabase Storage] Video upload fallback error:", errVideos, err1, err2, err3);
    throw new Error(errVideos?.message || err1?.message || "Erreur lors du téléversement vers Supabase Storage.");
  } catch (err: any) {
    console.error("[Supabase Storage] Error uploading course video:", err);
    throw err;
  }
}

export async function fetchAllStudentsFromSupabase(): Promise<StudentRecord[]> {
  if (!supabase) return [];
  try {
    const { data, error } = await supabase
      .from("profiles")
      .select("*")
      .order("created_at", { ascending: false });

    if (error || !data) return [];

    return data.map((d: any) => {
      const lastSeenTimestamp = d.last_seen ? safeParseTime(d.last_seen) : (d.created_at ? safeParseTime(d.created_at) : 0);
      const isOnlineNow = d.last_seen ? (Date.now() - safeParseTime(d.last_seen) < 5 * 60 * 1000) : false;
      const detectedProvider = d.auth_provider || (d.email && (d.email.toLowerCase().includes("@gmail.com") || d.email.toLowerCase().includes("google")) ? "google" : "email");
      const studentClass = (d.classe || d.level || d.class_name || d.new_class_name || d.niveau || "3ème") as SecondaryLevel;
      return {
        id: d.id,
        uid: d.id,
        displayName: d.display_name || "Élève",
        email: d.email || "",
        level: studentClass,
        classe: d.classe || studentClass,
        studentId: d.student_id,
        matricule: d.matricule || d.student_id,
        phoneNumber: d.phone_number || "",
        phone: d.phone_number || "",
        photoUrl: d.avatar_url || d.photo_url || "",
        photoURL: d.avatar_url || d.photo_url || "",
        avatarUrl: d.avatar_url || d.photo_url || "",
        avatar_url: d.avatar_url || d.photo_url || "",
        isAdmin: Boolean(d.is_admin),
        isVIP: Boolean(d.is_vip),
        vipPlan: d.vip_plan,
        vipExpiresAt: d.vip_expires_at ? safeParseTime(d.vip_expires_at) : undefined,
        isProfileComplete: Boolean(d.is_profile_complete),
        status: (isOnlineNow ? "En ligne" : "Hors-ligne") as "En ligne" | "Hors-ligne",
        lastLogin: d.last_seen ? new Date(safeParseTime(d.last_seen)).toLocaleDateString("fr-FR") : "Jamais",
        lastSeen: lastSeenTimestamp,
        createdAt: d.created_at ? safeParseTime(d.created_at) : Date.now(),
        authProvider: detectedProvider,
        quizResults: [],
        homeworkGrades: [],
      };
    });
  } catch (err) {
    console.warn("[Supabase] Error fetching all students:", err);
    return [];
  }
}

export function subscribeToAllStudentsSupabase(
  onUpdate: (students: StudentRecord[]) => void
): () => void {
  if (!supabase) return () => {};

  const fetchAndNotify = () => {
    fetchAllStudentsFromSupabase().then((list) => {
      if (list && list.length > 0) onUpdate(list);
    });
  };

  fetchAndNotify();

  // Polling fallback to guarantee real-time updates even if Supabase replication is not enabled
  const intervalId = setInterval(fetchAndNotify, 15000);

  const channelName = `profiles_all_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const channel = supabase
    .channel(channelName)
    .on(
      "postgres_changes",
      { event: "*", schema: "public", table: "profiles" },
      () => {
        fetchAndNotify();
      }
    )
    .subscribe();

  return () => {
    clearInterval(intervalId);
    supabase?.removeChannel(channel);
  };
}

export function subscribeToUserProfileSupabase(
  uid: string,
  onUpdate: (profile: UserProfile | null) => void
): () => void {
  if (!supabase || !uid) return () => {};

  getUserProfileFromSupabase(uid).then((p) => {
    if (p) onUpdate(p);
  });

  const channelName = `profile_user_${uid}_${Date.now()}`;
  const channel = supabase
    .channel(channelName)
    .on(
      "postgres_changes",
      { event: "*", schema: "public", table: "profiles", filter: `id=eq.${uid}` },
      (payload: any) => {
        if (payload?.new && payload.new.id === uid) {
          const d = payload.new;
          const rawField = d.classe || d.level || d.class_name || d.new_class_name || d.niveau;
          const rawClasse = rawField ? String(rawField).trim() : null;
          const rawLevel = rawClasse ? (rawClasse as SecondaryLevel) : undefined;
          const isExplicitAdmin = Boolean(d.is_admin || d.role === "admin");
          const role = d.role || (isExplicitAdmin ? "admin" : "eleve");

          const resolvedName =
            (d.display_name && d.display_name.trim()) ||
            (d.full_name && d.full_name.trim()) ||
            (d.email ? d.email.split("@")[0] : "") ||
            (isExplicitAdmin ? "Administrateur" : "Élève");
          const nameParts = resolvedName.trim().split(/\s+/);
          const prenom = nameParts.length > 1 ? nameParts.slice(0, -1).join(" ") : nameParts[0];
          const nom = nameParts.length > 1 ? nameParts[nameParts.length - 1] : "";

          const fastProfile: UserProfile = {
            id: d.id,
            uid: d.id,
            email: d.email,
            displayName: resolvedName,
            fullName: resolvedName,
            prenom,
            nom,
            role,
            studentId: d.student_id,
            matricule: d.matricule || d.student_id,
            level: isExplicitAdmin ? undefined : rawLevel,
            classe: isExplicitAdmin ? undefined : (rawClasse || (null as any)),
            phoneNumber: d.phone_number || "",
            phone: d.phone_number || "",
            photoUrl: d.avatar_url || d.photo_url || "",
            photoURL: d.avatar_url || d.photo_url || "",
            avatarUrl: d.avatar_url || d.photo_url || "",
            avatar_url: d.avatar_url || d.photo_url || "",
            isAdmin: isExplicitAdmin,
            isVIP: Boolean(d.is_vip),
            vipPlan: d.vip_plan,
            vipExpiresAt: d.vip_expires_at ? safeParseTime(d.vip_expires_at) : undefined,
            isProfileComplete: Boolean(isExplicitAdmin || (d.is_profile_complete && rawClasse)),
            lastSeen: safeParseTime(d.last_seen),
            createdAt: safeParseTime(d.created_at),
          };
          onUpdate(fastProfile);
        }
        getUserProfileFromSupabase(uid).then((p) => {
          if (p) onUpdate(p);
        });
      }
    )
    .subscribe();

  return () => {
    supabase?.removeChannel(channel);
  };
}

export async function deleteStudentFromSupabaseCascade(studentUid: string): Promise<void> {
  if (!supabase || !studentUid) return;
  try {
    await supabase.from("profiles").delete().eq("id", studentUid);
    await supabase.from("quiz_results").delete().eq("student_uid", studentUid);
    await supabase.from("homework_submissions").delete().eq("student_uid", studentUid);
    await supabase.from("transactions").delete().eq("user_uid", studentUid);
    await supabase.from("vip_payment_requests").delete().eq("student_uid", studentUid);
    await supabase.from("class_change_requests").delete().eq("student_uid", studentUid);
    await supabase.from("notifications").delete().eq("target_uid", studentUid);
  } catch (err) {
    console.warn("[Supabase] Cascade delete error:", err);
  }
}

export async function purgeNonAdminUsersFromSupabase(): Promise<number> {
  if (!supabase) return 0;
  try {
    const { data: nonAdmins } = await supabase
      .from("profiles")
      .select("id, email")
      .eq("is_admin", false);

    if (!nonAdmins || nonAdmins.length === 0) return 0;

    const idsToPurge = nonAdmins
      .filter((u: any) => {
        const em = (u.email || "").toLowerCase().trim();
        return (
          em !== "massperpendiculaire@gmail.com" &&
          em !== "massaw.seck@unchk.edu.sn" &&
          em !== "massaw.savoirplus@gmail.com"
        );
      })
      .map((u: any) => u.id);

    if (idsToPurge.length > 0) {
      await supabase.from("profiles").delete().in("id", idsToPurge);
    }
    return idsToPurge.length;
  } catch (err) {
    console.warn("[Supabase] Purge non admin error:", err);
    return 0;
  }
}

export async function setUserVIPStatusSupabase(
  userUid: string,
  isVIP: boolean,
  vipPlan?: string,
  vipExpiresAt?: number
): Promise<void> {
  if (!supabase || !userUid) return;
  try {
    await supabase
      .from("profiles")
      .update({
        is_vip: isVIP,
        vip_plan: vipPlan || null,
        vip_expires_at: vipExpiresAt || null,
      })
      .eq("id", userUid);
  } catch (err) {
    console.warn("[Supabase] Set VIP status error:", err);
  }
}

export const setUserVIPStatusFirebase = setUserVIPStatusSupabase;

// ============================================================================
// 3. COURSES (CRUD + Realtime)
// ============================================================================

function parseTimestamp(val: any): number {
  if (!val) return Date.now();
  if (typeof val === "number") return val;
  const num = Number(val);
  if (!isNaN(num) && num > 100000000) return num;
  const parsed = new Date(val).getTime();
  return isNaN(parsed) ? Date.now() : parsed;
}

function mapCourseRow(c: any): Course {
  return {
    id: String(c.id || c.course_id || c.courseId || `course_${Date.now()}`),
    title: String(c.title || c.titre || c.name || "Cours sans titre"),
    level: (c.level || c.niveau || c.classe || "3ème") as SecondaryLevel,
    subject: (c.subject || c.matiere || "Maths") as Subject,
    chapter: String(c.chapter || c.chapitre || ""),
    summary: String(c.summary || c.resume || c.description || ""),
    content: String(c.content || c.contenu || c.body || ""),
    pdfUrl: c.pdf_url || c.pdfUrl || c.file_url || c.url || undefined,
    pdfFileName: c.pdf_file_name || c.pdfFileName || c.file_name || undefined,
    createdAt: parseTimestamp(c.created_at || c.createdAt),
  };
}

export async function getCoursesByLevelSupabase(level?: SecondaryLevel): Promise<Course[]> {
  if (!supabase) return [];
  try {
    let query = supabase.from("courses").select("*");
    if (level && level !== "Savoir+" && level !== "GMA" && level !== "Génie Mentor Académie" && (level as string) !== "ALL") {
      query = query.eq("level", level);
    }
    
    // Try ordering by created_at
    let res = await query.order("created_at", { ascending: false });
    
    // If order fails (e.g., column type or index issue), retry without order
    if (res.error) {
      logSupabaseError("cours (table 'courses')", res.error);
      const fallbackQuery = supabase.from("courses").select("*");
      const fallbackRes = level && level !== "Savoir+" && level !== "GMA" && level !== "Génie Mentor Académie" && (level as string) !== "ALL"
        ? await fallbackQuery.eq("level", level)
        : await fallbackQuery;
      if (fallbackRes.data && !fallbackRes.error) {
        res = fallbackRes;
      }
    }

    if (!res.data || res.data.length === 0) {
      return [];
    }

    const courses = res.data.map(mapCourseRow).sort((a, b) => b.createdAt - a.createdAt);
    return courses;
  } catch (err) {
    console.warn("[Supabase] Unexpected error fetching courses directly:", err);
    return [];
  }
}

export async function saveCourseToSupabase(course: Course): Promise<boolean> {
  if (!supabase) return true;
  try {
    const { error } = await supabase.from("courses").upsert({
      id: course.id,
      title: course.title,
      level: course.level,
      subject: course.subject,
      chapter: course.chapter,
      summary: course.summary,
      content: course.content,
      pdf_url: course.pdfUrl || null,
      pdf_file_name: course.pdfFileName || null,
      created_at: course.createdAt || Date.now(),
    });
    if (error) {
      console.warn("[Supabase] Notice saving course to 'courses' table:", error.message || error);
      return false;
    }
    return true;
  } catch (err) {
    console.warn("[Supabase] Unexpected exception saving course:", err);
    return false;
  }
}

export async function deleteCourseFromSupabase(courseId: string): Promise<void> {
  if (!supabase) return;
  const { error } = await supabase.from("courses").delete().eq("id", courseId);
  if (error) {
    console.error("[Supabase] Error deleting course from 'courses' table:", error);
    throw error;
  }
}

export function subscribeToAllCoursesSupabase(
  onUpdate: (courses: Course[]) => void
): () => void {
  if (!supabase) return () => {};

  getCoursesByLevelSupabase().then((list) => {
    onUpdate(list);
  });

  const channelName = `courses_all_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
  const channel = supabase
    .channel(channelName)
    .on(
      "postgres_changes",
      { event: "*", schema: "public", table: "courses" },
      () => {
        getCoursesByLevelSupabase().then((list) => onUpdate(list));
      }
    )
    .subscribe();

  return () => {
    if (supabase && channel) {
      try {
        supabase.removeChannel(channel);
      } catch (err) {
        console.warn("[Supabase] Remove channel error:", err);
      }
    }
  };
}

export function subscribeToCoursesSupabase(
  level: SecondaryLevel,
  onUpdate: (courses: Course[]) => void
): () => void {
  if (!supabase) return () => {};

  getCoursesByLevelSupabase(level).then((list) => {
    onUpdate(list);
  });

  const channelName = `courses_${level}_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
  const channel = supabase
    .channel(channelName)
    .on(
      "postgres_changes",
      { event: "*", schema: "public", table: "courses" },
      () => {
        getCoursesByLevelSupabase(level).then((list) => onUpdate(list));
      }
    )
    .subscribe();

  return () => {
    if (supabase && channel) {
      try {
        supabase.removeChannel(channel);
      } catch (err) {
        console.warn("[Supabase] Remove channel error:", err);
      }
    }
  };
}

// ============================================================================
// 3.5 TUTORIALS / VIDÉOS (CRUD + Realtime, up to 2 GB)
// ============================================================================

export async function getAllTutorialsSupabase(): Promise<TutorialVideo[]> {
  if (!supabase) return [];
  try {
    const { data, error } = await supabase
      .from("tutorials")
      .select("*")
      .order("created_at", { ascending: false });

    if (error) {
      logSupabaseError("tutoriels (table 'tutorials')", error);
      return [];
    }

    if (!data) return [];

    return data.map((row: any) => ({
      id: row.id,
      title: row.title,
      level: row.level,
      subject: row.subject,
      category: row.category,
      description: row.description || "",
      videoUrl: row.video_url || row.videoUrl || "",
      videoFileName: row.video_file_name || row.videoFileName || undefined,
      videoSize: row.video_size || row.videoSize || undefined,
      duration: row.duration || undefined,
      thumbnailUrl: row.thumbnail_url || row.thumbnailUrl || undefined,
      viewsCount: row.views_count || row.viewsCount || 0,
      createdAt: row.created_at ? (typeof row.created_at === "number" ? row.created_at : new Date(row.created_at).getTime()) : Date.now(),
      dateFormatted: row.date_formatted || undefined,
    }));
  } catch (err) {
    console.error("[Supabase] Unexpected error fetching tutorials:", err);
    return [];
  }
}

export async function saveTutorialToSupabase(tutorial: TutorialVideo): Promise<void> {
  if (!supabase) return;
  try {
    const { error } = await supabase.from("tutorials").upsert({
      id: tutorial.id,
      title: tutorial.title,
      level: tutorial.level,
      subject: tutorial.subject,
      category: tutorial.category,
      description: tutorial.description,
      video_url: tutorial.videoUrl,
      video_file_name: tutorial.videoFileName || null,
      video_size: tutorial.videoSize || null,
      duration: tutorial.duration || null,
      thumbnail_url: tutorial.thumbnailUrl || null,
      views_count: tutorial.viewsCount || 0,
      created_at: tutorial.createdAt || Date.now(),
      date_formatted: tutorial.dateFormatted || null,
    });

    if (error) {
      logSupabaseError("sauvegarde tutoriel (table 'tutorials')", error);
    }
  } catch (err) {
    console.warn("[Supabase] Error saving tutorial:", err);
  }
}

export async function deleteTutorialFromSupabase(tutorialId: string): Promise<void> {
  if (!supabase) return;
  try {
    const { error } = await supabase.from("tutorials").delete().eq("id", tutorialId);
    if (error) {
      logSupabaseError("suppression tutoriel (table 'tutorials')", error);
    }
  } catch (err) {
    console.warn("[Supabase] Error deleting tutorial:", err);
  }
}

export function subscribeToAllTutorialsSupabase(
  onUpdate: (tutorials: TutorialVideo[]) => void
): () => void {
  if (!supabase) return () => {};

  getAllTutorialsSupabase().then((list) => {
    onUpdate(list);
  });

  const channelName = `tutorials_all_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
  const channel = supabase
    .channel(channelName)
    .on(
      "postgres_changes",
      { event: "*", schema: "public", table: "tutorials" },
      () => {
        getAllTutorialsSupabase().then((list) => onUpdate(list));
      }
    )
    .subscribe();

  return () => {
    if (supabase && channel) {
      try {
        supabase.removeChannel(channel);
      } catch (err) {
        console.warn("[Supabase] Remove channel error:", err);
      }
    }
  };
}

// ============================================================================
// 4. ASSETS / EXERCISES (CRUD + Realtime)
// ============================================================================

export async function getAssetsSupabase(level?: SecondaryLevel): Promise<Asset[]> {
  if (!supabase) return [];
  try {
    let query = supabase.from("assets").select("*");
    if (level && level !== "Savoir+" && level !== "GMA" && level !== "Génie Mentor Académie" && (level as string) !== "ALL") {
      query = query.eq("level", level);
    }
    let res = await query.order("created_at", { ascending: false });
    if (res.error) {
      logSupabaseError("exercices/assets (table 'assets')", res.error);
      const fallback = await supabase.from("assets").select("*");
      if (fallback.data && !fallback.error) {
        res = fallback;
      }
    }
    if (!res.data || res.data.length === 0) return [];

    return res.data.map((a: any) => ({
      assetId: String(a.asset_id || a.id || `asset_${Date.now()}`),
      title: String(a.title || a.titre || a.name || "Document"),
      type: a.type || "exercice",
      level: (a.level || a.niveau || a.classe || "3ème") as SecondaryLevel,
      subject: (a.subject || a.matiere || "Maths") as Subject,
      chapter: String(a.chapter || a.chapitre || ""),
      downloadUrl: a.download_url || a.pdfUrl || a.url,
      pdfUrl: a.download_url || a.pdfUrl || a.url,
      pdfFileName: a.pdf_file_name || a.pdfFileName,
      fileSize: a.file_size || "1.2 MB",
      contentPreview: a.content_preview,
      isCachedOffline: Boolean(a.is_cached_offline),
      createdAt: parseTimestamp(a.created_at || a.createdAt),
    })).sort((a, b) => b.createdAt - a.createdAt);
  } catch (err) {
    console.warn("[Supabase] Unexpected error fetching assets:", err);
    return [];
  }
}

export async function saveAssetToSupabase(asset: Asset): Promise<void> {
  if (!supabase) return;
  const assetId = asset.assetId || (asset as any).id;
  const { error } = await supabase.from("assets").upsert({
    id: assetId,
    asset_id: assetId,
    title: asset.title,
    type: asset.type,
    level: asset.level,
    subject: asset.subject,
    chapter: asset.chapter,
    download_url: asset.downloadUrl || asset.pdfUrl || null,
    pdf_file_name: asset.pdfFileName || null,
    file_size: asset.fileSize || "1.2 MB",
    content_preview: asset.contentPreview || null,
    is_cached_offline: Boolean(asset.isCachedOffline),
    created_at: asset.createdAt || Date.now(),
  });
  if (error) {
    console.error("[Supabase] Error saving asset to 'assets' table:", error);
    throw error;
  }
}

export async function deleteAssetFromSupabase(assetId: string): Promise<void> {
  if (!supabase) return;
  const { error } = await supabase
    .from("assets")
    .delete()
    .or(`id.eq.${assetId},asset_id.eq.${assetId}`);
  if (error) {
    console.error("[Supabase] Error deleting asset from 'assets' table:", error);
    throw error;
  }
}

export function subscribeToAllAssetsSupabase(
  onUpdate: (assets: Asset[]) => void
): () => void {
  if (!supabase) return () => {};

  getAssetsSupabase().then((list) => {
    onUpdate(list);
  });

  const channelName = `assets_all_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
  const channel = supabase
    .channel(channelName)
    .on(
      "postgres_changes",
      { event: "*", schema: "public", table: "assets" },
      () => {
        getAssetsSupabase().then((list) => onUpdate(list));
      }
    )
    .subscribe();

  return () => {
    if (supabase && channel) {
      try {
        supabase.removeChannel(channel);
      } catch (err) {
        console.warn("[Supabase] Remove channel error:", err);
      }
    }
  };
}

// ============================================================================
// 5. QUIZZES (CRUD + Results + Realtime)
// ============================================================================

export async function getQuizzesByLevelSupabase(level?: SecondaryLevel): Promise<Quiz[]> {
  if (!supabase) return [];
  try {
    let query = supabase.from("quizzes").select("*");
    if (level && level !== "Savoir+" && level !== "GMA" && level !== "Génie Mentor Académie" && (level as string) !== "ALL") {
      query = query.eq("level", level);
    }
    let res = await query.order("created_at", { ascending: false });
    if (res.error) {
      logSupabaseError("quiz (table 'quizzes')", res.error);
      const fallback = await supabase.from("quizzes").select("*");
      if (fallback.data && !fallback.error) {
        res = fallback;
      }
    }
    if (!res.data || res.data.length === 0) return [];

    return res.data.map((q: any) => {
      const durMins = Math.max(1, Number(q.duration_minutes) || 15);
      return {
        id: String(q.id || `quiz_${Date.now()}`),
        title: String(q.title || q.titre || "Quiz d'évaluation"),
        subject: (q.subject || q.matiere || "Maths") as Subject,
        level: (q.level || q.niveau || q.classe || "3ème") as SecondaryLevel,
        durationMinutes: durMins,
        duration: String(durMins),
        durationSeconds: durMins * 60,
        durationFormatted: `${String(Math.floor(durMins / 60)).padStart(2, "0")} : ${String(durMins % 60).padStart(2, "0")} : 00`,
        questions: Array.isArray(q.questions) ? q.questions : [],
        createdAt: parseTimestamp(q.created_at || q.createdAt),
      };
    }).sort((a, b) => b.createdAt - a.createdAt);
  } catch (err) {
    console.warn("[Supabase] Unexpected error fetching quizzes:", err);
    return [];
  }
}

export async function saveQuizToSupabase(quiz: Quiz): Promise<void> {
  if (!supabase) return;
  const durationMins = Math.max(
    1,
    quiz.duration_minutes ||
      quiz.durationMinutes ||
      (quiz.durationSeconds ? Math.ceil(quiz.durationSeconds / 60) : 0) ||
      (quiz.duration ? parseInt(quiz.duration, 10) : 0) ||
      15
  );

  // 1. Upsert main quiz record
  const quizRecord: any = {
    id: quiz.id,
    title: quiz.title,
    subject: quiz.subject,
    level: quiz.level,
    chapter: quiz.chapter || null,
    duration_minutes: durationMins,
    questions: quiz.questions || [],
    status: quiz.status || "published",
    created_at: quiz.createdAt || Date.now(),
  };

  const { error } = await supabase.from("quizzes").upsert(quizRecord);
  if (error) {
    console.error("[Supabase] Error saving quiz to 'quizzes' table:", error);
    // Fallback if chapter or status column is not present
    try {
      await supabase.from("quizzes").upsert({
        id: quiz.id,
        title: quiz.title,
        subject: quiz.subject,
        level: quiz.level,
        duration_minutes: durationMins,
        questions: quiz.questions || [],
        created_at: quiz.createdAt || Date.now(),
      });
    } catch (fbErr) {
      console.warn("[Supabase] Fallback save quiz failed:", fbErr);
    }
  }

  // 2. Upsert questions into 'quiz_questions' table if available
  if (Array.isArray(quiz.questions) && quiz.questions.length > 0) {
    try {
      const questionRows = quiz.questions.map((q, idx) => ({
        id: q.id || `q_${quiz.id}_${idx + 1}`,
        quiz_id: quiz.id,
        question_text: q.question || q.question_text || "",
        image_url: q.image_url || q.imageUrl || null,
        media_type: q.media_type || q.mediaType || (q.image_url || q.imageUrl ? "image" : null),
        type: q.type || "single",
        options: q.options || [],
        correct_answers: q.correct_answers || (q.correctIndices && q.correctIndices.length > 0 ? q.correctIndices : [q.correctIndex ?? 0]),
        explanation: q.explanation || "",
        order_index: idx,
        created_at: quiz.createdAt || Date.now(),
      }));

      await supabase.from("quiz_questions").upsert(questionRows);
    } catch (qErr) {
      // Non-blocking schema tolerance if quiz_questions table doesn't exist
      console.info("[Supabase] Notice on quiz_questions table upsert:", qErr);
    }
  }
}

export async function deleteQuizFromSupabase(quizId: string): Promise<void> {
  if (!supabase) return;
  const { error } = await supabase.from("quizzes").delete().eq("id", quizId);
  if (error) {
    console.error("[Supabase] Error deleting quiz from 'quizzes' table:", error);
    throw error;
  }
}

export function subscribeToAllQuizzesSupabase(
  onUpdate: (quizzes: Quiz[]) => void
): () => void {
  if (!supabase) return () => {};

  getQuizzesByLevelSupabase().then((list) => {
    onUpdate(list);
  });

  const channelName = `quizzes_all_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
  const channel = supabase
    .channel(channelName)
    .on(
      "postgres_changes",
      { event: "*", schema: "public", table: "quizzes" },
      () => {
        getQuizzesByLevelSupabase().then((list) => onUpdate(list));
      }
    )
    .subscribe();

  return () => {
    if (supabase && channel) {
      try {
        supabase.removeChannel(channel);
      } catch (err) {
        console.warn("[Supabase] Remove channel error:", err);
      }
    }
  };
}

export function subscribeToQuizzesSupabase(
  level: SecondaryLevel,
  onUpdate: (quizzes: Quiz[]) => void
): () => void {
  if (!supabase) return () => {};

  getQuizzesByLevelSupabase(level).then((list) => {
    onUpdate(list);
  });

  const channelName = `quizzes_${level}_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
  const channel = supabase
    .channel(channelName)
    .on(
      "postgres_changes",
      { event: "*", schema: "public", table: "quizzes" },
      () => {
        getQuizzesByLevelSupabase(level).then((list) => onUpdate(list));
      }
    )
    .subscribe();

  return () => {
    if (supabase && channel) {
      try {
        supabase.removeChannel(channel);
      } catch (err) {
        console.warn("[Supabase] Remove channel error:", err);
      }
    }
  };
}

export async function saveQuizResultToSupabase(result: QuizResultRecord): Promise<void> {
  if (!supabase) return;
  try {
    let userId = result.studentId;
    // Source d'autorité : extraction de l'UID depuis le jeton d'authentification
    try {
      const { data: authData } = await supabase.auth.getUser();
      if (authData?.user?.id) {
        userId = authData.user.id;
      }
    } catch {}
    const quizId = result.quizId || "quiz_default";
    const payload = {
      id: result.id || `res_${userId}_${quizId}`,
      user_id: userId,
      student_uid: userId,
      quiz_id: quizId,
      quiz_title: result.quizTitle,
      student_name: result.studentName || "Élève",
      level: result.level,
      subject: result.subject,
      score: result.correctAnswers,
      score20: result.score20 ?? (result.scorePercentage ? Math.round((result.scorePercentage / 5) * 10) / 10 : 0),
      total_questions: result.totalQuestions,
      percentage: result.scorePercentage,
      answers: result.questionReviews || [],
      completed_at: result.timestamp || Date.now(),
      date_formatted: result.date || new Date().toLocaleDateString("fr-FR"),
      timestamp: result.timestamp || Date.now(),
    };

    // 1. Primary upsert with user_id, quiz_id conflict resolution
    const { error } = await supabase
      .from("quiz_results")
      .upsert(payload, { onConflict: "user_id, quiz_id" });

    if (error) {
      // 2. Fallback upsert using primary key 'id' if the unique constraint is not yet migrated
      const { error: fallbackErr } = await supabase
        .from("quiz_results")
        .upsert(payload, { onConflict: "id" });
      if (fallbackErr) {
        logSupabaseError("évaluation de quiz (table 'quiz_results')", fallbackErr);
      }
    }

    // 3. Mirroring to quiz_attempts table for comprehensive backward compatibility
    try {
      await supabase
        .from("quiz_attempts")
        .upsert({
          id: payload.id,
          user_id: userId,
          quiz_id: quizId,
          student_name: payload.student_name,
          score: payload.score,
          total_questions: payload.total_questions,
          percentage: payload.percentage,
          date_formatted: payload.date_formatted,
          timestamp: payload.timestamp,
        }, { onConflict: "user_id, quiz_id" });
    } catch {
      // Non-blocking mirror fallback
    }
  } catch (err) {
    console.warn("[Supabase] Error saving quiz result:", err);
  }
}

export async function deleteQuizResultFromSupabase(studentUid: string, quizId: string): Promise<void> {
  if (!supabase || !studentUid || !quizId) return;
  try {
    await supabase
      .from("quiz_results")
      .delete()
      .or(`student_uid.eq.${studentUid},user_id.eq.${studentUid}`)
      .eq("quiz_id", quizId);

    try {
      await supabase
        .from("quiz_attempts")
        .delete()
        .eq("user_id", studentUid)
        .eq("quiz_id", quizId);
    } catch {}
  } catch (err) {
    console.warn("[Supabase] Error deleting quiz result:", err);
  }
}

export function subscribeToUserQuizResultsSupabase(
  studentId: string,
  onUpdate: (results: QuizResultRecord[]) => void
): () => void {
  if (!supabase || !studentId) return () => {};

  const fetchResults = async () => {
    try {
      const { data, error } = await supabase
        .from("quiz_results")
        .select("*")
        .or(`student_uid.eq.${studentId},user_id.eq.${studentId}`)
        .order("completed_at", { ascending: false });

      if (error || !data) return;
      onUpdate(
        data.map((d: any) => ({
          id: d.id,
          studentId: d.student_uid || d.user_id || "",
          studentName: d.student_name || "Élève",
          quizId: d.quiz_id,
          quizTitle: d.quiz_title,
          level: d.level,
          subject: d.subject,
          correctAnswers: d.score,
          totalQuestions: d.total_questions,
          scorePercentage: d.percentage,
          score20: d.total_questions ? Math.round(((d.score || 0) / d.total_questions) * 20 * 10) / 10 : 0,
          date: new Date(Number(d.completed_at) || Date.now()).toLocaleDateString("fr-FR"),
          questionReviews: Array.isArray(d.answers) ? d.answers : [],
          timestamp: Number(d.completed_at || Date.now()),
          dateFormatted: new Date(Number(d.completed_at) || Date.now()).toLocaleDateString("fr-FR"),
        }))
      );
    } catch (err) {
      console.warn("[Supabase] Error fetching user quiz results:", err);
    }
  };

  fetchResults();

  const channelName = `quiz_results_${studentId}_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const channel = supabase
    .channel(channelName)
    .on(
      "postgres_changes",
      { event: "*", schema: "public", table: "quiz_results" },
      () => {
        fetchResults();
      }
    )
    .subscribe();

  return () => {
    supabase?.removeChannel(channel);
  };
}

// ============================================================================
// 6. HOMEWORK SUBMISSIONS (CRUD + Grading + Realtime)
// ============================================================================

export async function fetchHomeworkSubmissionsSupabase(): Promise<HomeworkSubmission[]> {
  if (!supabase) return [];
  try {
    const { data, error } = await supabase
      .from("homework_submissions")
      .select("*")
      .order("submitted_at", { ascending: false });

    if (error || !data) return [];

    return data.map((d: any) => ({
      id: d.id,
      userUid: d.student_uid || "",
      studentMatricule: d.matricule || "",
      matricule: d.matricule || "",
      studentName: d.student_name,
      studentEmail: d.student_email || "",
      studentLevel: d.level,
      level: d.level,
      subject: d.subject,
      title: d.title,
      fileData: d.file_data,
      fileName: d.file_name,
      fileType: d.file_type,
      studentComment: d.student_comment || "",
      status: d.status || "SUBMITTED",
      grade20: d.grade20 ? Number(d.grade20) : undefined,
      grade: d.grade20 ? Number(d.grade20) : undefined,
      maxGrade: d.max_grade ? Number(d.max_grade) : 20,
      feedback: d.feedback || "",
      adminFeedback: d.feedback || "",
      annotatedPdfData: d.annotated_pdf_data || undefined,
      gradedBy: d.graded_by || undefined,
      gradedAt: d.graded_at ? Number(d.graded_at) : undefined,
      submittedAt: d.submitted_at ? Number(d.submitted_at) : Date.now(),
      dateFormatted: new Date(d.submitted_at || Date.now()).toLocaleDateString("fr-FR"),
    }));
  } catch (err) {
    console.warn("[Supabase] Error fetching homework submissions:", err);
    return [];
  }
}

export async function submitHomeworkToSupabase(submission: HomeworkSubmission): Promise<void> {
  if (!supabase) return;
  const { error } = await supabase.from("homework_submissions").upsert({
    id: submission.id,
    student_uid: submission.userUid,
    student_name: submission.studentName,
    student_email: submission.studentEmail || null,
    matricule: submission.matricule || submission.studentMatricule || null,
    level: submission.level,
    subject: submission.subject,
    title: submission.title,
    file_data: submission.fileData,
    file_name: submission.fileName,
    file_type: submission.fileType,
    student_comment: submission.studentComment || submission.comment || null,
    status: submission.status || "SUBMITTED",
    submitted_at: submission.submittedAt || Date.now(),
  });
  if (error) {
    console.error("[Supabase] Error submitting homework to 'homework_submissions':", error);
    throw error;
  }
}

export async function gradeHomeworkInSupabase(
  id: string,
  grade20: number,
  feedback: string,
  adminName = "Massaw Seck",
  annotatedPdfData?: string
): Promise<void> {
  if (!supabase) return;
  const { error } = await supabase
    .from("homework_submissions")
    .update({
      status: "GRADED",
      grade20,
      feedback,
      admin_feedback: feedback,
      graded_by: adminName,
      annotated_pdf_data: annotatedPdfData || null,
      graded_at: Date.now(),
    })
    .eq("id", id);

  if (error) {
    console.error("[Supabase] Error grading homework in 'homework_submissions':", error);
    throw error;
  }
}

export async function deleteHomeworkFromSupabase(id: string): Promise<void> {
  if (!supabase) return;
  const { error } = await supabase.from("homework_submissions").delete().eq("id", id);
  if (error) {
    console.error("[Supabase] Error deleting homework from 'homework_submissions':", error);
    throw error;
  }
}

export function subscribeToHomeworkSubmissionsSupabase(
  onUpdate: (submissions: HomeworkSubmission[]) => void
): () => void {
  if (!supabase) return () => {};

  fetchHomeworkSubmissionsSupabase().then((list) => {
    onUpdate(list);
  });

  const channelName = `hw_submissions_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
  const channel = supabase
    .channel(channelName)
    .on(
      "postgres_changes",
      { event: "*", schema: "public", table: "homework_submissions" },
      () => {
        fetchHomeworkSubmissionsSupabase().then((list) => onUpdate(list));
      }
    )
    .subscribe();

  return () => {
    if (supabase && channel) {
      try {
        supabase.removeChannel(channel);
      } catch (err) {
        console.warn("[Supabase] Remove channel error:", err);
      }
    }
  };
}

export function subscribeToUserHomeworksSupabase(
  userUid: string,
  onUpdate: (submissions: HomeworkSubmission[]) => void
): () => void {
  if (!supabase || !userUid) return () => {};

  const fetchUserHw = async () => {
    try {
      const { data, error } = await supabase
        .from("homework_submissions")
        .select("*")
        .eq("student_uid", userUid)
        .order("submitted_at", { ascending: false });

      if (error) {
        logSupabaseError("devoirs (table 'homework_submissions')", error);
        return;
      }
      if (!data) return;

      onUpdate(
        data.map((d: any) => ({
          id: d.id,
          userUid: d.student_uid || "",
          studentMatricule: d.matricule || "",
          matricule: d.matricule || "",
          studentName: d.student_name,
          studentEmail: d.student_email || "",
          studentLevel: d.level,
          level: d.level,
          subject: d.subject,
          title: d.title,
          fileData: d.file_data,
          fileName: d.file_name,
          fileType: d.file_type,
          studentComment: d.student_comment || "",
          status: d.status || "SUBMITTED",
          grade20: d.grade20 ? Number(d.grade20) : undefined,
          grade: d.grade20 ? Number(d.grade20) : undefined,
          maxGrade: d.max_grade ? Number(d.max_grade) : 20,
          feedback: d.feedback || "",
          adminFeedback: d.feedback || "",
          annotatedPdfData: d.annotated_pdf_data || undefined,
          gradedBy: d.graded_by || undefined,
          gradedAt: d.graded_at ? Number(d.graded_at) : undefined,
          submittedAt: d.submitted_at ? Number(d.submitted_at) : Date.now(),
          dateFormatted: new Date(d.submitted_at || Date.now()).toLocaleDateString("fr-FR"),
        }))
      );
    } catch (err) {
      console.error("[Supabase] Unexpected error fetching user homeworks:", err);
    }
  };

  fetchUserHw();

  const channelName = `user_hw_${userUid}_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
  const channel = supabase
    .channel(channelName)
    .on(
      "postgres_changes",
      { event: "*", schema: "public", table: "homework_submissions" },
      () => {
        fetchUserHw();
      }
    )
    .subscribe();

  return () => {
    if (supabase && channel) {
      try {
        supabase.removeChannel(channel);
      } catch (err) {
        console.warn("[Supabase] Remove channel error:", err);
      }
    }
  };
}

// ============================================================================
// 7. VIP PAYMENT REQUESTS (CRUD + Realtime)
// ============================================================================

export async function fetchVIPPaymentRequestsSupabase(): Promise<VIPPaymentRequest[]> {
  // Read local cache to ensure pending requests are never wiped out by empty responses
  const localMap = new Map<string, VIPPaymentRequest>();
  try {
    const raw = typeof window !== "undefined" ? localStorage.getItem("savoirplus_vip_payment_requests") : null;
    if (raw) {
      const parsed: VIPPaymentRequest[] = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        parsed.forEach((r) => { if (r && r.id) localMap.set(r.id, r); });
      }
    }
  } catch (err) {
    console.warn("[LocalCache VIP] Error reading cache:", err);
  }

  if (!supabase) return Array.from(localMap.values()).sort((a, b) => b.createdAt - a.createdAt);

  try {
    let { data, error } = await supabase
      .from("vip_payment_requests")
      .select("*")
      .order("created_at", { ascending: false });

    if (error) {
      logSupabaseError("demandes VIP (table 'vip_payment_requests')", error);
      return Array.from(localMap.values()).sort((a, b) => b.createdAt - a.createdAt);
    }
    if (data && Array.isArray(data)) {
      // Enrich with profiles map to resolve any NULL student_id or class_id
      let profilesMap = new Map<string, any>();
      try {
        const { data: profData } = await supabase.from("profiles").select("*");
        if (profData && Array.isArray(profData)) {
          profData.forEach((p) => profilesMap.set(p.id, p));
        }
      } catch (profErr) {
        console.warn("[VIPReqs] Profiles enrich notice:", profErr);
      }

      const remoteMap = new Map<string, VIPPaymentRequest>();
      data.forEach((d: any) => {
        const uid = d.student_uid || d.user_uid || d.user_id || d.eleve_id || d.id;
        const prof = profilesMap.get(uid);

        const rawStatus = (d.status || "PENDING").toString().toLowerCase().trim();
        const normStatus: VIPRequestStatus = 
          rawStatus === "approved" || rawStatus === "valide" || rawStatus === "validée" || rawStatus === "approuve" || rawStatus === "approuvée" ? "APPROVED" :
          rawStatus === "rejected" || rawStatus === "refuse" || rawStatus === "refusée" ? "REJECTED" : "PENDING";
        
        const createdAt = Number(d.requested_at || d.created_at || Date.now());
        const item: VIPPaymentRequest = {
          id: d.id,
          userUid: uid,
          student_uid: uid,
          studentName: d.student_name || d.user_name || prof?.display_name || "Élève",
          userName: d.student_name || d.user_name || prof?.display_name || "Élève",
          userPhone: d.student_phone || d.user_phone || prof?.phone_number || "",
          transactionRef: d.transaction_ref || d.transaction_id || "REF",
          amount: Number(d.amount || 0),
          status: normStatus,
          rejectionReason: d.rejection_reason || undefined,
          planId: d.plan_id,
          plan_id: d.plan_id,
          createdAt,
          dateFormatted: new Date(createdAt).toLocaleDateString("fr-FR"),
        };
        remoteMap.set(item.id, item);
      });

      // Save updated list to local storage
      try {
        if (typeof window !== "undefined") {
          localStorage.setItem("savoirplus_vip_payment_requests", JSON.stringify(Array.from(remoteMap.values())));
        }
      } catch (e) {
        // ignore
      }

      return Array.from(remoteMap.values()).sort((a, b) => b.createdAt - a.createdAt);
    }

    return Array.from(localMap.values()).sort((a, b) => b.createdAt - a.createdAt);
  } catch (err) {
    logSupabaseError("demandes VIP (table 'vip_payment_requests')", err);
    return Array.from(localMap.values()).sort((a, b) => b.createdAt - a.createdAt);
  }
}

export async function saveVIPPaymentRequestToSupabase(req: VIPPaymentRequest | any): Promise<void> {
  if (!supabase) return;
  const { data: authData } = await supabase.auth.getUser();
  const authUserId = authData?.user?.id;
  const rawStudentUid = req.student_uid || req.userUid || authUserId || "";

  const isUuid = /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/.test(rawStudentUid.trim());
  if (!isUuid) {
    throw new Error("Identifiant élève invalide : 'student_uid' doit être au format UUID Supabase.");
  }

  const payload: any = {
    id: req.id || `vip_req_${Date.now()}`,
    student_uid: rawStudentUid.trim(),
    student_name: req.student_name || req.studentName || req.userName || "Élève",
    student_phone: req.student_phone || req.userPhone || "",
    level: req.level || req.userLevel || "3ème",
    plan_id: req.plan_id || req.planId || "3mois",
    amount: Number(req.amount || 2000),
    status: (req.status || "PENDING").toUpperCase(),
    requested_at: Date.now(),
    operator: req.operator || "wave",
    transaction_ref: req.transaction_ref || req.transactionRef || "",
  };

  const { error } = await supabase.from("vip_payment_requests").upsert(payload);
  if (error) {
    console.error("[Supabase Error] Exception lors de l'enregistrement de la demande VIP:", error);
    const detailMsg = error.message || error.details || error.hint || JSON.stringify(error);
    throw new Error(`Erreur Supabase (${error.code || "DB/RLS"}) : ${detailMsg}`);
  }
}

export async function updateVIPPaymentRequestStatusSupabase(
  requestId: string,
  status: VIPRequestStatus | "approved" | "rejected" | "pending",
  userUid?: string,
  rejectionReason?: string,
  vipPlan?: string,
  vipExpiresAt?: number,
  studentName?: string
): Promise<void> {
  // 0. Update local storage cache immediately
  try {
    if (typeof window !== "undefined") {
      const raw = localStorage.getItem("savoirplus_vip_payment_requests");
      if (raw) {
        const list: VIPPaymentRequest[] = JSON.parse(raw);
        const normStatus: VIPRequestStatus = String(status).toUpperCase() === "APPROVED" ? "APPROVED" : String(status).toUpperCase() === "REJECTED" ? "REJECTED" : "PENDING";
        const updatedList = list.map((item) => {
          if (item.id === requestId || (userUid && item.userUid === userUid && item.status === "PENDING")) {
            return {
              ...item,
              status: normStatus,
              rejectionReason: normStatus === "REJECTED" ? (rejectionReason || item.rejectionReason) : undefined,
            };
          }
          return item;
        });
        localStorage.setItem("savoirplus_vip_payment_requests", JSON.stringify(updatedList));
      }
    }
  } catch {}

  if (!supabase) return;
  try {
    const isApproved = String(status).toUpperCase() === "APPROVED";
    const isRejected = String(status).toUpperCase() === "REJECTED";
    const uppercaseStatus = isApproved ? "APPROVED" : isRejected ? "REJECTED" : "PENDING";
    const lowercaseStatus = isApproved ? "approved" : isRejected ? "rejected" : "pending";

    // Étape A : Mettre à jour la demande dans vip_payment_requests (compatible lowercase et uppercase)
    try {
      await supabase.from("vip_payment_requests").update({
        status: lowercaseStatus,
        rejection_reason: isRejected ? (rejectionReason || null) : null,
        updated_at: Date.now(),
        processed_at: Date.now(),
      }).eq("id", requestId);
    } catch {}

    try {
      await supabase.from("vip_payment_requests").update({
        status: uppercaseStatus,
        rejection_reason: isRejected ? (rejectionReason || null) : null,
        updated_at: Date.now(),
        processed_at: Date.now(),
      }).eq("id", requestId);
    } catch {}

    await safeUpdateSupabaseTable("vip_payment_requests", requestId, { 
      status: lowercaseStatus, 
      rejection_reason: rejectionReason || null,
      updated_at: Date.now(),
      processed_at: Date.now(),
    });

    if (isApproved && userUid) {
      // Étape B : Activer le statut VIP dans la table profiles de l'élève
      await safeUpdateProfile(userUid, { 
        is_vip: true, 
        vip_plan: vipPlan || "1 Mois",
        vip_expires_at: vipExpiresAt || null,
        updated_at: Date.now(),
      });

      // Étape C : Envoyer une notification à l'élève
      const notifId = `notif_vip_appr_${requestId}`;
      const now = Date.now();
      const dateFormatted = `Aujourd'hui à ${new Date().toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}`;

      await supabase.from("notifications").insert([{
        id: notifId,
        target_uid: userUid,
        user_id: userUid,
        user_uid: userUid,
        recipient_id: userUid,
        target_role: "student",
        title: "Pass VIP Activé !",
        message: "Votre demande de Pass VIP a été validée avec succès.",
        type: "vip_approved",
        status: "unread",
        is_read: false,
        created_at: now,
        date_formatted: dateFormatted,
      }]);
    } else if (isRejected && userUid) {
      const notifId = `notif_vip_rej_${requestId}`;
      const now = Date.now();
      const dateFormatted = `Aujourd'hui à ${new Date().toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}`;

      await supabase.from("notifications").insert([{
        id: notifId,
        target_uid: userUid,
        user_id: userUid,
        user_uid: userUid,
        recipient_id: userUid,
        target_role: "student",
        title: "Demande Pass VIP non validée",
        message: `Votre demande de Pass VIP n'a pas été acceptée.${rejectionReason ? ` Motif : ${rejectionReason}` : ""}`,
        type: "vip_rejected",
        status: "unread",
        is_read: false,
        created_at: now,
        date_formatted: dateFormatted,
      }]);
    }
    // Mark admin notifications as processed
    if (userUid) {
      await markAdminNotificationAsProcessed(userUid, "vip_request");
    }
  } catch (err) {
    console.error("[Supabase] Unexpected error updating VIP payment status:", err);
    throw err;
  }
}

export function subscribeToVIPPaymentRequestsSupabase(
  onUpdate: (requests: VIPPaymentRequest[]) => void
): () => void {
  if (!supabase) return () => {};

  fetchVIPPaymentRequestsSupabase().then((list) => {
    onUpdate(list);
  });

  const channelName = `vip_payment_requests_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
  const channel = supabase
    .channel(channelName)
    .on(
      "postgres_changes",
      { event: "*", schema: "public", table: "vip_payment_requests" },
      () => {
        fetchVIPPaymentRequestsSupabase().then((list) => onUpdate(list));
      }
    )
    .subscribe();

  return () => {
    if (supabase && channel) {
      try {
        supabase.removeChannel(channel);
      } catch (err) {
        console.warn("[Supabase] Remove channel error:", err);
      }
    }
  };
}

// ============================================================================
// 8. CLASS CHANGE REQUESTS (CRUD + Realtime)
// ============================================================================

export async function fetchClassChangeRequestsSupabase(): Promise<ClassChangeRequest[]> {
  const localMap = new Map<string, ClassChangeRequest>();
  try {
    const raw = typeof window !== "undefined" ? localStorage.getItem("savoirplus_class_change_requests") : null;
    if (raw) {
      const parsed: ClassChangeRequest[] = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        parsed.forEach((r) => { if (r && r.id) localMap.set(r.id, r); });
      }
    }
  } catch (err) {
    console.warn("[LocalCache ClassReqs] Error reading local cache:", err);
  }

  if (!supabase) return Array.from(localMap.values()).sort((a, b) => b.createdAt - a.createdAt);

  try {
    let { data, error } = await supabase
      .from("class_change_requests")
      .select("*")
      .order("created_at", { ascending: false });

    if (error) {
      logSupabaseError("demandes de changement de classe (table 'class_change_requests')", error);
      return Array.from(localMap.values()).sort((a, b) => b.createdAt - a.createdAt);
    }
    if (data && Array.isArray(data)) {
      // Enrich with profiles map to resolve any NULL student_id or class_id
      let profilesMap = new Map<string, any>();
      try {
        const { data: profData } = await supabase.from("profiles").select("*");
        if (profData && Array.isArray(profData)) {
          profData.forEach((p) => profilesMap.set(p.id, p));
        }
      } catch (profErr) {
        console.warn("[ClassReqs] Profiles enrich notice:", profErr);
      }

      const remoteMap = new Map<string, ClassChangeRequest>();
      data.forEach((d: any) => {
        const uid = d.student_uid || d.user_uid || d.user_id || d.eleve_id || d.id;
        const prof = profilesMap.get(uid);

        const rawStatus = (d.status || 'pending').toString().toLowerCase().trim();
        const normStatus: ClassChangeStatus = 
          rawStatus === 'approved' || rawStatus === 'valide' || rawStatus === 'validée' || rawStatus === 'approuve' || rawStatus === 'approuvée' || rawStatus === 'validated'
            ? 'approved'
            : rawStatus === 'rejected' || rawStatus === 'refuse' || rawStatus === 'refusée'
            ? 'rejected'
            : 'pending';

        const createdAt = Number(d.requested_at || d.created_at || Date.now());
        const item: ClassChangeRequest = {
          id: d.id,
          userUid: uid,
          userName: d.student_name || d.user_name || prof?.display_name || "Élève",
          userEmail: d.student_email || d.user_email || prof?.email || "",
          studentMatricule: d.matricule || prof?.student_id || prof?.matricule || "",
          currentLevel: d.current_level || d.current_class || prof?.classe || prof?.level || "Non spécifiée",
          requestedLevel: d.requested_level || d.requested_class || "Terminale S2",
          reason: d.reason || "",
          status: normStatus,
          rejectionReason: d.rejection_reason || undefined,
          createdAt,
          dateFormatted: new Date(createdAt).toLocaleDateString("fr-FR"),
        };
        remoteMap.set(item.id, item);
      });

      // Synchronize back to local storage
      try {
        if (typeof window !== "undefined") {
          localStorage.setItem("savoirplus_class_change_requests", JSON.stringify(Array.from(remoteMap.values())));
        }
      } catch (e) {
        // ignore
      }

      return Array.from(remoteMap.values()).sort((a, b) => b.createdAt - a.createdAt);
    }

    return Array.from(localMap.values()).sort((a, b) => b.createdAt - a.createdAt);
  } catch (err) {
    logSupabaseError("demandes de changement de classe (table 'class_change_requests')", err);
    return Array.from(localMap.values()).sort((a, b) => b.createdAt - a.createdAt);
  }
}

export async function saveClassChangeRequestToSupabase(req: ClassChangeRequest): Promise<void> {
  if (!supabase) return;
  const payload: any = {
    id: req.id,
    student_uid: req.userUid,
    user_uid: req.userUid,
    student_name: req.userName,
    student_email: req.userEmail,
    current_level: req.currentLevel,
    requested_level: req.requestedLevel,
    reason: req.reason,
    status: (req.status || "PENDING").toUpperCase(),
    requested_at: req.createdAt || Date.now(),
  };

  try {
    let { error } = await supabase.from("class_change_requests").upsert(payload);

    // Résilience si une colonne optionnelle n'existe pas dans le cache du schéma Supabase (PGRST204)
    let attempts = 0;
    while (error && error.code === "PGRST204" && attempts < 3) {
      attempts++;
      const match = error.message?.match(/Could not find the '([^']+)' column/);
      if (match && match[1] && match[1] in payload) {
        delete payload[match[1]];
        const retryResult = await supabase.from("class_change_requests").upsert(payload);
        error = retryResult.error;
      } else {
        break;
      }
    }

    if (error) {
      console.error("[Supabase] Error saving class change request:", error);
      throw error;
    }
  } catch (err) {
    console.error("[Supabase] Unexpected exception saving class change request:", err);
    throw err;
  }
}

export async function deleteClassChangeRequestSupabase(requestId: string): Promise<void> {
  if (!supabase) return;
  try {
    await supabase.from("class_change_requests").delete().eq("id", requestId);
    try {
      await supabase.from("demandes_changement_classe").delete().eq("id", requestId);
    } catch {
      // ignore
    }
  } catch (err) {
    console.warn("[Supabase] Warning deleting class change request:", err);
  }
}

export async function updateClassChangeRequestStatusSupabase(
  requestId: string,
  status: ClassChangeStatus,
  userUid?: string,
  newLevel?: SecondaryLevel,
  rejectReason?: string,
  userName?: string
): Promise<void> {
  // 0. Mise à jour immédiate du cache local pour que les rafraîchissements conservent l'état validé
  try {
    if (typeof window !== "undefined") {
      const raw = localStorage.getItem("savoirplus_class_change_requests");
      if (raw) {
        const list: ClassChangeRequest[] = JSON.parse(raw);
        const updatedList = list.map((item) => {
          if (item.id === requestId || (userUid && item.userUid === userUid && item.status === "pending")) {
            return {
              ...item,
              status: status,
              rejectionReason: status === "rejected" ? (rejectReason || item.rejectionReason) : undefined,
              requestedLevel: newLevel || item.requestedLevel,
            };
          }
          return item;
        });
        localStorage.setItem("savoirplus_class_change_requests", JSON.stringify(updatedList));
      }
    }
  } catch {}

  if (!supabase) return;
  try {
    const isApproved = status === "approved" || String(status).toUpperCase() === "APPROVED";
    const isRejected = status === "rejected" || String(status).toUpperCase() === "REJECTED";
    const lowercaseStatus = isApproved ? "approved" : isRejected ? "rejected" : "pending";
    const uppercaseStatus = isApproved ? "APPROVED" : isRejected ? "REJECTED" : "PENDING";

    // 1. Mettre à jour définitivement le statut dans la table class_change_requests (compatible lowercase et uppercase)
    try {
      await supabase.from("class_change_requests").update({
        status: lowercaseStatus,
        rejection_reason: isRejected ? (rejectReason || null) : null,
        requested_level: newLevel || undefined,
        updated_at: Date.now(),
        processed_at: Date.now(),
      }).eq("id", requestId);
    } catch {}

    try {
      await supabase.from("class_change_requests").update({
        status: uppercaseStatus,
        rejection_reason: isRejected ? (rejectReason || null) : null,
        requested_level: newLevel || undefined,
        updated_at: Date.now(),
        processed_at: Date.now(),
      }).eq("id", requestId);
    } catch {}

    await safeUpdateSupabaseTable("class_change_requests", requestId, { 
      status: lowercaseStatus, 
      requested_level: newLevel || undefined,
      rejection_reason: isRejected ? (rejectReason || null) : null,
      updated_at: Date.now(),
      processed_at: Date.now(),
    });

    if (isApproved && newLevel && userUid) {
      // 2. Mettre à jour le profil de l'élève (classe / niveau) dans la table profiles
      await safeUpdateProfile(userUid, { 
        level: newLevel, 
        classe: newLevel,
        class_id: newLevel,
        niveau: newLevel,
        is_profile_complete: true,
        updated_at: Date.now(),
      });

      // Tenter les RPC existantes en complément
      try {
        await supabase.rpc("approve_class_change", {
          request_id: requestId,
          student_id: userUid,
          new_class_name: newLevel,
        });
      } catch {
        // RPC facultative
      }

      // 3. Notification temps réel pour l'élève
      await saveNotificationToSupabase({
        id: "notif_lvl_appr_" + requestId,
        recipient: userUid,
        target_uid: userUid,
        targetUid: userUid,
        userUid,
        title: "✅ Demande de changement de classe approuvée !",
        message: `Félicitations ! L'administration a validé votre passage en classe de ${newLevel}. Vos cours, devoirs et QCM sont immédiatement actualisés.`,
        type: "CLASS_CHANGE",
        status: "UNREAD",
        createdAt: Date.now(),
        dateFormatted: new Date().toLocaleDateString("fr-FR"),
      });
    } else if (isRejected && userUid) {
      await saveNotificationToSupabase({
        id: "notif_lvl_rej_" + requestId,
        recipient: userUid,
        target_uid: userUid,
        targetUid: userUid,
        userUid,
        title: "❌ Demande de changement de classe refusée",
        message: `Votre demande pour passer en classe de ${newLevel || ""} n'a pas été acceptée.${rejectReason ? ` Motif : ${rejectReason}` : ""}`,
        type: "CLASS_CHANGE",
        status: "UNREAD",
        createdAt: Date.now(),
        dateFormatted: new Date().toLocaleDateString("fr-FR"),
      });
    }

    // 4. Marquer les notifications administrateur associées comme traitées
    if (userUid) {
      await markAdminNotificationAsProcessed(userUid, "class_change");
    }
  } catch (err) {
    console.error("[Supabase] Unexpected error updating class change status:", err);
  }
}

/**
 * Mise à jour directe de la classe d'un élève par l'administration.
 * Remplace l'ancienne classe par la nouvelle, valide les demandes associées sans les supprimer et notifie l'élève.
 */
export async function updateStudentLevelSupabase(
  studentUid: string,
  newLevel: SecondaryLevel
): Promise<void> {
  if (!supabase || !studentUid || !newLevel) return;
  try {
    // 0. Exécution de la fonction RPC Supabase admin_change_student_class
    try {
      const { error: rpcErr } = await supabase.rpc("admin_change_student_class", {
        target_student_id: studentUid,
        new_class_name: newLevel,
      });
      if (rpcErr) {
        console.warn("[Supabase] admin_change_student_class RPC warning:", rpcErr);
      }
    } catch (e) {
      console.warn("[Supabase] admin_change_student_class RPC exception:", e);
    }

    // 1. Mettre à jour la table profiles
    await safeUpdateProfile(studentUid, {
      level: newLevel,
      classe: newLevel,
      class_id: newLevel,
      niveau: newLevel,
      is_profile_complete: true,
      updated_at: Date.now(),
    });

    // 2. Mettre à jour la table users_profile si elle existe
    try {
      await supabase
        .from("users_profile")
        .update({
          level: newLevel,
          classe: newLevel,
        })
        .eq("id", studentUid);
    } catch {}

    // 3. IMPORTANT : Marquer toute demande de changement de classe en cours comme APPROUVÉE (ne jamais supprimer pour garder l'historique fiable)
    try {
      await supabase
        .from("class_change_requests")
        .update({
          status: "approved",
          requested_level: newLevel,
          updated_at: Date.now(),
          processed_at: Date.now(),
        })
        .eq("student_uid", studentUid)
        .eq("status", "pending");
    } catch {}
    try {
      await supabase
        .from("class_change_requests")
        .update({
          status: "approved",
          requested_level: newLevel,
          updated_at: Date.now(),
          processed_at: Date.now(),
        })
        .eq("user_uid", studentUid)
        .eq("status", "pending");
    } catch {}

    // 4. Notification ciblée pour l'élève avec target_uid
    await saveNotificationToSupabase({
      id: "notif_lvl_direct_" + Date.now(),
      target_uid: studentUid,
      targetUid: studentUid,
      userUid: studentUid,
      userId: studentUid,
      recipientId: studentUid,
      title: `🎓 Classe mise à jour : ${newLevel}`,
      message: `L'administration a mis à jour votre classe. Vous êtes désormais en classe de ${newLevel}. Vos cours, exercices et devoirs ont été automatiquement actualisés.`,
      type: "class_change",
      status: "unread",
      createdAt: Date.now(),
      dateFormatted: new Date().toLocaleDateString("fr-FR"),
    });
  } catch (err) {
    console.error("[Supabase] Unexpected error updating student level:", err);
    throw err;
  }
}

export function subscribeToClassChangeRequestsSupabase(
  onUpdate: (requests: ClassChangeRequest[]) => void
): () => void {
  if (!supabase) return () => {};

  fetchClassChangeRequestsSupabase().then((list) => {
    onUpdate(list);
  });

  const channelName = `class_change_requests_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
  const channel = supabase
    .channel(channelName)
    .on(
      "postgres_changes",
      { event: "*", schema: "public", table: "class_change_requests" },
      async () => {
        const list = await fetchClassChangeRequestsSupabase();
        onUpdate(list);
      }
    )
    .subscribe();

  return () => {
    if (supabase && channel) {
      try {
        supabase.removeChannel(channel);
      } catch (err) {
        console.warn("[Supabase] Remove channel error:", err);
      }
    }
  };
}

// ============================================================================
// 9. GENERAL TRANSACTIONS (CRUD + Realtime)
// ============================================================================

export async function fetchTransactionsSupabase(userUid?: string): Promise<PaymentTransaction[]> {
  const mergedMap = new Map<string, PaymentTransaction>();

  // Read local cache first for zero-lag and offline fallback
  try {
    const raw = typeof window !== "undefined" ? localStorage.getItem("savoirplus_transactions") : null;
    if (raw) {
      const parsed: PaymentTransaction[] = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        parsed.forEach((tx) => { if (tx && tx.id) mergedMap.set(tx.id, tx); });
      }
    }
  } catch (err) {
    console.warn("[LocalCache Tx] Error reading cache:", err);
  }

  if (!supabase) return Array.from(mergedMap.values()).sort((a, b) => b.createdAt - a.createdAt);

  // 1. Fetch from public.payment_transactions
  try {
    let qPay = supabase
      .from("payment_transactions")
      .select("*")
      .order("created_at", { ascending: false });

    if (userUid) {
      qPay = qPay.or(`student_id.eq.${userUid},id.eq.${userUid}`);
    }

    const { data: payData, error: payError } = await qPay;
    if (!payError && Array.isArray(payData)) {
      payData.forEach((d: any) => {
        const op = (d.payment_method || d.operator || "").toString().toUpperCase().includes("ORANGE") ? "orange" : "wave";
        const rawStatus = (d.status || "pending").toString().toLowerCase().trim();
        const st: TransactionStatus =
          rawStatus === "approved" || rawStatus === "valide" || rawStatus === "approuve"
            ? "approved"
            : rawStatus === "rejected" || rawStatus === "refuse"
            ? "rejected"
            : "pending";
        const txCreatedAt = Number(d.created_at || Date.now());

        const item: PaymentTransaction = {
          id: d.id || d.transaction_ref || `tx_${Math.random()}`,
          userUid: d.student_id || userUid || "",
          userId: d.student_id || userUid || "",
          userName: d.student_name || "Élève",
          learnerName: d.student_name || "Apprenant",
          level: d.course_title || d.class_name || "Général",
          type: "renforcement",
          paymentType: "mensualite",
          amount: Number(d.amount || 0),
          operator: op,
          status: st,
          createdAt: txCreatedAt,
          dateFormatted: d.date_formatted || new Date(txCreatedAt).toLocaleDateString("fr-FR"),
        };
        mergedMap.set(item.id, item);
      });
    }
  } catch (err) {
    logSupabaseError("fetching from payment_transactions", err);
  }

  // 2. Fetch from public.transactions
  try {
    let query = supabase
      .from("transactions")
      .select("*")
      .order("created_at", { ascending: false, nullsFirst: false });

    if (userUid) {
      query = query.or(`user_id.eq.${userUid},user_uid.eq.${userUid}`);
    }

    const { data, error } = await query;
    if (!error && Array.isArray(data)) {
      data.forEach((d: any) => {
        const op = (d.operator || d.payment_method || "").toString().toUpperCase().includes("ORANGE") ? "orange" : "wave";
        const rawStatus = (d.status || "pending").toString().toLowerCase().trim();
        const st: TransactionStatus =
          rawStatus === "approved" || rawStatus === "valide" || rawStatus === "approuve"
            ? "approved"
            : rawStatus === "rejected" || rawStatus === "refuse"
            ? "rejected"
            : "pending";
        const txCreatedAt = d.created_at
          ? typeof d.created_at === "number"
            ? d.created_at
            : new Date(d.created_at).getTime()
          : Date.now();

        const item: PaymentTransaction = {
          id: d.transaction_id || d.id || `tx_${Math.random()}`,
          userUid: d.user_id || d.user_uid || userUid || "",
          userId: d.user_id || d.user_uid || userUid || "",
          userName: d.student_name || d.user_name || d.learner_name || "Élève",
          learnerName: d.student_name || d.learner_name || d.user_name || "Apprenant",
          level: d.class_name || d.level || "3eme",
          type: d.type || "renforcement",
          paymentType: d.payment_type || "mensualite",
          selectedMonth: d.selected_month,
          amount: Number(d.amount || 0),
          operator: op,
          status: st,
          rejectionReason: d.rejection_reason,
          createdAt: txCreatedAt,
          dateFormatted: new Date(txCreatedAt).toLocaleDateString("fr-FR"),
        };
        mergedMap.set(item.id, item);
      });
    }
  } catch (err) {
    logSupabaseError("unexpected error fetching transactions", err);
  }

  const result = Array.from(mergedMap.values()).sort((a, b) => b.createdAt - a.createdAt);

  // Sync back to local storage
  try {
    if (typeof window !== "undefined") {
      localStorage.setItem("savoirplus_transactions", JSON.stringify(result));
    }
  } catch (e) {
    // ignore
  }

  return result;
}

export async function saveTransactionToSupabase(tx: PaymentTransaction): Promise<void> {
  if (!supabase) return;
  const operatorFormatted = (tx.operator === "orange" || tx.operator?.toString().toUpperCase().includes("ORANGE")) 
    ? "ORANGE_MONEY" 
    : "WAVE";

  const statusFormatted = tx.status === "approved" 
    ? "APPROVED" 
    : tx.status === "rejected" 
    ? "REJECTED" 
    : "PENDING";

  // 1. Save to payment_transactions
  try {
    const payPayload = {
      id: tx.id,
      student_name: tx.learnerName || tx.userName || "Apprenant",
      student_id: tx.userId || tx.userUid || "",
      course_id: tx.type || null,
      course_title: tx.level || "Cours",
      amount: Number(tx.amount || 0),
      payment_method: operatorFormatted,
      status: (tx.status || "pending").toLowerCase(),
      transaction_ref: tx.id,
      created_at: tx.createdAt || Date.now(),
      date_formatted: tx.dateFormatted || new Date(tx.createdAt || Date.now()).toLocaleDateString("fr-FR"),
    };
    await supabase.from("payment_transactions").upsert(payPayload);
  } catch (err) {
    console.warn("[Supabase] payment_transactions save fallback:", err);
  }

  // 2. Save to transactions
  const essentialPayload = {
    user_id: tx.userId || tx.userUid,
    student_name: tx.learnerName || tx.userName || "Apprenant",
    class_name: tx.level || "",
    operator: operatorFormatted,
    transaction_id: tx.id || `TX-${Date.now()}`,
    amount: Number(tx.amount || 0),
    status: statusFormatted,
  };

  try {
    const { error } = await supabase.from("transactions").insert([essentialPayload]);
    if (error) {
      logSupabaseError("saving transaction to 'transactions' table", error);
      
      const fallbackPayload = {
        id: tx.id,
        user_uid: tx.userUid || tx.userId,
        user_name: tx.userName || tx.learnerName,
        learner_name: tx.learnerName || tx.userName,
        level: tx.level,
        type: tx.type,
        payment_type: tx.paymentType,
        selected_month: tx.selectedMonth || null,
        amount: tx.amount,
        operator: tx.operator,
        status: (tx.status || "pending").toLowerCase(),
        rejection_reason: tx.rejectionReason || null,
        created_at: tx.createdAt || Date.now(),
      };
      
      try {
        await supabase.from("transactions").upsert(fallbackPayload);
      } catch (fbErr) {
        console.warn("fallback saving transaction err:", fbErr);
      }
    }
  } catch (err) {
    logSupabaseError("unexpected exception saving transaction", err);
  }
}

export async function updateTransactionStatusSupabase(
  txId: string,
  status: TransactionStatus,
  rejectionReason?: string
): Promise<void> {
  if (!supabase) return;
  try {
    // Update public.transactions
    await supabase
      .from("transactions")
      .update({
        status,
        rejection_reason: rejectionReason || null,
      })
      .eq("id", txId);

    // Update public.payment_transactions
    await supabase
      .from("payment_transactions")
      .update({
        status: (status || "pending").toLowerCase(),
      })
      .eq("id", txId);
  } catch (err) {
    logSupabaseError("updating transaction status", err);
  }
}

export async function deleteTransactionFromSupabase(txId: string): Promise<void> {
  if (!supabase) return;
  try {
    await supabase.from("transactions").delete().eq("id", txId);
    await supabase.from("payment_transactions").delete().eq("id", txId);
  } catch (err) {
    logSupabaseError("unexpected error deleting transaction", err);
  }
}

export function subscribeToAllTransactionsSupabase(
  onUpdate: (txs: PaymentTransaction[]) => void
): () => void {
  if (!supabase) return () => {};

  fetchTransactionsSupabase().then((list) => {
    onUpdate(list);
  });

  const channelName = `transactions_all_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
  const channel = supabase
    .channel(channelName)
    .on(
      "postgres_changes",
      { event: "*", schema: "public", table: "payment_transactions" },
      async () => {
        const list = await fetchTransactionsSupabase();
        onUpdate(list);
      }
    )
    .on(
      "postgres_changes",
      { event: "*", schema: "public", table: "transactions" },
      async () => {
        const list = await fetchTransactionsSupabase();
        onUpdate(list);
      }
    )
    .subscribe();

  return () => {
    if (supabase && channel) {
      try {
        supabase.removeChannel(channel);
      } catch (err) {
        console.warn("[Supabase] Remove channel error:", err);
      }
    }
  };
}

// ============================================================================
// 10. NOTIFICATIONS & AUDIT LOGS
// ============================================================================

export async function saveNotificationToSupabase(notif: UserNotification | any): Promise<void> {
  if (!supabase) return;

  const targetUid = notif.target_uid || notif.targetUid || notif.recipientId || notif.userUid;
  const isTargetAdmin =
    notif.recipient === "admin" ||
    notif.recipientId === "admin" ||
    targetUid === "admin" ||
    notif.targetRole === "admin" ||
    notif.type === "admin_alert";

  const recipientEmail = notif.recipient
    ? notif.recipient
    : isTargetAdmin
    ? "admin"
    : (notif.userEmail || notif.user_email || notif.recipientId || targetUid || "admin");

  const senderEmail = notif.sender_email || notif.senderEmail || notif.userEmail || notif.user_email || (recipientEmail === "admin" ? "" : "admin");

  let dbStatus = "UNREAD";
  const s = String(notif.status || "").toUpperCase();
  if (s === "READ" || notif.is_read === true) {
    dbStatus = "READ";
  } else if (s === "PROCESSED") {
    dbStatus = "PROCESSED";
  }

  let dbType = String(notif.type || "SYSTEM").toUpperCase();

  const cleanRecipient = recipientEmail ? recipientEmail.toLowerCase().trim() : "admin";
  const cleanSender = senderEmail ? senderEmail.toLowerCase().trim() : "";

  const payload: any = {
    id: notif.id || `notif_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    recipient: cleanRecipient,
    sender_email: cleanSender,
    type: dbType,
    title: notif.title || "Notification",
    message: notif.message || "",
    status: dbStatus,
    created_at: notif.createdAt || notif.created_at || Date.now(),

    // Legacy field compatibility
    target_uid: isTargetAdmin ? "admin" : targetUid || cleanRecipient,
    user_uid: notif.userUid || notif.userId || cleanRecipient,
    user_id: notif.userId || notif.userUid || cleanRecipient,
    user_email: notif.userEmail || cleanSender,
    recipient_id: cleanRecipient,
    target_role: notif.targetRole || (isTargetAdmin ? "admin" : "student"),
    target_level: notif.targetLevel || null,
    is_read: dbStatus === "READ" || dbStatus === "PROCESSED",
    transaction_id: notif.transactionId || null,
    date_formatted: notif.dateFormatted || notif.date_formatted || new Date().toLocaleDateString("fr-FR"),
  };

  try {
    let { error } = await supabase.from("notifications").upsert(payload);

    if (error && error.code === "PGRST204") {
      const strictPayload = {
        id: payload.id,
        recipient: payload.recipient,
        sender_email: payload.sender_email,
        type: payload.type,
        title: payload.title,
        message: payload.message,
        status: payload.status,
        created_at: payload.created_at,
      };
      const retryRes = await supabase.from("notifications").upsert(strictPayload);
      if (retryRes.error) {
        console.warn("[Supabase] Strict notification retry notice:", retryRes.error);
      }
    } else if (error) {
      console.warn("[Supabase] Notice saving notification to table:", error.message || error);
    }
  } catch (err) {
    console.warn("[Supabase] Exception saving notification:", err);
  }
}

export async function markAdminNotificationAsProcessed(
  studentEmailOrUid: string,
  type?: string
): Promise<void> {
  if (!supabase || !studentEmailOrUid) return;
  try {
    const target = studentEmailOrUid.toLowerCase().trim();

    const { error } = await supabase
      .from("notifications")
      .update({ status: "PROCESSED", is_read: true })
      .eq("recipient", "admin")
      .or(`sender_email.eq.${target},user_email.eq.${target},user_id.eq.${studentEmailOrUid},user_uid.eq.${studentEmailOrUid}`);
    
    if (error) {
      console.warn("[Supabase] Notice marking admin notification as processed:", error);
    }
  } catch (err) {
    console.error("[Supabase] Unexpected error marking admin notification as processed:", err);
  }
}

export async function fetchUserNotificationsSupabase(
  userEmailOrUid: string,
  isAdmin?: boolean,
  onlyUnread?: boolean
): Promise<UserNotification[]> {
  if (!supabase || !userEmailOrUid) return [];
  try {
    const cleanEmail = (userEmailOrUid || "").toLowerCase().trim();
    const userIsAdmin = isAdmin ?? (cleanEmail && ADMIN_EMAILS.map((e) => e.toLowerCase().trim()).includes(cleanEmail));

    let query = supabase
      .from("notifications")
      .select("*")
      .neq("status", "PROCESSED")
      .neq("status", "processed");

    if (onlyUnread) {
      query = query.or("status.eq.unread,status.eq.UNREAD,is_read.eq.false");
    }

    if (userIsAdmin) {
      query = query.or("recipient.eq.admin,target_role.eq.admin,target_role.eq.all");
    } else {
      const conditions: string[] = [];
      if (userEmailOrUid) {
        conditions.push(`user_id.eq.${userEmailOrUid}`);
        conditions.push(`user_uid.eq.${userEmailOrUid}`);
        conditions.push(`recipient_id.eq.${userEmailOrUid}`);
        conditions.push(`target_uid.eq.${userEmailOrUid}`);
        conditions.push(`recipient.eq.${userEmailOrUid}`);
      }
      if (cleanEmail && cleanEmail.includes("@")) {
        conditions.push(`recipient.eq.${cleanEmail}`);
        conditions.push(`user_email.eq.${cleanEmail}`);
      }
      conditions.push("target_role.eq.all");
      conditions.push("recipient.eq.all");

      query = query.or(conditions.join(","));
    }

    const { data, error } = await query.order("created_at", { ascending: false });

    let resultList: UserNotification[] = [];

    if (!error && data && data.length > 0) {
      resultList = data.map((d: any) => ({
        id: String(d.id),
        recipient: d.recipient || d.target_uid,
        sender_email: d.sender_email || d.user_email,
        targetUid: d.target_uid || d.recipient,
        target_uid: d.target_uid || d.recipient,
        userUid: d.user_uid || d.user_id || d.sender_email || d.recipient,
        userId: d.user_id || d.user_uid || d.sender_email || d.recipient,
        userName: d.user_name || d.sender_email || "Utilisateur",
        userEmail: d.sender_email || d.user_email || d.recipient,
        recipientId: d.recipient || d.recipient_id,
        title: d.title || "",
        message: d.message || "",
        type: d.type || "SYSTEM",
        status: d.status === "PROCESSED" || d.status === "processed"
          ? "PROCESSED"
          : (d.status === "READ" || d.status === "read" || d.is_read)
            ? "READ"
            : "UNREAD",
        createdAt: Number(d.created_at || Date.now()),
        dateFormatted: d.date_formatted || new Date(Number(d.created_at || Date.now())).toLocaleDateString("fr-FR"),
      }));
    }

    // Dynamic generation from class_change_requests & vip_payment_requests for student
    if (!userIsAdmin && userEmailOrUid) {
      try {
        const { data: clsData } = await supabase
          .from("class_change_requests")
          .select("*")
          .or(`student_uid.eq.${userEmailOrUid},user_uid.eq.${userEmailOrUid}${cleanEmail && cleanEmail.includes("@") ? `,student_email.eq.${cleanEmail}` : ""}`)
          .order("requested_at", { ascending: false });

        if (clsData && clsData.length > 0) {
          clsData.forEach((req: any) => {
            const statusStr = String(req.status || "pending").toUpperCase();
            const reqId = req.id || `cls_${req.requested_at}`;
            const targetClass = req.requested_level || req.requested_class || "supérieure";
            const dateTs = Number(req.updated_at || req.requested_at || req.created_at || Date.now());

            if (statusStr === "APPROVED" || statusStr === "VALIDATED") {
              resultList.push({
                id: `dyn_cls_appr_${reqId}`,
                userUid: userEmailOrUid,
                userId: userEmailOrUid,
                title: "🎓 Votre passage en classe supérieure a été validé !",
                message: `Félicitations ! Votre demande de passage en classe de ${targetClass} a été validée par la Direction. Vos cours et devoirs sont à jour.`,
                type: "class_approved",
                status: "UNREAD",
                createdAt: dateTs,
                dateFormatted: new Date(dateTs).toLocaleDateString("fr-FR"),
              });
            } else if (statusStr === "REJECTED") {
              resultList.push({
                id: `dyn_cls_rej_${reqId}`,
                userUid: userEmailOrUid,
                userId: userEmailOrUid,
                title: "❌ Demande de changement de classe non validée",
                message: `Votre demande pour passer en classe de ${targetClass} n'a pas été acceptée par l'administration.${req.reason ? ` Motif : "${req.reason}"` : ""}`,
                type: "class_rejected",
                status: "UNREAD",
                createdAt: dateTs,
                dateFormatted: new Date(dateTs).toLocaleDateString("fr-FR"),
              });
            }
          });
        }
      } catch {}

      try {
        const { data: vipData } = await supabase
          .from("vip_payment_requests")
          .select("*")
          .or(`student_uid.eq.${userEmailOrUid},user_uid.eq.${userEmailOrUid}`)
          .order("requested_at", { ascending: false });

        if (vipData && vipData.length > 0) {
          vipData.forEach((req: any) => {
            const statusStr = String(req.status || "pending").toUpperCase();
            const reqId = req.id || `vip_${req.requested_at}`;
            const planLabel = req.plan_duration || req.plan_id || "Pass VIP";
            const dateTs = Number(req.updated_at || req.requested_at || req.created_at || Date.now());

            if (statusStr === "APPROVED" || statusStr === "VALIDATED") {
              resultList.push({
                id: `dyn_vip_appr_${reqId}`,
                userUid: userEmailOrUid,
                userId: userEmailOrUid,
                title: "👑 Votre accès VIP est activé !",
                message: `Félicitations ! Votre paiement pour le ${planLabel} a été validé avec succès par la Direction.`,
                type: "vip_approved",
                status: "UNREAD",
                createdAt: dateTs,
                dateFormatted: new Date(dateTs).toLocaleDateString("fr-FR"),
              });
            } else if (statusStr === "REJECTED") {
              resultList.push({
                id: `dyn_vip_rej_${reqId}`,
                userUid: userEmailOrUid,
                userId: userEmailOrUid,
                title: "❌ Paiement Pass VIP non validé",
                message: `Votre demande de Pass VIP n'a pas été acceptée.${req.rejection_reason ? ` Motif : "${req.rejection_reason}"` : ""}`,
                type: "vip_rejected",
                status: "UNREAD",
                createdAt: dateTs,
                dateFormatted: new Date(dateTs).toLocaleDateString("fr-FR"),
              });
            }
          });
        }
      } catch {}
    }

    const map = new Map<string, UserNotification>();
    resultList.forEach((n) => map.set(n.id, n));
    return Array.from(map.values()).sort((a, b) => b.createdAt - a.createdAt);
  } catch (err) {
    console.error("[Supabase] Unexpected error fetching user notifications:", err);
    return [];
  }
}

export async function fetchAllNotificationsSupabase(): Promise<UserNotification[]> {
  if (!supabase) return [];
  try {
    const { data, error } = await supabase
      .from("notifications")
      .select("*")
      .neq("status", "PROCESSED")
      .neq("status", "processed")
      .order("created_at", { ascending: false });

    if (error) {
      logSupabaseError("toutes les notifications (table 'notifications')", error);
      return [];
    }
    if (!data) return [];

    return data.map((d: any) => ({
      id: d.id,
      recipient: d.recipient || d.target_uid,
      sender_email: d.sender_email || d.user_email,
      targetUid: d.target_uid || d.recipient,
      target_uid: d.target_uid || d.recipient,
      userUid: d.user_uid || d.user_id || d.sender_email || d.recipient,
      userId: d.user_id || d.user_uid || d.sender_email || d.recipient,
      userName: d.user_name || d.sender_email || "Utilisateur",
      userEmail: d.sender_email || d.user_email || d.recipient,
      recipientId: d.recipient || d.recipient_id,
      title: d.title || "",
      message: d.message || "",
      type: d.type || "SYSTEM",
      status: d.status === "PROCESSED" || d.status === "processed"
        ? "PROCESSED"
        : (d.status === "READ" || d.status === "read" || d.is_read)
          ? "READ"
          : "UNREAD",
      createdAt: Number(d.created_at || Date.now()),
      dateFormatted: d.date_formatted || new Date(Number(d.created_at || Date.now())).toLocaleDateString("fr-FR"),
    }));
  } catch (err) {
    console.error("[Supabase] Unexpected error fetching all notifications:", err);
    return [];
  }
}

export async function deleteNotificationFromSupabase(notifId: string, _userUid?: string): Promise<void> {
  if (!supabase || !notifId) return;
  try {
    const { error } = await supabase
      .from("notifications")
      .delete()
      .eq("id", notifId);
    if (error) {
      console.error("[Supabase] Error deleting notification:", error);
    }
  } catch (err) {
    console.error("[Supabase] Unexpected error deleting notification:", err);
  }
}

export async function clearAllNotificationsFromSupabase(targetUid?: string, isAdmin?: boolean): Promise<void> {
  if (!supabase) return;
  try {
    const { data: { user } } = await supabase.auth.getUser();
    const effectiveId = targetUid || user?.id;
    if (!effectiveId) return;

    let query = supabase.from("notifications").delete();
    if (isAdmin || effectiveId === "admin") {
      query = query.or(`target_uid.eq.admin,target_uid.eq.${effectiveId}`);
    } else {
      query = query.eq("target_uid", effectiveId);
    }
    const { error } = await query;
    if (error) {
      console.error("[Supabase] Error clearing notifications:", error);
    }
  } catch (err) {
    console.error("[Supabase] Unexpected error clearing notifications:", err);
  }
}

// Marquer comme lu dans Supabase pour une notification individuelle
export async function markNotificationAsReadInSupabase(notifId: string): Promise<void> {
  if (!supabase || !notifId) return;
  try {
    const { error } = await supabase
      .from('notifications')
      .update({ is_read: true, status: 'READ' })
      .eq('id', notifId);

    if (error) {
      console.warn("[Supabase] Error marking notification as read:", error);
    }
  } catch (err) {
    console.error("[Supabase] Unexpected error marking notification as read:", err);
  }
}

// Marquer toutes les notifications comme lues dans Supabase
export async function markAllNotificationsAsReadInSupabase(userEmailOrUid?: string, isAdmin?: boolean): Promise<void> {
  if (!supabase) return;
  try {
    const { data: { user } } = await supabase.auth.getUser();
    const cleanEmail = (userEmailOrUid || user?.email || "").toLowerCase().trim();
    if (!cleanEmail) return;

    let query = supabase.from('notifications').update({ is_read: true, status: 'READ' });
    if (isAdmin || cleanEmail === "admin") {
      query = query.eq("recipient", "admin");
    } else {
      query = query.eq("recipient", cleanEmail);
    }
    const { error } = await query;
    if (error) {
      console.warn("[Supabase] Error marking all notifications as read:", error);
    }
  } catch (err) {
    console.error("[Supabase] Unexpected error marking all notifications as read:", err);
  }
}

export function subscribeToUserNotificationsSupabase(
  userEmailOrUid: string,
  onUpdate: (notifs: UserNotification[]) => void,
  isAdmin?: boolean
): () => void {
  if (!supabase || !userEmailOrUid) return () => {};

  fetchUserNotificationsSupabase(userEmailOrUid, isAdmin).then((list) => {
    onUpdate(list);
  });

  const cleanEmail = userEmailOrUid.toLowerCase().trim();
  const filterStr = isAdmin ? "recipient=eq.admin" : cleanEmail.includes("@") ? `recipient=eq.${cleanEmail}` : undefined;
  const channelName = `user_notifs_${isAdmin ? "admin" : cleanEmail.replace(/[^a-zA-Z0-9]/g, "_")}_${Date.now()}`;

  const channel = supabase
    .channel(channelName)
    .on(
      "postgres_changes",
      {
        event: "*",
        schema: "public",
        table: "notifications",
        filter: filterStr,
      },
      () => {
        fetchUserNotificationsSupabase(userEmailOrUid, isAdmin).then((list) => onUpdate(list));
      }
    )
    .subscribe();

  return () => {
    if (supabase && channel) {
      try {
        supabase.removeChannel(channel);
      } catch (err) {
        console.warn("[Supabase] Remove channel error:", err);
      }
    }
  };
}

export function subscribeToAllNotificationsSupabase(
  onUpdate: (notifs: UserNotification[]) => void
): () => void {
  if (!supabase) return () => {};

  fetchAllNotificationsSupabase().then((list) => {
    onUpdate(list);
  });

  const channelName = `all_notifs_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
  const channel = supabase
    .channel(channelName)
    .on(
      "postgres_changes",
      { event: "*", schema: "public", table: "notifications" },
      () => {
        fetchAllNotificationsSupabase().then((list) => onUpdate(list));
      }
    )
    .subscribe();

  return () => {
    if (supabase && channel) {
      try {
        supabase.removeChannel(channel);
      } catch (err) {
        console.warn("[Supabase] Remove channel error:", err);
      }
    }
  };
}

// ============================================================================
// 11. APP CONFIG, LOGO, CAISSE & GLOBAL PUBLISHING WORKFLOW
// ============================================================================

export interface AppConfigRecord {
  logoUrl?: string;
  officialSignature?: string;
  faviconUrl?: string;
  pwaIcon192Url?: string;
  pwaIcon512Url?: string;
  appName?: string;
  globalVersion?: string;
  latest_version?: string;
  apk_url?: string;
  message?: string;
  heroTitle?: string;
  heroSubtitle?: string;
  announcementText?: string;
  supportPhone?: string;
  vipPriceFCFA?: number;
  publishedAt?: number;
  publishedBy?: string;
  updatedAt?: number;
  [key: string]: any;
}

export async function getAppConfigFromSupabase(): Promise<AppConfigRecord | null> {
  if (!supabase) return null;

  let mergedConfig: AppConfigRecord = {
    appName: "Génie Mentor Académie",
    latest_version: APP_VERSION,
    globalVersion: APP_VERSION,
    apk_url: "",
    message: "Une nouvelle version de l'application Génie Mentor Académie est disponible avec de superbes améliorations.",
    updatedAt: Date.now(),
  };

  let hasFoundAny = false;

  // 1. Primary global system configuration from 'system_settings'
  try {
    const { data: sysData, error: sysError } = await supabase
      .from("system_settings")
      .select("*");

    if (!sysError && sysData && Array.isArray(sysData) && sysData.length > 0) {
      hasFoundAny = true;
      for (const row of sysData) {
        const v =
          row.latest_version ||
          row.app_version ||
          row.version ||
          row.global_version ||
          (row.key === "app_version" || row.key === "version" || row.key === "latest_version" ? row.value : null) ||
          (row.value && typeof row.value === "object" ? row.value.latest_version || row.value.app_version || row.value.version : null);

        if (v) {
          mergedConfig.latest_version = String(v).trim();
          mergedConfig.globalVersion = String(v).trim();
        }

        const apk =
          row.apk_url ||
          row.apk_link ||
          (row.key === "apk_url" ? row.value : null) ||
          (row.value && typeof row.value === "object" ? row.value.apk_url || row.value.apk_link : null);
        if (apk) mergedConfig.apk_url = String(apk).trim();

        const msg =
          row.message ||
          row.release_notes ||
          row.description ||
          (row.key === "message" || row.key === "release_notes" ? row.value : null) ||
          (row.value && typeof row.value === "object" ? row.value.message || row.value.release_notes : null);
        if (msg) mergedConfig.message = String(msg);

        if (row.logo_url) mergedConfig.logoUrl = row.logo_url;
        if (row.official_signature) mergedConfig.officialSignature = row.official_signature;
        if (row.favicon_url) mergedConfig.faviconUrl = row.favicon_url;
        if (row.pwa_icon_192_url || row.pwa_icon_url) mergedConfig.pwaIcon192Url = row.pwa_icon_192_url || row.pwa_icon_url;
        if (row.pwa_icon_512_url) mergedConfig.pwaIcon512Url = row.pwa_icon_512_url;
        if (row.app_name) mergedConfig.appName = row.app_name;
        if (row.updated_at) mergedConfig.updatedAt = Number(row.updated_at);
      }
    }
  } catch (err) {
    // ignore if table doesn't exist yet
  }

  // 2. Global settings from 'app_settings'
  try {
    const { data: settingsData, error: settingsError } = await supabase
      .from("app_settings")
      .select("*")
      .maybeSingle();

    if (!settingsError && settingsData) {
      hasFoundAny = true;
      const v = settingsData.latest_version || settingsData.version || settingsData.global_version || settingsData.app_version;
      if (v) {
        mergedConfig.latest_version = String(v).trim();
        mergedConfig.globalVersion = String(v).trim();
      }
      if (settingsData.apk_url || settingsData.apk_link) {
        mergedConfig.apk_url = settingsData.apk_url || settingsData.apk_link;
      }
      if (settingsData.message || settingsData.release_notes || settingsData.description) {
        mergedConfig.message = settingsData.message || settingsData.release_notes || settingsData.description;
      }
      if (settingsData.logo_url) mergedConfig.logoUrl = settingsData.logo_url;
      if (settingsData.official_signature) mergedConfig.officialSignature = settingsData.official_signature;
      if (settingsData.favicon_url) mergedConfig.faviconUrl = settingsData.favicon_url;
      if (settingsData.pwa_icon_192_url || settingsData.pwa_icon_url) mergedConfig.pwaIcon192Url = settingsData.pwa_icon_192_url || settingsData.pwa_icon_url;
      if (settingsData.pwa_icon_512_url) mergedConfig.pwaIcon512Url = settingsData.pwa_icon_512_url;
      if (settingsData.app_name) mergedConfig.appName = settingsData.app_name;
      if (settingsData.hero_title) mergedConfig.heroTitle = settingsData.hero_title;
      if (settingsData.hero_subtitle) mergedConfig.heroSubtitle = settingsData.hero_subtitle;
      if (settingsData.announcement_text) mergedConfig.announcementText = settingsData.announcement_text;
      if (settingsData.support_phone) mergedConfig.supportPhone = settingsData.support_phone;
      if (settingsData.vip_price_fcfa) mergedConfig.vipPriceFCFA = settingsData.vip_price_fcfa;
      if (settingsData.updated_at) mergedConfig.updatedAt = Number(settingsData.updated_at);
    }
  } catch (err) {
    // ignore
  }

  // 3. Secondary config from 'app_config' table (if created in Supabase)
  try {
    const { data, error } = await supabase
      .from("app_config")
      .select("*")
      .eq("id", "main")
      .maybeSingle();

    if (!error && data) {
      hasFoundAny = true;
      mergedConfig = {
        ...mergedConfig,
        logoUrl: data.logo_url || mergedConfig.logoUrl,
        officialSignature: data.official_signature || mergedConfig.officialSignature,
        faviconUrl: data.favicon_url || mergedConfig.faviconUrl,
        pwaIcon192Url: data.pwa_icon_192_url || data.pwa_icon_url || mergedConfig.pwaIcon192Url,
        pwaIcon512Url: data.pwa_icon_512_url || mergedConfig.pwaIcon512Url,
        appName: data.app_name || mergedConfig.appName,
        globalVersion: data.global_version || data.app_version || data.latest_version || mergedConfig.globalVersion,
        latest_version: data.latest_version || data.global_version || data.app_version || mergedConfig.latest_version,
        apk_url: data.apk_url || mergedConfig.apk_url,
        message: data.message || mergedConfig.message,
        heroTitle: data.hero_title || mergedConfig.heroTitle,
        heroSubtitle: data.hero_subtitle || mergedConfig.heroSubtitle,
        announcementText: data.announcement_text || mergedConfig.announcementText,
        supportPhone: data.support_phone || mergedConfig.supportPhone,
        vipPriceFCFA: data.vip_price_fcfa || mergedConfig.vipPriceFCFA,
        publishedAt: Number(data.published_at || data.updated_at || Date.now()),
        publishedBy: data.published_by || "Admin",
        updatedAt: Number(data.updated_at || Date.now()),
      };
    }
  } catch (err) {
    // ignore if table doesn't exist yet
  }

  // 4. Fallback from 'app_versions'
  try {
    const { data: versionsData, error: versionsError } = await supabase
      .from("app_versions")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    if (!versionsError && versionsData) {
      hasFoundAny = true;
      const v = versionsData.version || versionsData.latest_version;
      if (v) {
        mergedConfig.latest_version = String(v).trim();
        mergedConfig.globalVersion = String(v).trim();
      }
      if (versionsData.apk_url || versionsData.apk_link) {
        mergedConfig.apk_url = versionsData.apk_url || versionsData.apk_link;
      }
      if (versionsData.message || versionsData.release_notes || versionsData.description) {
        mergedConfig.message = versionsData.message || versionsData.release_notes || versionsData.description;
      }
    }
  } catch {
    // ignore
  }

  return hasFoundAny ? mergedConfig : null;
}

export async function saveAppConfigToSupabase(config: AppConfigRecord): Promise<void> {
  if (!supabase) return;

  const versionString = config.latest_version || config.globalVersion || null;
  const apkUrlString = config.apk_url || null;
  const releaseMessage = config.message || null;
  const now = Date.now();

  // Also persist in localStorage for instant offline access and cross-tab consistency
  try {
    const cachedRaw = localStorage.getItem("savoir_plus_app_config_v1");
    const previous = cachedRaw ? JSON.parse(cachedRaw) : {};
    const updatedLocal = { ...previous, ...config, updatedAt: now };
    localStorage.setItem("savoir_plus_app_config_v1", JSON.stringify(updatedLocal));
  } catch {
    // ignore
  }

  // 1. Save to 'system_settings' (global system table)
  try {
    const sysPayload: Record<string, any> = {
      latest_version: versionString,
      version: versionString,
      app_version: versionString,
      apk_url: apkUrlString,
      message: releaseMessage,
      app_name: config.appName || "Génie Mentor Académie",
      updated_at: now,
    };
    if (config.logoUrl) sysPayload.logo_url = config.logoUrl;
    if (config.officialSignature) sysPayload.official_signature = config.officialSignature;
    if (config.faviconUrl) sysPayload.favicon_url = config.faviconUrl;
    if (config.pwaIcon192Url) {
      sysPayload.pwa_icon_192_url = config.pwaIcon192Url;
      sysPayload.pwa_icon_url = config.pwaIcon192Url;
    }
    if (config.pwaIcon512Url) {
      sysPayload.pwa_icon_512_url = config.pwaIcon512Url;
      if (!sysPayload.logo_url) sysPayload.logo_url = config.pwaIcon512Url;
    }

    // Récupérer l'ID de la ligne existante pour cibler l'UPDATE (supporte id = 1 ou id = 'main')
    const { data: existingRows } = await supabase
      .from("system_settings")
      .select("id")
      .limit(1);

    let saved = false;
    if (existingRows && existingRows.length > 0) {
      const existingId = existingRows[0].id;
      sysPayload.id = existingId;
      const { error: updErr } = await supabase
        .from("system_settings")
        .update(sysPayload)
        .eq("id", existingId);

      if (!updErr) saved = true;
    }

    if (!saved) {
      sysPayload.id = 1;
      const { error: ups1Err } = await supabase.from("system_settings").upsert(sysPayload);
      if (!ups1Err) {
        saved = true;
      } else {
        sysPayload.id = "main";
        const { error: upsMainErr } = await supabase.from("system_settings").upsert(sysPayload);
        if (!upsMainErr) saved = true;
      }
    }
  } catch (err) {
    console.warn("[Supabase] Save to system_settings notice:", err);
  }

  // 2. Save to 'app_settings' (standard table present in Supabase)
  try {
    const fullPayload: Record<string, any> = {
      id: "main",
      latest_version: versionString,
      version: versionString,
      app_version: versionString,
      apk_url: apkUrlString,
      apk_link: apkUrlString,
      message: releaseMessage,
      release_notes: releaseMessage,
      app_name: config.appName || "Génie Mentor Académie",
      updated_at: now,
    };
    if (config.logoUrl) fullPayload.logo_url = config.logoUrl;
    if (config.officialSignature) fullPayload.official_signature = config.officialSignature;
    if (config.faviconUrl) fullPayload.favicon_url = config.faviconUrl;
    if (config.pwaIcon192Url) fullPayload.pwa_icon_192_url = config.pwaIcon192Url;
    if (config.pwaIcon512Url) fullPayload.pwa_icon_512_url = config.pwaIcon512Url;
    if (config.heroTitle) fullPayload.hero_title = config.heroTitle;
    if (config.heroSubtitle) fullPayload.hero_subtitle = config.heroSubtitle;
    if (config.announcementText) fullPayload.announcement_text = config.announcementText;
    if (config.supportPhone) fullPayload.support_phone = config.supportPhone;
    if (config.vipPriceFCFA) fullPayload.vip_price_fcfa = config.vipPriceFCFA;

    const { error: settingsErr } = await supabase.from("app_settings").upsert(fullPayload);
    if (settingsErr) {
      // If error was due to unknown optional columns, fallback to base columns
      await supabase.from("app_settings").upsert({
        id: "main",
        latest_version: versionString,
        version: versionString,
        apk_url: apkUrlString,
        message: releaseMessage,
        app_name: config.appName || "Génie Mentor Académie",
        updated_at: now,
      });
    }
  } catch (err) {
    console.warn("[Supabase] Save to app_settings notice:", err);
  }

  // 3. Save to 'app_versions' (history table)
  if (versionString) {
    try {
      await supabase.from("app_versions").upsert({
        id: `ver_${versionString.replace(/[^a-zA-Z0-9_-]/g, "_")}`,
        version: versionString,
        latest_version: versionString,
        apk_url: apkUrlString,
        message: releaseMessage,
        is_latest: true,
        updated_at: now,
      });
    } catch (err) {
      console.warn("[Supabase] Save to app_versions notice:", err);
    }
  }

  // 4. Gracefully attempt save to 'app_config' if the table exists
  try {
    const { error } = await supabase.from("app_config").upsert({
      id: "main",
      logo_url: config.logoUrl || null,
      official_signature: config.officialSignature || null,
      app_name: config.appName || "Génie Mentor Académie",
      global_version: versionString,
      latest_version: versionString,
      apk_url: apkUrlString,
      message: releaseMessage,
      hero_title: config.heroTitle || null,
      hero_subtitle: config.heroSubtitle || null,
      announcement_text: config.announcementText || null,
      support_phone: config.supportPhone || null,
      vip_price_fcfa: config.vipPriceFCFA || null,
      published_at: config.publishedAt || now,
      published_by: config.publishedBy || "Admin",
      updated_at: now,
    });
    if (error && error.code !== "PGRST205") {
      console.warn("[Supabase] Notice saving to app_config table:", error.message || error);
    }
  } catch (err) {
    // Non-blocking fallback
  }
}

export async function saveLogoToSupabase(logoUrl: string): Promise<void> {
  return saveAppConfigToSupabase({ logoUrl });
}

export async function saveAdminPasswordToSupabase(password: string): Promise<void> {
  if (!supabase) return;
  try {
    await supabase.from("system_settings").upsert({
      id: "admin_security",
      app_name: password,
      updated_at: Date.now(),
    });
  } catch {
    // ignore
  }
  try {
    await supabase.from("app_settings").upsert({
      id: "admin_security",
      app_name: password,
      updated_at: Date.now(),
    });
  } catch {
    // ignore
  }
  try {
    await supabase.from("app_config").upsert({
      id: "admin_security",
      app_name: password,
      updated_at: Date.now(),
    });
  } catch {
    // ignore
  }
}

export const subscribeToAllClassChangeRequestsSupabase = subscribeToClassChangeRequestsSupabase;
export const subscribeToAllHomeworksSupabase = subscribeToHomeworkSubmissionsSupabase;
export const logAdminActionToFirebase = (
  adminEmail: string,
  actionType: string,
  details: string,
  target?: string
) => logAdminActionToSupabase(adminEmail, actionType, details, target);

export function subscribeToAppConfigSupabase(
  onUpdate: (config: AppConfigRecord) => void
): () => void {
  if (!supabase) return () => {};

  const handleConfig = (cfg: AppConfigRecord | null) => {
    if (!cfg) return;
    if (cfg.logoUrl && typeof window !== "undefined") {
      try {
        localStorage.setItem("savoir_app_logo_data", cfg.logoUrl);
        window.dispatchEvent(new CustomEvent("savoir_logo_updated", { detail: cfg.logoUrl }));
      } catch (e) {
        // ignore
      }
    }
    onUpdate(cfg);
  };

  getAppConfigFromSupabase().then((cfg) => {
    handleConfig(cfg);
  });

  const channelName = `app_config_live_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
  const channel = supabase
    .channel(channelName)
    .on(
      "postgres_changes",
      { event: "*", schema: "public", table: "system_settings" },
      () => {
        getAppConfigFromSupabase().then((cfg) => {
          handleConfig(cfg);
        });
      }
    )
    .on(
      "postgres_changes",
      { event: "*", schema: "public", table: "app_settings" },
      () => {
        getAppConfigFromSupabase().then((cfg) => {
          handleConfig(cfg);
        });
      }
    )
    .on(
      "postgres_changes",
      { event: "*", schema: "public", table: "app_config" },
      () => {
        getAppConfigFromSupabase().then((cfg) => {
          handleConfig(cfg);
        });
      }
    )
    .on(
      "postgres_changes",
      { event: "*", schema: "public", table: "app_versions" },
      () => {
        getAppConfigFromSupabase().then((cfg) => {
          handleConfig(cfg);
        });
      }
    )
    .subscribe();

  return () => {
    if (supabase && channel) {
      try {
        supabase.removeChannel(channel);
      } catch (err) {
        console.warn("[Supabase] Remove channel error:", err);
      }
    }
  };
}

export async function saveCaisseTransactionToSupabase(tx: CaisseTransaction): Promise<void> {
  if (!supabase) return;
  try {
    const { error } = await supabase.from("caisse_transactions").upsert({
      id: tx.id,
      student_name: tx.studentName,
      student_matricule: tx.studentMatricule || null,
      phone: tx.phone,
      amount: tx.amount,
      motif: tx.motif,
      payment_method: tx.paymentMethod,
      note: tx.note || null,
      admin_name: tx.adminName || "Admin",
      created_at: tx.createdAt || Date.now(),
    });
    if (error) {
      console.error("[Supabase] Error saving caisse transaction:", error);
      throw error;
    }
  } catch (err) {
    console.error("[Supabase] Unexpected error saving caisse transaction:", err);
  }
}

export async function fetchCaisseTransactionsSupabase(): Promise<CaisseTransaction[]> {
  if (!supabase) return [];
  try {
    const { data, error } = await supabase
      .from("caisse_transactions")
      .select("*")
      .order("created_at", { ascending: false });

    if (error) {
      logSupabaseError("caisse (table 'caisse_transactions')", error);
      return [];
    }
    if (!data) return [];

    return data.map((d: any) => ({
      id: d.id,
      studentName: d.student_name,
      studentMatricule: d.student_matricule || undefined,
      phone: d.phone,
      amount: Number(d.amount),
      motif: d.motif,
      paymentMethod: d.payment_method,
      note: d.note || undefined,
      adminName: d.admin_name,
      createdAt: Number(d.created_at || Date.now()),
      dateFormatted: new Date(Number(d.created_at || Date.now())).toLocaleDateString("fr-FR"),
    }));
  } catch (err) {
    console.error("[Supabase] Unexpected error fetching caisse transactions:", err);
    return [];
  }
}

export async function deleteCaisseTransactionFromSupabase(txId: string): Promise<void> {
  if (!supabase) return;
  try {
    const { error } = await supabase.from("caisse_transactions").delete().eq("id", txId);
    if (error) {
      logSupabaseError("deleting caisse transaction", error);
    }
  } catch (err) {
    logSupabaseError("unexpected error deleting caisse transaction", err);
  }
}

export async function deleteAllCaisseTransactionsFromSupabase(): Promise<void> {
  if (!supabase) return;
  try {
    const { error } = await supabase.from("caisse_transactions").delete().neq("id", "none");
    if (error) {
      logSupabaseError("clearing all caisse transactions", error);
    }
  } catch (err) {
    logSupabaseError("unexpected error clearing all caisse transactions", err);
  }
}

export async function deleteVIPPaymentRequestFromSupabase(reqId: string): Promise<void> {
  if (!supabase) return;
  try {
    const { error } = await supabase.from("vip_payment_requests").delete().eq("id", reqId);
    if (error) {
      logSupabaseError("deleting vip payment request", error);
    }
  } catch (err) {
    logSupabaseError("unexpected error deleting vip payment request", err);
  }
}

export async function saveCaisseResetTimestampToSupabase(timestamp: number): Promise<void> {
  if (!supabase) return;
  try {
    const { error } = await supabase.from("app_config").upsert({
      id: "caisse_config",
      key: "caisse_reset_timestamp",
      value: String(timestamp),
      reset_at: timestamp,
      updated_at: Date.now(),
    });
    if (error) {
      logSupabaseError("saving caisse reset timestamp", error);
    }
  } catch (err) {
    logSupabaseError("unexpected error saving caisse reset timestamp", err);
  }
}

export async function getCaisseResetTimestampFromSupabase(): Promise<number> {
  if (!supabase) return 0;
  try {
    const { data, error } = await supabase
      .from("app_config")
      .select("*")
      .eq("id", "caisse_config")
      .single();

    if (!error && data) {
      return Number(data.reset_at || data.value || 0);
    }
  } catch (err) {
    logSupabaseError("fetching caisse reset timestamp", err);
  }
  return 0;
}

export async function saveAuditLogToSupabase(log: AdminAuditLog): Promise<void> {
  if (!supabase) return;
  try {
    const payload = {
      id: log.id || `audit_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      admin_email: log.adminEmail || "massperpendiculaire@gmail.com",
      admin_name: log.adminName || "Massaw Seck (Admin)",
      action_type: log.actionType,
      target: log.target || null,
      details: log.details,
      created_at: log.createdAt || Date.now(),
      date_formatted: log.dateFormatted || new Date().toLocaleString("fr-FR"),
    };
    const { error } = await supabase.from("admin_audit_logs").upsert(payload);
    if (error && error.code !== "PGRST205") {
      logSupabaseError("saving audit log to admin_audit_logs", error);
    }
  } catch (err) {
    console.warn("[Supabase] Audit log fallback:", err);
  }
}

export async function fetchAuditLogsSupabase(): Promise<AdminAuditLog[]> {
  if (!supabase) return [];
  try {
    const { data, error } = await supabase
      .from("admin_audit_logs")
      .select("*")
      .order("created_at", { ascending: false });

    if (error) {
      logSupabaseError("fetching audit logs from admin_audit_logs", error);
      return [];
    }
    if (!data) return [];

    return data.map((d: any) => ({
      id: String(d.id),
      adminEmail: d.admin_email || "massperpendiculaire@gmail.com",
      adminName: d.admin_name || "Massaw Seck (Admin)",
      actionType: d.action_type || "ACTION_ADMIN",
      target: d.target || undefined,
      details: d.details || "",
      createdAt: Number(d.created_at || Date.now()),
      dateFormatted: d.date_formatted || new Date(Number(d.created_at || Date.now())).toLocaleString("fr-FR"),
    }));
  } catch (err) {
    logSupabaseError("unexpected error fetching audit logs", err);
    return [];
  }
}

export async function logAdminActionToSupabase(
  adminEmail: string,
  actionType: string,
  details: string,
  target?: string
): Promise<void> {
  const now = Date.now();
  const dateFormatted = new Date(now).toLocaleString("fr-FR");
  await saveAuditLogToSupabase({
    id: `audit_${now}_${Math.random().toString(36).substring(2, 7)}`,
    adminEmail: adminEmail || "massperpendiculaire@gmail.com",
    adminName: "Massaw Seck (Admin)",
    actionType,
    target,
    details,
    createdAt: now,
    dateFormatted,
  });
}

export function subscribeToCaisseTransactionsSupabase(
  onUpdate: (txs: CaisseTransaction[]) => void
): () => void {
  if (!supabase) return () => {};

  fetchCaisseTransactionsSupabase().then((list) => {
    onUpdate(list);
  });

  const channelName = `caisse_txs_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
  const channel = supabase
    .channel(channelName)
    .on(
      "postgres_changes",
      { event: "*", schema: "public", table: "caisse_transactions" },
      () => {
        fetchCaisseTransactionsSupabase().then((list) => onUpdate(list));
      }
    )
    .subscribe();

  return () => {
    if (supabase && channel) {
      try {
        supabase.removeChannel(channel);
      } catch (err) {
        console.warn("[Supabase] Remove channel error:", err);
      }
    }
  };
}

// ============================================================================
// 12. GLOBAL PUBLISH & MASS SYNCHRONIZATION WORKFLOW
// ============================================================================

export async function publishGlobalPlatformUpdateSupabase(snapshot: {
  courses?: Course[];
  assets?: Asset[];
  quizzes?: Quiz[];
  students?: StudentRecord[];
  homeworks?: HomeworkSubmission[];
  appConfig?: AppConfigRecord;
  publishedBy?: string;
}): Promise<{ success: boolean; version: string; count: number; timestamp: number }> {
  if (!supabase) {
    return { success: false, version: `v${APP_VERSION}`, count: 0, timestamp: Date.now() };
  }

  let totalItems = 0;
  const now = Date.now();
  const newVersion = `v${new Date().toISOString().slice(0, 10).replace(/-/g, ".")}.${Math.floor(now / 1000) % 10000}`;

  try {
    // 1. Sync courses
    if (snapshot.courses && snapshot.courses.length > 0) {
      for (const course of snapshot.courses) {
        await saveCourseToSupabase(course);
        totalItems++;
      }
    }

    // 2. Sync assets
    if (snapshot.assets && snapshot.assets.length > 0) {
      for (const asset of snapshot.assets) {
        await saveAssetToSupabase(asset);
        totalItems++;
      }
    }

    // 3. Sync quizzes
    if (snapshot.quizzes && snapshot.quizzes.length > 0) {
      for (const quiz of snapshot.quizzes) {
        await saveQuizToSupabase(quiz);
        totalItems++;
      }
    }

    // 4. Update and Broadcast App Config
    const configToSave: AppConfigRecord = {
      ...(snapshot.appConfig || {}),
      globalVersion: newVersion,
      publishedAt: now,
      publishedBy: snapshot.publishedBy || "Massaw Seck (Admin)",
      updatedAt: now,
    };
    await saveAppConfigToSupabase(configToSave);

    // 5. Broadcast global notification for all users
    await saveNotificationToSupabase({
      id: "notif_global_update_" + now,
      userUid: "all",
      userId: "all",
      title: "🚀 Mise à Jour Globale de la Plateforme",
      message: `L'administration a publié une nouvelle version fixe (${newVersion}) des cours, exercices et quiz. Vos contenus sont parfaitement synchronisés.`,
      type: "general",
      status: "unread",
      createdAt: now,
      dateFormatted: `Aujourd'hui, ${new Date().toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}`,
    });

    // 6. Log admin action
    await logAdminActionToSupabase(
      snapshot.publishedBy || "massperpendiculaire@gmail.com",
      "PUBLISH_GLOBAL_UPDATE",
      `Publication de la mise à jour globale ${newVersion} (${totalItems} contenus synchronisés).`
    );

    return {
      success: true,
      version: newVersion,
      count: totalItems,
      timestamp: now,
    };
  } catch (err) {
    console.error("[Supabase] Global Publish Error:", err);
    return {
      success: false,
      version: newVersion,
      count: totalItems,
      timestamp: now,
    };
  }
}

export async function syncAllExistingDataToSupabase(data: {
  students?: StudentRecord[];
  courses?: Course[];
  assets?: Asset[];
  quizzes?: Quiz[];
  homeworks?: HomeworkSubmission[];
  vipRequests?: VIPPaymentRequest[];
  classRequests?: ClassChangeRequest[];
}): Promise<{ success: boolean; count: number }> {
  const res = await publishGlobalPlatformUpdateSupabase({
    courses: data.courses,
    assets: data.assets,
    quizzes: data.quizzes,
    students: data.students,
    homeworks: data.homeworks,
  });
  return { success: res.success, count: res.count };
}
