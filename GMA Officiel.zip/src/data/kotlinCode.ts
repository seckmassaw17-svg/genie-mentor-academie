import { KotlinCodeFile } from "../types";

export const KOTLIN_SOURCE_FILES: KotlinCodeFile[] = [
  {
    filename: "firebase-applet-config.json",
    packagePath: "root.config",
    description: "Fichier de configuration Firebase Applet (Web & Cloud Firestore Database ID)",
    code: `{
  "projectId": "thermal-concord-gt8c4",
  "appId": "1:499880703952:web:84d9d4b20abcdfd583ebd5",
  "apiKey": "AIzaSyAXB6v6HfBX9tom1n59TIikPnYiz3PC2Pw",
  "authDomain": "thermal-concord-gt8c4.firebaseapp.com",
  "firestoreDatabaseId": "ai-studio-remixsavoir-bdd988cd-6403-48f3-b7c5-7fc231d8ef96",
  "storageBucket": "thermal-concord-gt8c4.firebasestorage.app",
  "messagingSenderId": "499880703952",
  "measurementId": "",
  "recaptchaSiteKey": ""
}`
  },
  {
    filename: "google-services.json",
    packagePath: "app.google-services",
    description: "Configuration Firebase SDK pour application Android Native",
    code: `{
  "project_info": {
    "project_number": "499880703952",
    "project_id": "thermal-concord-gt8c4",
    "storage_bucket": "thermal-concord-gt8c4.firebasestorage.app"
  },
  "client": [
    {
      "client_info": {
        "mobilesdk_app_id": "1:499880703952:android:9d4b20abcdfd583ebd501",
        "android_client_info": {
          "package_name": "com.gma.education"
        }
      },
      "api_key": [
        {
          "current_key": "AIzaSyAXB6v6HfBX9tom1n59TIikPnYiz3PC2Pw"
        }
      ],
      "services": {
        "appinvite_service": {
          "other_platform_oauth_client": []
        }
      }
    }
  ],
  "configuration_version": "1"
}`
  },
  {
    filename: "firestore.rules",
    packagePath: "firebase.security",
    description: "Règles de sécurité Cloud Firestore (RBAC Admin & Propriétaire des données)",
    code: `rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    // Global Deny Catch-All
    match /{document=**} {
      allow read, write: if false;
    }

    function isSignedIn() {
      return request.auth != null;
    }

    function isOwner(userId) {
      return isSignedIn() && request.auth.uid == userId;
    }

    function isAdmin() {
      return isSignedIn() && (
        request.auth.token.email == "massaw.seck@unchk.edu.sn" ||
        request.auth.token.email == "massperpendiculaire@gmail.com" ||
        exists(/databases/$(database)/documents/users/$(request.auth.uid)) &&
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.isAdmin == true
      );
    }

    match /users/{userId} {
      allow get: if isSignedIn() && (isOwner(userId) || isAdmin());
      allow list: if isAdmin();
      allow create, update: if isSignedIn() && (isOwner(userId) || isAdmin());
      allow delete: if isAdmin();
    }

    match /courses/{courseId} {
      allow read: if isSignedIn();
      allow create, update, delete: if isSignedIn();
    }

    match /assets/{assetId} {
      allow read: if isSignedIn();
      allow create, update, delete: if isSignedIn();
    }

    match /quizzes/{quizId} {
      allow read: if isSignedIn();
      allow create, update, delete: if isSignedIn();
    }

    match /payment_requests/{requestId} {
      allow read, write, delete: if isSignedIn();
    }

    match /class_change_requests/{reqId} {
      allow read, write, delete: if isSignedIn();
    }

    match /notifications/{notifId} {
      allow read, write, delete: if isSignedIn();
    }
  }
}`
  },
  {
    filename: "Entity.kt",
    packagePath: "com.gma.education.data.local",
    description: "Modèles d'entités Room (CourseEntity, AssetEntity, QuizEntity)",
    code: `package com.gma.education.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "courses")
data class CourseEntity(
    @PrimaryKey val id: String,
    val title: String,
    val subject: String,
    val level: String,
    val chapter: String,
    val createdAt: Long
)

@Entity(tableName = "assets")
data class AssetEntity(
    @PrimaryKey val assetId: String,
    val parentId: String,
    val name: String,
    val type: String,
    val storagePath: String,
    val downloadUrl: String
)

@Entity(tableName = "quizzes")
data class QuizEntity(
    @PrimaryKey val id: String,
    val title: String,
    val subject: String,
    val level: String,
    val questionsJson: String
)
`
  },
  {
    filename: "GmaDao.kt",
    packagePath: "com.gma.education.data.local",
    description: "Interface DAO Room avec requêtes Flow et opérations hors-ligne",
    code: `package com.gma.education.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface GmaDao {
    @Query("SELECT * FROM courses WHERE level = :userLevel ORDER BY createdAt DESC")
    fun getCoursesByLevel(userLevel: String): Flow<List<CourseEntity>>

    @Query("SELECT * FROM assets WHERE parentId = :courseId")
    fun getAssetsForParent(courseId: String): Flow<List<AssetEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCourses(courses: List<CourseEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAssets(assets: List<AssetEntity>)

    @Query("DELETE FROM courses")
    suspend fun clearCourses()
    
    @Query("DELETE FROM assets")
    suspend fun clearAssets()
}
`
  },
  {
    filename: "SyncWorker.kt",
    packagePath: "com.gma.education.data.worker",
    description: "Worker en arrière-plan WorkManager pour la synchronisation Firestore vers Room",
    code: `package com.gma.education.data.worker

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.google.firebase.firestore.FirebaseFirestore
import com.gma.education.data.local.CourseEntity
import com.gma.education.data.local.GmaDao
import kotlinx.coroutines.tasks.await

class SyncWorker(
    appContext: Context,
    workerParams: WorkerParameters,
    private val dao: GmaDao
) : CoroutineWorker(appContext, workerParams) {
    override suspend fun doWork(): Result {
        val userLevel = inputData.getString("USER_LEVEL") ?: return Result.failure()
        val db = FirebaseFirestore.getInstance()
        return try {
            val snapshot = db.collection("courses").whereEqualTo("level", userLevel).get().await()
            val courses = snapshot.documents.mapNotNull { doc ->
                CourseEntity(
                    id = doc.id,
                    title = doc.getString("title") ?: "",
                    subject = doc.getString("subject") ?: "",
                    level = doc.getString("level") ?: "",
                    chapter = doc.getString("chapter") ?: "",
                    createdAt = doc.getLong("createdAt") ?: 0L
                )
            }
            dao.insertCourses(courses)
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}
`
  },
  {
    filename: "MainActivity.kt",
    packagePath: "com.gma.education",
    description: "Activité principale Android avec activation du FLAG_SECURE (anti-captures d'écran)",
    code: `package com.gma.education

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.gma.education.ui.GmaApp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Sécurité : empêche la capture et l'enregistrement d'écran des cours
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )
        
        setContent {
            GmaApp()
        }
    }
}
`
  },
  {
    filename: "GmaTheme.kt",
    packagePath: "com.gma.education.ui.theme",
    description: "Thème Material Design 3 (Bleu Nuit #1A237E et Fond Blanc #FFFFFF)",
    code: `package com.gma.education.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val NightBlue = Color(0xFF1A237E)
val WhiteBg = Color(0xFFFFFFFF)
val SecondaryGold = Color(0xFFFFB300)

private val LightColorScheme = lightColorScheme(
    primary = NightBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE8EAF6),
    secondary = SecondaryGold,
    background = WhiteBg,
    surface = WhiteBg
)

@Composable
fun GmaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = LightColorScheme,
        content = content
    )
}
`
  },
  {
    filename: "server.ts",
    packagePath: "backend.node",
    description: "Serveur Express Full-Stack TypeScript avec Proxy Gemini API (Tuteur IA, Transcription vocale, Caching LRU)",
    code: `import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const port = process.env.PORT || 3000;

app.use(express.json({ limit: "25mb" }));

// Initialisation du client Google GenAI
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      "User-Agent": "aistudio-build",
    },
  },
});

// Cache en mémoire vive pour réponses instantanées du Tuteur IA
const tutorResponseCache = new Map<string, { text: string; timestamp: number }>();
const CACHE_TTL_MS = 1000 * 60 * 60 * 6; // 6 heures

// Route Tuteur IA Génie Mentor Académie (Monsieur Massaw Seck)
app.post("/api/gemini/tutor", async (req, res) => {
  try {
    const { messages, subject, level, studentName } = req.body;
    // Génération et gestion de fallback robuste (gemini-3.1-flash-lite)
    // ...
  } catch (err) {
    res.status(500).json({ error: "Erreur Tuteur IA" });
  }
});

// Route Transcription Vocale Haute Fidélité
app.post("/api/gemini/transcribe", async (req, res) => {
  // Décodage base64 et transcription multimodale
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({ server: { middlewareMode: true }, appType: "spa" });
    app.use(vite.middlewares);
  } else {
    app.use(express.static("dist"));
    app.get("*", (req, res) => res.sendFile(path.resolve("dist", "index.html")));
  }
  app.listen(port, () => console.log("Serveur Génie Mentor Académie (GMA) en écoute sur le port " + port));
}

startServer();`
  },
  {
    filename: "server.js",
    packagePath: "backend.dist",
    description: "Point d'entrée serveur Node.js compilé pour le déploiement Cloud Run & Production",
    code: `// Fichier généré automatiquement lors du build (npm run build)
// esbuild server.ts --platform=node --format=esm --outfile=server.js
import "./server.ts";`
  }
];
