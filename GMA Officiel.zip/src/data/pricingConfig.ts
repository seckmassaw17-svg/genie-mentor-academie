import { SecondaryLevel } from "../types";
import { normalizeLevel } from "./mockData";

export interface LevelPricing {
  level: SecondaryLevel;
  inscriptionFee: number;
  monthlyFee: number;
}

export interface PricingConfig {
  inscriptionFees: Record<string, number>;
  monthlyFees: Record<string, number>;
  vipPassFee: number;
  domicileBaseHourFee: number;
  wavePaymentUrl: string;
  officialPhone: string;
  updatedAt?: number;
}

export const DEFAULT_PRICING_CONFIG: PricingConfig = {
  wavePaymentUrl: "https://pay.wave.com/m/M_sn_yU5uzEBaEB9o/c/sn/",
  officialPhone: "78 376 95 84",
  vipPassFee: 15000,
  domicileBaseHourFee: 15000,
  inscriptionFees: {
    // Standardized nomenclature
    "6e": 5000,
    "5e": 5000,
    "4e": 5000,
    "3e": 5000,
    "2nde S": 5000,
    "2nde L": 5000,
    "1re S1": 5000,
    "1re S2": 5000,
    "1re L1": 5000,
    "1re L2": 5000,
    "1re L'": 5000,
    "Tle S1": 10000,
    "Tle S2": 10000,
    "Tle L1": 7000,
    "Tle L2": 7000,
    "Tle L'": 7000,

    // Legacy compatibility
    "6ème": 5000,
    "5ème": 5000,
    "4ème": 5000,
    "3ème": 5000,
    "Seconde L": 5000,
    "Seconde S": 5000,
    "Première L1": 5000,
    "Première L2": 5000,
    "Première S1": 5000,
    "Première S2": 5000,
    "Terminale L1": 7000,
    "Terminale L2": 7000,
    "Terminale S1": 10000,
    "Terminale S2": 10000,
    "Default": 5000,
  },
  monthlyFees: {
    // Standardized nomenclature
    "6e": 4000,
    "5e": 4000,
    "4e": 5000,
    "3e": 5000,
    "2nde S": 5000,
    "2nde L": 5000,
    "1re S1": 5000,
    "1re S2": 5000,
    "1re L1": 5000,
    "1re L2": 5000,
    "1re L'": 5000,
    "Tle S1": 7000,
    "Tle S2": 7000,
    "Tle L1": 6000,
    "Tle L2": 6000,
    "Tle L'": 6000,

    // Legacy compatibility
    "6ème": 4000,
    "5ème": 4000,
    "4ème": 5000,
    "3ème": 5000,
    "Seconde L": 5000,
    "Seconde S": 5000,
    "Première L1": 5000,
    "Première L2": 5000,
    "Première S1": 5000,
    "Première S2": 5000,
    "Terminale L1": 6000,
    "Terminale L2": 6000,
    "Terminale S1": 7000,
    "Terminale S2": 7000,
    "Default": 5000,
  },
};

const PRICING_STORAGE_KEY = "savoirplus_pricing_config_v2";

export function getStoredPricingConfig(): PricingConfig {
  try {
    const raw = localStorage.getItem(PRICING_STORAGE_KEY);
    if (!raw) return DEFAULT_PRICING_CONFIG;
    const parsed = JSON.parse(raw);
    return {
      ...DEFAULT_PRICING_CONFIG,
      ...parsed,
      inscriptionFees: {
        ...DEFAULT_PRICING_CONFIG.inscriptionFees,
        ...(parsed.inscriptionFees || {}),
      },
      monthlyFees: {
        ...DEFAULT_PRICING_CONFIG.monthlyFees,
        ...(parsed.monthlyFees || {}),
      },
    };
  } catch {
    return DEFAULT_PRICING_CONFIG;
  }
}

export function saveStoredPricingConfig(config: PricingConfig): void {
  try {
    localStorage.setItem(PRICING_STORAGE_KEY, JSON.stringify({ ...config, updatedAt: Date.now() }));
    window.dispatchEvent(new Event("savoirplus_pricing_updated"));
    import("./supabaseStorage").then((m) => {
      m.saveAppConfigToSupabase({ pricingConfig: config } as any).catch((err) => console.warn("[RoomSync]", err?.message || err));
    });
  } catch (err) {
    console.error("Failed to save pricing config:", err);
  }
}

export function getRegistrationFeeForLevel(level: SecondaryLevel | string): number {
  if (!level) return DEFAULT_PRICING_CONFIG.inscriptionFees["Default"] || 5000;
  const config = getStoredPricingConfig();
  if (config.inscriptionFees[level] !== undefined) {
    return config.inscriptionFees[level];
  }
  const norm = normalizeLevel(level) || "";
  if (config.inscriptionFees[norm] !== undefined) {
    return config.inscriptionFees[norm];
  }
  const lvlStr = String(level);
  if (norm.startsWith("Tle S") || lvlStr.includes("Terminale S")) return config.inscriptionFees["Tle S1"] || 10000;
  if (norm.startsWith("Tle L") || lvlStr.includes("Terminale L")) return config.inscriptionFees["Tle L1"] || 7000;
  if (norm.startsWith("Tle") || lvlStr.startsWith("Terminale")) return 7000;
  return config.inscriptionFees["Default"] || 5000;
}

export function getMonthlyFeeForLevel(level: SecondaryLevel | string): number {
  if (!level) return DEFAULT_PRICING_CONFIG.monthlyFees["Default"] || 5000;
  const config = getStoredPricingConfig();
  if (config.monthlyFees[level] !== undefined) {
    return config.monthlyFees[level];
  }
  const norm = normalizeLevel(level) || "";
  if (config.monthlyFees[norm] !== undefined) {
    return config.monthlyFees[norm];
  }
  const lvlStr = String(level);
  if (norm === "6e" || norm === "5e" || lvlStr === "6ème" || lvlStr === "5ème") {
    return config.monthlyFees["6e"] || config.monthlyFees["6ème"] || 4000;
  }
  if (norm.startsWith("Tle S") || lvlStr.includes("Terminale S")) return config.monthlyFees["Tle S1"] || 7000;
  if (norm.startsWith("Tle L") || lvlStr.includes("Terminale L")) return config.monthlyFees["Tle L1"] || 6000;
  return config.monthlyFees["Default"] || 5000;
}
