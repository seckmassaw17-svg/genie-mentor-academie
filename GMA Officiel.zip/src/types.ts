// Standardized levels for Senegal Secondary Education (Collège & Lycée)
export type StandardSecondaryLevel =
  | "6e"
  | "5e"
  | "4e"
  | "3e"
  | "2nde S"
  | "2nde L"
  | "1re S1"
  | "1re S2"
  | "1re L1"
  | "1re L2"
  | "1re L'"
  | "Tle S1"
  | "Tle S2"
  | "Tle L1"
  | "Tle L2"
  | "Tle L'";

export type SecondaryLevel = 
  | StandardSecondaryLevel
  | "6ème" 
  | "5ème" 
  | "4ème" 
  | "3ème" 
  | "1ère S1" 
  | "1ère S2" 
  | "1ère L2" 
  | "1ère L1" 
  | "1ère L'"
  | "Terminale S1" 
  | "Terminale S2" 
  | "Terminale L2" 
  | "Terminale L1" 
  | "Terminale L'"
  | "Seconde L" 
  | "Seconde S" 
  | "Première L1" 
  | "Première L2" 
  | "Première S1" 
  | "Première S2" 
  | "2nde" 
  | "1ère" 
  | "Terminale"
  | "GMA"
  | "Génie Mentor Académie"
  | "Savoir+"
  | "Concours"
  | "Examens"
  | "Exercice Avancé"
  | "Exercices Avancés";

export type Subject = 
  | "Maths" 
  | "Mathématiques"
  | "Physique-Chimie" 
  | "SVT" 
  | "Français" 
  | "Histoire-Géo" 
  | "Anglais" 
  | "Philo" 
  | "Informatique";

export interface Course {
  id: string;
  title: string;
  subject: Subject;
  level: SecondaryLevel;
  chapter: string;
  summary: string;
  content: string;
  createdAt: number;
  pdfUrl?: string; // Direct PDF or document preview URL
  pdfFileName?: string;
  videoUrl?: string; // Direct video or embed URL (supports up to 2 GB)
  videoFileName?: string;
  videoSize?: string;
}

export type TutorialCategory = "Ressources complémentaires" | "Exercices corrigés";

export interface TutorialVideo {
  id: string;
  title: string;
  level: SecondaryLevel;
  subject: Subject;
  category: TutorialCategory;
  description: string;
  videoUrl: string;
  videoFileName?: string;
  videoSize?: string; // Max 2 Go
  duration?: string;
  thumbnailUrl?: string;
  viewsCount?: number;
  createdAt: number;
  dateFormatted?: string;
}

export interface Asset {
  assetId: string;
  parentId?: string; // Course ID or Exercise ID
  name?: string;
  title?: string;
  description?: string;
  type: "pdf" | "docx" | "image" | "audio" | "video" | string;
  size?: string;
  storagePath?: string;
  downloadUrl: string;
  isCachedOffline?: boolean;
  isPremium?: boolean; // Document/Ressource VIP réservé aux abonnés
  level?: SecondaryLevel;
  category?: string;
  subject?: Subject;
  chapter?: string;
  pdfUrl?: string;
  pdfFileName?: string;
  fileSize?: string;
  contentPreview?: string;
  createdAt?: number;
}

export type QuestionType = 
  | "single" 
  | "multiple" 
  | "true_false" 
  | "short_answer"
  | "qcm"
  | "vrai_faux"
  | "texte";

export interface QuizQuestion {
  id: string;
  question: string;
  question_text?: string;
  options: string[];
  type?: QuestionType; // "single", "multiple", "true_false", "short_answer"
  correctIndex?: number; // for backward compatibility & single choice
  correctIndices?: number[]; // for multiple choice questions
  correct_answers?: (number | string)[]; // unified flexible representation
  correctAnswerText?: string; // for short answer / text input
  explanation: string;
  imageUrl?: string | null;
  image_url?: string | null;
  mediaType?: "image" | "svg" | "graph" | string;
  media_type?: "image" | "svg" | "graph" | string;
  optionImages?: (string | null | undefined)[];
  option_images?: (string | null | undefined)[];
}

export interface Quiz {
  id: string;
  title: string;
  subject: Subject;
  level: SecondaryLevel;
  chapter?: string;
  questions: QuizQuestion[];
  createdAt: number;
  duration?: string;
  durationMinutes?: number;
  duration_minutes?: number;
  durationSeconds?: number; // Total duration in seconds
  durationFormatted?: string; // Formatted display e.g. "00:15:00"
  status?: "draft" | "published";
  isDraft?: boolean;
}

export interface QuizDraftPayload {
  title: string;
  class_name: string;
  subject: string;
  chapter?: string;
  time_limit_minutes?: number;
  questions: {
    question_text: string;
    image_url?: string | null;
    media_type?: string | null;
    type?: QuestionType;
    options?: string[];
    correct_answers: (number | string)[];
    explanation: string;
  }[];
}

export interface QuizQuestionReview {
  questionId?: string;
  question: string;
  options: string[];
  type?: QuestionType;
  userAnswerIndex: number;
  userAnswerIndices?: number[];
  correctIndex: number;
  correctIndices?: number[];
  explanation: string;
  isCorrect: boolean;
  imageUrl?: string | null;
  image_url?: string | null;
  optionImages?: (string | null | undefined)[];
  option_images?: (string | null | undefined)[];
}

export interface QuizResultRecord {
  id: string;
  studentId: string;
  studentMatricule?: string;
  matricule?: string;
  studentName: string;
  quizId?: string;
  quizTitle: string;
  subject: Subject;
  level: SecondaryLevel;
  scorePercentage: number;
  score20: number;
  totalQuestions: number;
  correctAnswers: number;
  date: string;
  timestamp: number;
  questionReviews?: QuizQuestionReview[];
}

export interface StudentRecord {
  id?: string;
  uid: string;
  displayName: string;
  email: string;
  role?: "admin" | "eleve" | "student" | string;
  level: SecondaryLevel;
  classe?: string;
  studentId?: string;
  matricule?: string;
  phoneNumber?: string;
  phone?: string;
  isProfileComplete?: boolean;
  status: "En ligne" | "Hors-ligne";
  lastLogin: string;
  lastSeen?: number;
  lastSeenFormatted?: string;
  createdAt: number;
  quizResults: QuizResultRecord[];
  homeworkGrades?: any[];
  photoUrl?: string;
  photoURL?: string;
  avatarUrl?: string;
  avatar_url?: string;
  password?: string;
  isAdmin?: boolean;
  isVIP?: boolean;
  vipPlan?: "1mois" | "3mois" | "1an" | "illimite" | "admin" | string;
  vipExpiresAt?: number; // -1 for lifetime, timestamp in ms for expiration
  authProvider?: "google" | "email";
}

export interface UserProfile {
  id?: string;
  uid: string;
  displayName: string;
  fullName?: string;
  nom?: string;
  prenom?: string;
  email: string;
  role?: "admin" | "eleve" | "student" | string;
  level?: SecondaryLevel;
  classe?: string;
  studentId?: string;
  matricule?: string;
  phoneNumber?: string;
  phone?: string;
  isProfileComplete?: boolean;
  photoUrl?: string;
  photoURL?: string;
  avatarUrl?: string;
  avatar_url?: string;
  isAdmin?: boolean;
  isVIP?: boolean;
  vipPlan?: "1mois" | "3mois" | "1an" | "illimite" | "admin" | string;
  vipExpiresAt?: number; // -1 for lifetime, timestamp in ms for expiration
  password?: string;
  authProvider?: "google" | "email";
  app_metadata?: {
    provider?: string;
    providers?: string[];
    [key: string]: any;
  };
  lastSeen?: number;
  createdAt: number;
}

export interface KotlinCodeFile {
  filename: string;
  packagePath: string;
  code: string;
  description: string;
}

export type TransactionStatus = "pending" | "approved" | "rejected";
export type PaymentFormType = "renforcement" | "domicile";
export type PaymentOperator = "wave" | "orange";

export interface PaymentTransaction {
  id: string;
  userUid: string;
  userId?: string; // Standard Auth UID for traceability
  studentMatricule?: string;
  userName: string; // Nom de la personne qui effectue le paiement / Titulaire du compte
  userEmail?: string; // Email de l'utilisateur
  userPhone?: string; // Téléphone de l'utilisateur
  recipientId?: string; // "admin" ou ID utilisateur destinataire
  learnerName: string; // Prénom et Nom de l'apprenant pour qui le cours est payé
  type: PaymentFormType | "VIP" | "pass_vip";
  offerType?: string; // e.g. "PASS_VIP"
  targetRole?: string; // "admin"
  paymentType: "inscription" | "mensualite" | "vip";
  selectedMonth?: string; // e.g. "Octobre", "Novembre"...
  level: SecondaryLevel;
  subjects?: Subject[];
  amount: number;
  operator: PaymentOperator;
  phoneNumber?: string; // Numéro de transfert vers 78 376 95 84
  status: TransactionStatus;
  createdAt: number;
  dateFormatted: string;
  tuteurName?: string;
  address?: string;
  weeklyHours?: string;
  serie?: string;
  rejectionReason?: string;
}

export interface UserNotification {
  id: string;
  recipient?: string; // "admin" ou email de l'élève
  sender_email?: string; // Email de l'émetteur
  senderEmail?: string;
  target_uid?: string; // Colonne standard Supabase : UID de l'élève ou "admin" ou "all"
  targetUid?: string;
  userUid: string;
  userId?: string; // Standard Auth UID for traceability
  studentMatricule?: string;
  userName?: string; // Nom complet de l'élève
  userEmail?: string; // Email de l'élève
  userPhone?: string; // Numéro de téléphone de l'élève
  recipientId?: string; // "admin", "all", ou ID unique de l'élève destinataire
  targetRole?: string; // "admin" ou "student" ou niveau de classe "Terminale S2"
  targetLevel?: SecondaryLevel | string;
  title: string;
  message: string;
  type: "payment_status" | "general" | "info" | "admin_broadcast" | "class_change" | "vip_request" | "vip_approved" | "vip_rejected" | string;
  status: "unread" | "read" | "processed" | "UNREAD" | "READ" | "PROCESSED";
  is_read?: boolean;
  transactionId?: string;
  actionTab?: "accueil" | "cours" | "evaluations" | "tutoriels" | "renforcement" | "vip" | "caisse" | "contact";
  actionSubTab?: "quiz" | "exercices" | "devoirs" | string;
  actionItemId?: string;
  createdAt: number;
  dateFormatted: string;
}

export type ClassChangeStatus = "pending" | "approved" | "rejected";

export interface ClassChangeRequest {
  id: string;
  userUid: string;
  userId?: string; // Standard Auth UID for traceability
  studentMatricule?: string;
  userName: string;
  userEmail: string;
  userPhone?: string;
  recipientId?: string; // "admin"
  targetRole?: string; // "admin"
  currentLevel: SecondaryLevel;
  requestedLevel: SecondaryLevel;
  reason: string;
  status: ClassChangeStatus;
  createdAt: number;
  dateFormatted: string;
  rejectionReason?: string;
}

export type VIPRequestStatus = "PENDING" | "APPROVED" | "REJECTED" | "pending" | "approved" | "rejected";

export interface VIPPaymentRequest {
  id: string;
  userUid: string;
  student_uid?: string; // Supabase column alias
  userId?: string; // Standard Auth UID for traceability
  studentMatricule?: string;
  studentName: string;
  userName?: string; // Alias for studentName
  userEmail?: string;
  userPhone: string;
  level?: string; // e.g. "3ème", "Terminale S2"
  recipientId?: string; // "admin"
  targetRole?: string; // "admin"
  offerType?: "PASS_VIP" | string;
  transactionRef: string;
  transaction_ref?: string;
  operator?: string;
  amount: number;
  status: VIPRequestStatus;
  planId?: "1mois" | "3mois" | "6mois" | "1an" | "illimite" | string;
  plan_id?: string; // Supabase column alias
  planDuration?: string; // e.g. "1 mois", "3 mois", "6 mois", "1 an", "Illimité"
  plan_duration?: string;
  createdAt: number;
  created_at?: number;
  requested_at?: number;
  dateFormatted: string;
  rejectionReason?: string;
  rejection_reason?: string;
}

export type CaissePaymentMethod = "Cash 💵" | "Wave 🌊" | "Orange Money 🟧";

export interface CaisseTransaction {
  id: string;
  studentName: string;
  studentMatricule?: string;
  phone: string;
  amount: number;
  motif: string;
  paymentMethod: CaissePaymentMethod;
  note?: string;
  adminName: string;
  createdAt: number;
  dateFormatted: string;
}

export type HomeworkStatus = "pending" | "graded" | "in_review" | "SUBMITTED" | "GRADING" | "GRADED";

export interface AdminAuditLog {
  id: string;
  adminEmail: string;
  adminName: string;
  actionType: "REMISE_A_ZERO_CAISSE" | "VIDER_HISTORIQUE_CAISSE" | "VALIDATE_PAYMENT" | "REJECT_PAYMENT" | "VALIDATE_CLASS_CHANGE" | "REJECT_CLASS_CHANGE" | "VALIDATE_VIP" | "REJECT_VIP" | "DELETE_ITEM" | "PUBLISH_UPDATE" | string;
  target?: string;
  details: string;
  createdAt: number;
  dateFormatted: string;
}

export interface HomeworkSubmission {
  id: string;
  userUid: string;
  studentMatricule?: string;
  matricule?: string;
  studentName: string;
  studentEmail?: string;
  studentLevel?: SecondaryLevel;
  level: SecondaryLevel;
  subject: Subject;
  title: string;
  comment?: string;
  studentComment?: string;
  fileData: string; // Base64 data URI or document link
  fileName: string;
  fileType: string;
  fileSize?: string;
  submittedAt: number;
  dateFormatted: string;
  // Correction par l'administrateur Massaw Seck
  status: HomeworkStatus;
  grade20?: number; // Note sur 20 attribuée
  grade?: number;
  maxGrade?: number;
  feedback?: string; // Appréciations pédagogiques
  adminFeedback?: string;
  annotatedPdfData?: string; // PDF corrigé / annoté optionnel
  gradedAt?: number;
  correctedAt?: number;
  gradedBy?: string; // "Massaw Seck"
  correctedBy?: string;
  syncedWithFirebase?: boolean;
}

